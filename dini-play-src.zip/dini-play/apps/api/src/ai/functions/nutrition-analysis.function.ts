export const nutritionAnalysisFunction = {
  name: "analyzeNutrition",
  description: "Analyse la valeur nutritionnelle d'une recette ou d'un plan de repas",
  parameters: {
    type: "object",
    properties: {
      calories: { type: "number" },
      macronutrients: {
        type: "object",
        properties: {
          protein: { type: "number" },
          carbs: { type: "number" },
          fat: { type: "number" },
          fiber: { type: "number" },
        },
        required: ["protein", "carbs", "fat"]
      },
      micronutrients: {
        type: "object",
        properties: {
          vitamins: { type: "array", items: { type: "string" } },
          minerals: { type: "array", items: { type: "string" } },
        },
      },
      healthScore: { type: "number" },
      halalCompliance: { type: "boolean" },
      allergens: { 
        type: "array", 
        items: { type: "string" } 
      },
    },
    required: ["calories", "macronutrients", "healthScore", "halalCompliance"],
  },
};
