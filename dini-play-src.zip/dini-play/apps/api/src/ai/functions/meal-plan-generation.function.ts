export const mealPlanGenerationFunction = {
  name: "generateMealPlan",
  description: "Génère un plan de repas personnalisé en fonction des préférences de l'utilisateur",
  parameters: {
    type: "object",
    properties: {
      mealPlan: {
        type: "object",
        properties: {
          days: {
            type: "array",
            items: {
              type: "object",
              properties: {
                day: { type: "number" },
                date: { type: "string", format: "date" },
                meals: {
                  type: "object",
                  properties: {
                    breakfast: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        recipeId: { type: "string" },
                        calories: { type: "number" },
                      },
                    },
                    lunch: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        recipeId: { type: "string" },
                        calories: { type: "number" },
                      },
                    },
                    dinner: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        recipeId: { type: "string" },
                        calories: { type: "number" },
                      },
                    },
                    snacks: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          title: { type: "string" },
                          calories: { type: "number" },
                        },
                      },
                    },
                  },
                  required: ["breakfast", "lunch", "dinner"],
                },
                totalCalories: { type: "number" },
                nutritionSummary: {
                  type: "object",
                  properties: {
                    protein: { type: "number" },
                    carbs: { type: "number" },
                    fat: { type: "number" },
                  },
                },
              },
              required: ["day", "date", "meals", "totalCalories"],
            },
          },
          totalDays: { type: "number" },
          averageCaloriesPerDay: { type: "number" },
        },
        required: ["days", "totalDays", "averageCaloriesPerDay"],
      },
    },
    required: ["mealPlan"],
  },
};
