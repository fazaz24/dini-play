export const recipeAnalysisFunction = {
  name: "analyzeRecipe",
  description: "Analyse une recette pour déterminer ses caractéristiques nutritionnelles et culturelles",
  parameters: {
    type: "object",
    properties: {
      nutritionalValue: {
        type: "object",
        properties: {
          calories: { type: "number" },
          protein: { type: "number" },
          carbs: { type: "number" },
          fat: { type: "number" },
        },
      },
      cuisineOrigin: { type: "string" },
      halalCompliance: { type: "boolean" },
      difficultyLevel: { type: "string", enum: ["easy", "medium", "hard"] },
      preparationTime: { type: "number" },
    },
    required: ["nutritionalValue", "halalCompliance"],
  },
};
