export const ingredientSubstitutionFunction = {
  name: "substituteIngredient",
  description: "Propose des substituts halal pour des ingrédients spécifiques",
  parameters: {
    type: "object",
    properties: {
      substitutions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            originalIngredient: { type: "string" },
            substitutes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  ratio: { type: "string" },
                  nutritionalImpact: { 
                    type: "string",
                    enum: ["lower_calories", "higher_protein", "similar", "higher_fiber", "lower_fat"]
                  },
                  tasteImpact: { 
                    type: "string",
                    enum: ["similar", "milder", "stronger", "different", "sweeter", "more_savory"]
                  },
                  halalStatus: { type: "boolean" },
                },
                required: ["name", "ratio", "halalStatus"]
              }
            },
            preparationNotes: { type: "string" },
          },
          required: ["originalIngredient", "substitutes"]
        }
      }
    },
    required: ["substitutions"],
  },
};
