import { IsString, IsNotEmpty, IsNumber, IsObject, IsOptional, Min, Max, IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

class PreferencesDto {
  @ApiProperty({ description: 'Préférences alimentaires', required: false })
  @IsArray()
  @IsOptional()
  dietaryPreferences?: string[];

  @ApiProperty({ description: 'Ingrédients à éviter', required: false })
  @IsArray()
  @IsOptional()
  excludedIngredients?: string[];

  @ApiProperty({ description: 'Cuisines préférées', required: false })
  @IsArray()
  @IsOptional()
  preferredCuisines?: string[];

  @ApiProperty({ description: 'Niveau de difficulté maximum', required: false })
  @IsString()
  @IsOptional()
  maxDifficultyLevel?: string;

  @ApiProperty({ description: 'Temps de préparation maximum en minutes', required: false })
  @IsNumber()
  @IsOptional()
  maxPrepTime?: number;

  @ApiProperty({ description: 'Calories maximum par repas', required: false })
  @IsNumber()
  @IsOptional()
  maxCaloriesPerMeal?: number;
}

export class GenerateMealPlanDto {
  @ApiProperty({ description: 'ID de l\'utilisateur' })
  @IsString()
  @IsNotEmpty()
  userId: string;

  @ApiProperty({ description: 'Durée du plan de repas en jours' })
  @IsNumber()
  @Min(1)
  @Max(30)
  duration: number;

  @ApiProperty({ type: PreferencesDto, description: 'Préférences pour le plan de repas' })
  @IsObject()
  @IsOptional()
  preferences?: PreferencesDto;
}
