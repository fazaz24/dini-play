import { IsString, IsNotEmpty, IsArray, ValidateNested, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class IngredientDto {
  @ApiProperty({ description: 'Nom de l\'ingrédient' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Quantité de l\'ingrédient' })
  @IsString()
  @IsNotEmpty()
  quantity: string;
}

class StepDto {
  @ApiProperty({ description: 'Description de l\'étape de préparation' })
  @IsString()
  @IsNotEmpty()
  description: string;
}

export class AnalyzeRecipeDto {
  @ApiProperty({ description: 'Titre de la recette' })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({ description: 'Description de la recette' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ type: [IngredientDto], description: 'Liste des ingrédients' })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => IngredientDto)
  ingredients: IngredientDto[];

  @ApiProperty({ type: [StepDto], description: 'Étapes de préparation' })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => StepDto)
  steps: StepDto[];

  @ApiProperty({ description: 'Temps de préparation en minutes', required: false })
  @IsOptional()
  prepTime?: number;

  @ApiProperty({ description: 'Temps de cuisson en minutes', required: false })
  @IsOptional()
  cookTime?: number;

  @ApiProperty({ description: 'Catégorie de la recette', required: false })
  @IsString()
  @IsOptional()
  category?: string;

  @ApiProperty({ description: 'Origine culturelle de la recette', required: false })
  @IsString()
  @IsOptional()
  cuisine?: string;
}
