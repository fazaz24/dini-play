import { IsString, IsNotEmpty, IsUUID } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ChatRequestDto {
  @ApiProperty({ description: 'Message de l\'utilisateur' })
  @IsString()
  @IsNotEmpty()
  message: string;

  @ApiProperty({ description: 'ID de l\'utilisateur' })
  @IsString()
  @IsUUID()
  @IsNotEmpty()
  userId: string;
}
