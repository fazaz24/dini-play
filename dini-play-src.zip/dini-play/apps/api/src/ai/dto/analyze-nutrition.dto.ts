import { IsString, IsNotEmpty, IsObject, IsOptional, IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class AnalyzeNutritionDto {
  @ApiProperty({ description: 'Nom de l\'aliment ou de la recette' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Ingrédients de la recette', required: false })
  @IsArray()
  @IsOptional()
  ingredients?: string[];

  @ApiProperty({ description: 'Quantités des ingrédients', required: false })
  @IsArray()
  @IsOptional()
  quantities?: string[];

  @ApiProperty({ description: 'Poids ou volume total', required: false })
  @IsString()
  @IsOptional()
  totalAmount?: string;

  @ApiProperty({ description: 'Informations nutritionnelles connues', required: false })
  @IsObject()
  @IsOptional()
  knownNutritionInfo?: Record<string, any>;
}
