import { Controller, Post, Body, Get, Param, UseGuards, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { AiService } from './ai.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { AnalyzeRecipeDto } from './dto/analyze-recipe.dto';
import { GenerateMealPlanDto } from './dto/generate-meal-plan.dto';
import { AnalyzeNutritionDto } from './dto/analyze-nutrition.dto';
import { ChatRequestDto } from './dto/chat-request.dto';

@ApiTags('ai')
@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('analyze-recipe')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Analyser une recette avec l\'IA' })
  @ApiResponse({ status: 201, description: 'Analyse de recette réussie' })
  async analyzeRecipe(@Body() analyzeRecipeDto: AnalyzeRecipeDto) {
    return this.aiService.analyzeRecipe(analyzeRecipeDto);
  }

  @Post('generate-recommendations')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Générer des recommandations de recettes personnalisées' })
  @ApiResponse({ status: 201, description: 'Recommandations générées avec succès' })
  async generateRecommendations(
    @Body('userPreferences') userPreferences: any,
    @Body('recentRecipes') recentRecipes: any[],
  ) {
    return this.aiService.generateRecommendations(userPreferences, recentRecipes);
  }

  @Post('generate-meal-plan')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Générer un plan de repas personnalisé' })
  @ApiResponse({ status: 201, description: 'Plan de repas généré avec succès' })
  async generateMealPlan(@Body() generateMealPlanDto: GenerateMealPlanDto) {
    return this.aiService.generateMealPlan(
      generateMealPlanDto.userId,
      generateMealPlanDto.duration,
      generateMealPlanDto.preferences,
    );
  }

  @Post('analyze-nutrition')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Analyser la valeur nutritionnelle d\'un aliment ou d\'une recette' })
  @ApiResponse({ status: 201, description: 'Analyse nutritionnelle réussie' })
  async analyzeNutrition(@Body() analyzeNutritionDto: AnalyzeNutritionDto) {
    return this.aiService.analyzeNutrition(analyzeNutritionDto);
  }

  @Post('chat')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Interagir avec l\'assistant IA' })
  @ApiResponse({ status: 201, description: 'Réponse de l\'assistant générée avec succès' })
  async chat(@Body() chatRequestDto: ChatRequestDto) {
    return this.aiService.processChat(chatRequestDto.message, chatRequestDto.userId);
  }
}
