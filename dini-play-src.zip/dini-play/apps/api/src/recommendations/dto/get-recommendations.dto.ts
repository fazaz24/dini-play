import { IsNotEmpty, IsUUID } from 'class-validator';

export class GetRecommendationsDto {
  @IsUUID()
  @IsNotEmpty()
  userId: string;
}
