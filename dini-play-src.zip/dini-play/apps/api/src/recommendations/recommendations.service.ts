import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { GetRecommendationsDto } from './dto/get-recommendations.dto';

@Injectable()
export class RecommendationsService {
  constructor(private prisma: PrismaService) {}

  async getRecommendations(getRecommendationsDto: GetRecommendationsDto) {
    const { userId } = getRecommendationsDto;

    // Récupérer les préférences et allergies de l'utilisateur
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        preferences: true,
        allergies: true,
        budget: true,
        cookingTime: true,
      },
    });

    if (!user) {
      throw new Error('Utilisateur non trouvé');
    }

    // Récupérer les recettes qui correspondent aux préférences et qui ne contiennent pas d'allergènes
    const recettes = await this.prisma.recette.findMany({
      where: {
        deletedAt: null,
        isHalal: true,
        ...(user.budget && { difficulty: user.budget }),
        ...(user.cookingTime && {
          OR: [
            { preparationTime: { lte: this.getMaxPrepTime(user.cookingTime) } },
            { cookingTime: { lte: this.getMaxCookTime(user.cookingTime) } },
          ],
        }),
        ingredients: {
          every: {
            ingredient: {
              name: {
                notIn: user.allergies || [],
              },
            },
          },
        },
      },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
      take: 10, // Limiter à 10 recommandations
    });

    // Trier les recettes par pertinence (nombre de préférences correspondantes)
    const sortedRecettes = recettes.sort((a, b) => {
      const scoreA = this.calculateRelevanceScore(a, user.preferences || []);
      const scoreB = this.calculateRelevanceScore(b, user.preferences || []);
      return scoreB - scoreA;
    });

    return {
      recommendations: sortedRecettes,
    };
  }

  // Méthode pour calculer le score de pertinence d'une recette
  private calculateRelevanceScore(recette: any, preferences: string[]): number {
    let score = 0;

    // Vérifier si le nom de la recette contient une préférence
    preferences.forEach(pref => {
      if (recette.name.toLowerCase().includes(pref.toLowerCase())) {
        score += 2;
      }
      
      // Vérifier si la description contient une préférence
      if (recette.description.toLowerCase().includes(pref.toLowerCase())) {
        score += 1;
      }
      
      // Vérifier si les ingrédients contiennent une préférence
      recette.ingredients.forEach(ing => {
        if (ing.ingredient.name.toLowerCase().includes(pref.toLowerCase())) {
          score += 3;
        }
      });
    });

    return score;
  }

  // Méthode pour convertir le temps de cuisson maximum en minutes
  private getMaxCookTime(cookingTime: string): number {
    switch (cookingTime) {
      case 'QUICK':
        return 15;
      case 'MEDIUM':
        return 30;
      case 'LONG':
        return 60;
      default:
        return 999; // Pas de limite
    }
  }

  // Méthode pour convertir le temps de préparation maximum en minutes
  private getMaxPrepTime(cookingTime: string): number {
    switch (cookingTime) {
      case 'QUICK':
        return 10;
      case 'MEDIUM':
        return 20;
      case 'LONG':
        return 45;
      default:
        return 999; // Pas de limite
    }
  }
}
