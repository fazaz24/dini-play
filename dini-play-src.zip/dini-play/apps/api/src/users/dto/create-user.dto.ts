import { IsEmail, IsEnum, IsNotEmpty, IsOptional, IsString, MinLength } from 'class-validator';
import { BudgetLevel, CookingTime, UserRole } from '@prisma/client';

export class CreateUserDto {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsString()
  @IsNotEmpty()
  @MinLength(6)
  password: string;

  @IsString()
  @IsNotEmpty()
  firstName: string;

  @IsString()
  @IsNotEmpty()
  lastName: string;

  @IsEnum(UserRole)
  @IsOptional()
  role?: UserRole;

  @IsOptional()
  allergies?: string[];

  @IsOptional()
  preferences?: string[];

  @IsEnum(BudgetLevel)
  @IsOptional()
  budget?: BudgetLevel;

  @IsEnum(CookingTime)
  @IsOptional()
  cookingTime?: CookingTime;
}
