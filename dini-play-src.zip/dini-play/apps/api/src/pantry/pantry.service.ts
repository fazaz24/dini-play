import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePantryItemDto } from './dto/create-pantry-item.dto';
import { UpdatePantryItemDto } from './dto/update-pantry-item.dto';

@Injectable()
export class PantryService {
  constructor(private prisma: PrismaService) {}

  async create(createPantryItemDto: CreatePantryItemDto) {
    return this.prisma.pantryItem.create({
      data: {
        ...createPantryItemDto,
        expiryDate: createPantryItemDto.expiryDate ? new Date(createPantryItemDto.expiryDate) : null,
      },
      include: {
        ingredient: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  async findAll() {
    return this.prisma.pantryItem.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        ingredient: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  async findByUser(userId: string) {
    return this.prisma.pantryItem.findMany({
      where: {
        userId,
        deletedAt: null,
      },
      include: {
        ingredient: true,
      },
    });
  }

  async findOne(id: string) {
    return this.prisma.pantryItem.findUnique({
      where: { id },
      include: {
        ingredient: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  async update(id: string, updatePantryItemDto: UpdatePantryItemDto) {
    const data: any = { ...updatePantryItemDto };
    
    if (updatePantryItemDto.expiryDate) {
      data.expiryDate = new Date(updatePantryItemDto.expiryDate);
    }
    
    return this.prisma.pantryItem.update({
      where: { id },
      data,
      include: {
        ingredient: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  async remove(id: string) {
    return this.prisma.pantryItem.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }
}
