import { IsNotEmpty, IsString } from 'class-validator';

export class DashboardStatsDto {
  @IsString()
  @IsNotEmpty()
  period: string; // 'day', 'week', 'month', 'year'
}
