import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { DashboardStatsDto } from './dto/dashboard-stats.dto';
import { UserRole } from '@prisma/client';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  async getDashboardStats(dashboardStatsDto: DashboardStatsDto) {
    const { period } = dashboardStatsDto;
    
    // Calculer la date de début en fonction de la période
    const startDate = this.getStartDateForPeriod(period);
    
    // Statistiques des utilisateurs
    const totalUsers = await this.prisma.user.count({
      where: {
        deletedAt: null,
      },
    });
    
    const newUsers = await this.prisma.user.count({
      where: {
        createdAt: {
          gte: startDate,
        },
        deletedAt: null,
      },
    });
    
    const adminUsers = await this.prisma.user.count({
      where: {
        role: UserRole.ADMIN,
        deletedAt: null,
      },
    });
    
    // Statistiques des recettes
    const totalRecettes = await this.prisma.recette.count({
      where: {
        deletedAt: null,
      },
    });
    
    const newRecettes = await this.prisma.recette.count({
      where: {
        createdAt: {
          gte: startDate,
        },
        deletedAt: null,
      },
    });
    
    // Statistiques des plans de repas
    const totalPlanRepas = await this.prisma.planRepas.count({
      where: {
        deletedAt: null,
      },
    });
    
    const newPlanRepas = await this.prisma.planRepas.count({
      where: {
        createdAt: {
          gte: startDate,
        },
        deletedAt: null,
      },
    });
    
    // Statistiques des listes de courses
    const totalShoppingLists = await this.prisma.shoppingList.count({
      where: {
        deletedAt: null,
      },
    });
    
    const newShoppingLists = await this.prisma.shoppingList.count({
      where: {
        createdAt: {
          gte: startDate,
        },
        deletedAt: null,
      },
    });
    
    return {
      period,
      users: {
        total: totalUsers,
        new: newUsers,
        admin: adminUsers,
      },
      recettes: {
        total: totalRecettes,
        new: newRecettes,
      },
      planRepas: {
        total: totalPlanRepas,
        new: newPlanRepas,
      },
      shoppingLists: {
        total: totalShoppingLists,
        new: newShoppingLists,
      },
    };
  }
  
  // Méthode pour obtenir la date de début en fonction de la période
  private getStartDateForPeriod(period: string): Date {
    const now = new Date();
    
    switch (period) {
      case 'day':
        return new Date(now.setDate(now.getDate() - 1));
      case 'week':
        return new Date(now.setDate(now.getDate() - 7));
      case 'month':
        return new Date(now.setMonth(now.getMonth() - 1));
      case 'year':
        return new Date(now.setFullYear(now.getFullYear() - 1));
      default:
        return new Date(now.setDate(now.getDate() - 30)); // Par défaut, 30 jours
    }
  }
}
