import { IsNotEmpty, IsString, IsInt, IsOptional, IsBoolean, IsNumber, Min, Max, IsArray } from 'class-validator';

export class CreateRecetteDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsString()
  @IsNotEmpty()
  instructions: string;

  @IsInt()
  @Min(1)
  preparationTime: number;

  @IsInt()
  @Min(0)
  cookingTime: number;

  @IsInt()
  @Min(1)
  servings: number;

  @IsBoolean()
  @IsOptional()
  isHalal?: boolean = true;

  @IsString()
  @IsNotEmpty()
  difficulty: string;

  @IsInt()
  @IsOptional()
  calories?: number;

  @IsNumber()
  @IsOptional()
  @Min(0)
  proteins?: number;

  @IsNumber()
  @IsOptional()
  @Min(0)
  carbs?: number;

  @IsNumber()
  @IsOptional()
  @Min(0)
  fats?: number;

  @IsString()
  @IsOptional()
  imageUrl?: string;

  @IsArray()
  @IsOptional()
  ingredients?: {
    ingredientId: string;
    quantity: number;
    unit: string;
  }[];
}
