import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRecetteDto } from './dto/create-recette.dto';
import { UpdateRecetteDto } from './dto/update-recette.dto';

@Injectable()
export class RecettesService {
  constructor(private prisma: PrismaService) {}

  async create(createRecetteDto: CreateRecetteDto) {
    const { ingredients, ...recetteData } = createRecetteDto;
    
    return this.prisma.recette.create({
      data: {
        ...recetteData,
        ingredients: ingredients ? {
          create: ingredients.map(ingredient => ({
            ingredient: {
              connect: { id: ingredient.ingredientId }
            },
            quantity: ingredient.quantity,
            unit: ingredient.unit,
          }))
        } : undefined,
      },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async findAll() {
    return this.prisma.recette.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async findOne(id: string) {
    return this.prisma.recette.findUnique({
      where: { id },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async update(id: string, updateRecetteDto: UpdateRecetteDto) {
    const { ingredients, ...recetteData } = updateRecetteDto;
    
    // Si nous avons des ingrédients à mettre à jour, nous devons d'abord supprimer les existants
    if (ingredients) {
      await this.prisma.ingredientOnRecette.deleteMany({
        where: { recetteId: id },
      });
    }
    
    return this.prisma.recette.update({
      where: { id },
      data: {
        ...recetteData,
        ingredients: ingredients ? {
          create: ingredients.map(ingredient => ({
            ingredient: {
              connect: { id: ingredient.ingredientId }
            },
            quantity: ingredient.quantity,
            unit: ingredient.unit,
          }))
        } : undefined,
      },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async remove(id: string) {
    return this.prisma.recette.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }
}
