import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { RecettesModule } from './recettes/recettes.module';
import { PlanRepasModule } from './plan-repas/plan-repas.module';
import { PantryModule } from './pantry/pantry.module';
import { ShoppingListModule } from './shopping-list/shopping-list.module';
import { RecommendationsModule } from './recommendations/recommendations.module';
import { AdminModule } from './admin/admin.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    PrismaModule,
    UsersModule,
    AuthModule,
    RecettesModule,
    PlanRepasModule,
    PantryModule,
    ShoppingListModule,
    RecommendationsModule,
    AdminModule,
  ],
})
export class AppModule {}
