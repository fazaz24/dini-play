import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ShoppingListService } from './shopping-list.service';
import { CreateShoppingListDto } from './dto/create-shopping-list.dto';
import { UpdateShoppingListDto } from './dto/update-shopping-list.dto';
import { CreateShoppingItemDto } from './dto/create-shopping-item.dto';
import { UpdateShoppingItemDto } from './dto/update-shopping-item.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('shopping-list')
@Controller('shopping-list')
export class ShoppingListController {
  constructor(private readonly shoppingListService: ShoppingListService) {}

  // Routes pour ShoppingList
  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  createShoppingList(@Body() createShoppingListDto: CreateShoppingListDto) {
    return this.shoppingListService.createShoppingList(createShoppingListDto);
  }

  @Get()
  findAllShoppingLists() {
    return this.shoppingListService.findAllShoppingLists();
  }

  @Get('user/:userId')
  findShoppingListsByUser(@Param('userId') userId: string) {
    return this.shoppingListService.findShoppingListsByUser(userId);
  }

  @Get(':id')
  findOneShoppingList(@Param('id') id: string) {
    return this.shoppingListService.findOneShoppingList(id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  updateShoppingList(@Param('id') id: string, @Body() updateShoppingListDto: UpdateShoppingListDto) {
    return this.shoppingListService.updateShoppingList(id, updateShoppingListDto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  removeShoppingList(@Param('id') id: string) {
    return this.shoppingListService.removeShoppingList(id);
  }

  // Routes pour ShoppingItem
  @Post('items')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  createShoppingItem(@Body() createShoppingItemDto: CreateShoppingItemDto) {
    return this.shoppingListService.createShoppingItem(createShoppingItemDto);
  }

  @Get('items')
  findAllShoppingItems() {
    return this.shoppingListService.findAllShoppingItems();
  }

  @Get('items/:id')
  findOneShoppingItem(@Param('id') id: string) {
    return this.shoppingListService.findOneShoppingItem(id);
  }

  @Patch('items/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  updateShoppingItem(@Param('id') id: string, @Body() updateShoppingItemDto: UpdateShoppingItemDto) {
    return this.shoppingListService.updateShoppingItem(id, updateShoppingItemDto);
  }

  @Delete('items/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  removeShoppingItem(@Param('id') id: string) {
    return this.shoppingListService.removeShoppingItem(id);
  }

  // Route pour générer une liste de courses à partir d'un plan de repas
  @Post('generate/:planRepasId/:userId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  generateFromPlanRepas(
    @Param('planRepasId') planRepasId: string,
    @Param('userId') userId: string,
  ) {
    return this.shoppingListService.generateFromPlanRepas(planRepasId, userId);
  }
}
