import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateShoppingListDto } from './dto/create-shopping-list.dto';
import { UpdateShoppingListDto } from './dto/update-shopping-list.dto';
import { CreateShoppingItemDto } from './dto/create-shopping-item.dto';
import { UpdateShoppingItemDto } from './dto/update-shopping-item.dto';

@Injectable()
export class ShoppingListService {
  constructor(private prisma: PrismaService) {}

  // Méthodes pour ShoppingList
  async createShoppingList(createShoppingListDto: CreateShoppingListDto) {
    return this.prisma.shoppingList.create({
      data: createShoppingListDto,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        items: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async findAllShoppingLists() {
    return this.prisma.shoppingList.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        items: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async findShoppingListsByUser(userId: string) {
    return this.prisma.shoppingList.findMany({
      where: {
        userId,
        deletedAt: null,
      },
      include: {
        items: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async findOneShoppingList(id: string) {
    return this.prisma.shoppingList.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        items: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async updateShoppingList(id: string, updateShoppingListDto: UpdateShoppingListDto) {
    return this.prisma.shoppingList.update({
      where: { id },
      data: updateShoppingListDto,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        items: {
          include: {
            ingredient: true,
          },
        },
      },
    });
  }

  async removeShoppingList(id: string) {
    return this.prisma.shoppingList.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }

  // Méthodes pour ShoppingItem
  async createShoppingItem(createShoppingItemDto: CreateShoppingItemDto) {
    return this.prisma.shoppingItem.create({
      data: createShoppingItemDto,
      include: {
        ingredient: true,
        shoppingList: true,
      },
    });
  }

  async findAllShoppingItems() {
    return this.prisma.shoppingItem.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        ingredient: true,
        shoppingList: true,
      },
    });
  }

  async findOneShoppingItem(id: string) {
    return this.prisma.shoppingItem.findUnique({
      where: { id },
      include: {
        ingredient: true,
        shoppingList: true,
      },
    });
  }

  async updateShoppingItem(id: string, updateShoppingItemDto: UpdateShoppingItemDto) {
    return this.prisma.shoppingItem.update({
      where: { id },
      data: updateShoppingItemDto,
      include: {
        ingredient: true,
        shoppingList: true,
      },
    });
  }

  async removeShoppingItem(id: string) {
    return this.prisma.shoppingItem.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }

  // Méthode pour générer une liste de courses à partir d'un plan de repas
  async generateFromPlanRepas(planRepasId: string, userId: string) {
    // 1. Créer une nouvelle liste de courses
    const shoppingList = await this.prisma.shoppingList.create({
      data: {
        name: 'Liste générée automatiquement',
        userId,
      },
    });

    // 2. Récupérer tous les repas du plan de repas avec leurs recettes et ingrédients
    const planRepas = await this.prisma.planRepas.findUnique({
      where: { id: planRepasId },
      include: {
        repas: {
          include: {
            recettes: {
              include: {
                recette: {
                  include: {
                    ingredients: {
                      include: {
                        ingredient: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!planRepas) {
      throw new Error('Plan de repas non trouvé');
    }

    // 3. Agréger tous les ingrédients nécessaires
    const ingredientsMap = new Map();

    planRepas.repas.forEach(repas => {
      repas.recettes.forEach(recetteOnRepas => {
        const { recette, servings } = recetteOnRepas;
        const servingsRatio = servings / recette.servings;

        recette.ingredients.forEach(ingredientOnRecette => {
          const { ingredient, quantity, unit } = ingredientOnRecette;
          const adjustedQuantity = quantity * servingsRatio;

          if (ingredientsMap.has(ingredient.id)) {
            const existingItem = ingredientsMap.get(ingredient.id);
            if (existingItem.unit === unit) {
              existingItem.quantity += adjustedQuantity;
            } else {
              // Si les unités sont différentes, on crée un nouvel élément
              ingredientsMap.set(`${ingredient.id}-${unit}`, {
                ingredientId: ingredient.id,
                quantity: adjustedQuantity,
                unit,
              });
            }
          } else {
            ingredientsMap.set(ingredient.id, {
              ingredientId: ingredient.id,
              quantity: adjustedQuantity,
              unit,
            });
          }
        });
      });
    });

    // 4. Créer les éléments de la liste de courses
    const shoppingItems = [];
    for (const item of ingredientsMap.values()) {
      const shoppingItem = await this.prisma.shoppingItem.create({
        data: {
          ...item,
          shoppingListId: shoppingList.id,
          checked: false,
        },
        include: {
          ingredient: true,
        },
      });
      shoppingItems.push(shoppingItem);
    }

    return {
      ...shoppingList,
      items: shoppingItems,
    };
  }
}
