import { IsNotEmpty, IsString, IsUUID } from 'class-validator';

export class CreateShoppingListDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsUUID()
  @IsNotEmpty()
  userId: string;
}
