import { Module } from '@nestjs/common';
import { PlanRepasService } from './plan-repas.service';
import { PlanRepasController } from './plan-repas.controller';

@Module({
  controllers: [PlanRepasController],
  providers: [PlanRepasService],
  exports: [PlanRepasService],
})
export class PlanRepasModule {}
