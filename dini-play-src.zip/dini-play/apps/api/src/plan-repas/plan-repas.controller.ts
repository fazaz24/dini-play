import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { PlanRepasService } from './plan-repas.service';
import { CreatePlanRepasDto } from './dto/create-plan-repas.dto';
import { UpdatePlanRepasDto } from './dto/update-plan-repas.dto';
import { CreateRepasDto } from './dto/create-repas.dto';
import { UpdateRepasDto } from './dto/update-repas.dto';
import { AddRecetteToRepasDto } from './dto/add-recette-to-repas.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('plan-repas')
@Controller('plan-repas')
export class PlanRepasController {
  constructor(private readonly planRepasService: PlanRepasService) {}

  // Routes pour PlanRepas
  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  createPlanRepas(@Body() createPlanRepasDto: CreatePlanRepasDto) {
    return this.planRepasService.createPlanRepas(createPlanRepasDto);
  }

  @Get()
  findAllPlanRepas() {
    return this.planRepasService.findAllPlanRepas();
  }

  @Get('user/:userId')
  findPlanRepasByUser(@Param('userId') userId: string) {
    return this.planRepasService.findPlanRepasByUser(userId);
  }

  @Get(':id')
  findOnePlanRepas(@Param('id') id: string) {
    return this.planRepasService.findOnePlanRepas(id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  updatePlanRepas(@Param('id') id: string, @Body() updatePlanRepasDto: UpdatePlanRepasDto) {
    return this.planRepasService.updatePlanRepas(id, updatePlanRepasDto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  removePlanRepas(@Param('id') id: string) {
    return this.planRepasService.removePlanRepas(id);
  }

  // Routes pour Repas
  @Post('repas')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  createRepas(@Body() createRepasDto: CreateRepasDto) {
    return this.planRepasService.createRepas(createRepasDto);
  }

  @Get('repas')
  findAllRepas() {
    return this.planRepasService.findAllRepas();
  }

  @Get('repas/:id')
  findOneRepas(@Param('id') id: string) {
    return this.planRepasService.findOneRepas(id);
  }

  @Patch('repas/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  updateRepas(@Param('id') id: string, @Body() updateRepasDto: UpdateRepasDto) {
    return this.planRepasService.updateRepas(id, updateRepasDto);
  }

  @Delete('repas/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  removeRepas(@Param('id') id: string) {
    return this.planRepasService.removeRepas(id);
  }

  // Routes pour ajouter/supprimer des recettes à un repas
  @Post('repas/:id/recettes')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  addRecetteToRepas(
    @Param('id') id: string,
    @Body() addRecetteToRepasDto: AddRecetteToRepasDto,
  ) {
    return this.planRepasService.addRecetteToRepas(id, addRecetteToRepasDto);
  }

  @Delete('repas/:repasId/recettes/:recetteId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  removeRecetteFromRepas(
    @Param('repasId') repasId: string,
    @Param('recetteId') recetteId: string,
  ) {
    return this.planRepasService.removeRecetteFromRepas(repasId, recetteId);
  }
}
