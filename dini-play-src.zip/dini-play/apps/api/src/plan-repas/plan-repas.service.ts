import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePlanRepasDto } from './dto/create-plan-repas.dto';
import { UpdatePlanRepasDto } from './dto/update-plan-repas.dto';
import { CreateRepasDto } from './dto/create-repas.dto';
import { UpdateRepasDto } from './dto/update-repas.dto';
import { AddRecetteToRepasDto } from './dto/add-recette-to-repas.dto';

@Injectable()
export class PlanRepasService {
  constructor(private prisma: PrismaService) {}

  // Méthodes pour PlanRepas
  async createPlanRepas(createPlanRepasDto: CreatePlanRepasDto) {
    return this.prisma.planRepas.create({
      data: createPlanRepasDto,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        repas: true,
      },
    });
  }

  async findAllPlanRepas() {
    return this.prisma.planRepas.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        repas: true,
      },
    });
  }

  async findPlanRepasByUser(userId: string) {
    return this.prisma.planRepas.findMany({
      where: {
        userId,
        deletedAt: null,
      },
      include: {
        repas: {
          include: {
            recettes: {
              include: {
                recette: true,
              },
            },
          },
        },
      },
    });
  }

  async findOnePlanRepas(id: string) {
    return this.prisma.planRepas.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        repas: {
          include: {
            recettes: {
              include: {
                recette: true,
              },
            },
          },
        },
      },
    });
  }

  async updatePlanRepas(id: string, updatePlanRepasDto: UpdatePlanRepasDto) {
    return this.prisma.planRepas.update({
      where: { id },
      data: updatePlanRepasDto,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        repas: true,
      },
    });
  }

  async removePlanRepas(id: string) {
    return this.prisma.planRepas.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }

  // Méthodes pour Repas
  async createRepas(createRepasDto: CreateRepasDto) {
    return this.prisma.repas.create({
      data: createRepasDto,
      include: {
        planRepas: true,
        recettes: {
          include: {
            recette: true,
          },
        },
      },
    });
  }

  async findAllRepas() {
    return this.prisma.repas.findMany({
      where: {
        deletedAt: null,
      },
      include: {
        planRepas: true,
        recettes: {
          include: {
            recette: true,
          },
        },
      },
    });
  }

  async findOneRepas(id: string) {
    return this.prisma.repas.findUnique({
      where: { id },
      include: {
        planRepas: true,
        recettes: {
          include: {
            recette: true,
          },
        },
      },
    });
  }

  async updateRepas(id: string, updateRepasDto: UpdateRepasDto) {
    return this.prisma.repas.update({
      where: { id },
      data: updateRepasDto,
      include: {
        planRepas: true,
        recettes: {
          include: {
            recette: true,
          },
        },
      },
    });
  }

  async removeRepas(id: string) {
    return this.prisma.repas.update({
      where: { id },
      data: {
        deletedAt: new Date(),
      },
    });
  }

  // Méthode pour ajouter une recette à un repas
  async addRecetteToRepas(repasId: string, addRecetteToRepasDto: AddRecetteToRepasDto) {
    const { recetteId, servings } = addRecetteToRepasDto;
    
    return this.prisma.recetteOnRepas.create({
      data: {
        repas: {
          connect: { id: repasId },
        },
        recette: {
          connect: { id: recetteId },
        },
        servings,
      },
      include: {
        repas: true,
        recette: true,
      },
    });
  }

  // Méthode pour supprimer une recette d'un repas
  async removeRecetteFromRepas(repasId: string, recetteId: string) {
    return this.prisma.recetteOnRepas.delete({
      where: {
        repasId_recetteId: {
          repasId,
          recetteId,
        },
      },
    });
  }
}
