import { PartialType } from '@nestjs/swagger';
import { CreateRepasDto } from './create-repas.dto';

export class UpdateRepasDto extends PartialType(CreateRepasDto) {}
