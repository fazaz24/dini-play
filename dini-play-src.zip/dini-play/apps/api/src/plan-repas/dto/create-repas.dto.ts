import { IsNotEmpty, IsString, IsDateString, IsEnum, IsUUID } from 'class-validator';
import { MealType } from '@prisma/client';

export class CreateRepasDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsDateString()
  @IsNotEmpty()
  date: string;

  @IsEnum(MealType)
  @IsNotEmpty()
  mealType: MealType;

  @IsUUID()
  @IsNotEmpty()
  planRepasId: string;
}
