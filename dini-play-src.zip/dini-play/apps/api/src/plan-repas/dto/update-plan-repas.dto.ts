import { PartialType } from '@nestjs/swagger';
import { CreatePlanRepasDto } from './create-plan-repas.dto';

export class UpdatePlanRepasDto extends PartialType(CreatePlanRepasDto) {}
