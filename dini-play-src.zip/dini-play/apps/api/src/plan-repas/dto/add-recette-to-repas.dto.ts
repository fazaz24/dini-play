import { IsNotEmpty, IsUUID, IsInt, Min } from 'class-validator';

export class AddRecetteToRepasDto {
  @IsUUID()
  @IsNotEmpty()
  recetteId: string;

  @IsInt()
  @Min(1)
  servings: number;
}
