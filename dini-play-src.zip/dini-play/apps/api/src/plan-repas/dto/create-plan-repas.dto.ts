import { IsNotEmpty, IsString, IsDateString, IsUUID } from 'class-validator';

export class CreatePlanRepasDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsDateString()
  @IsNotEmpty()
  startDate: string;

  @IsDateString()
  @IsNotEmpty()
  endDate: string;

  @IsUUID()
  @IsNotEmpty()
  userId: string;
}
