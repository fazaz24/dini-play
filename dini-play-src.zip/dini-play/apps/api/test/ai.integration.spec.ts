import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { JwtAuthGuard } from '../src/auth/guards/jwt-auth.guard';
import { AiService } from '../src/ai/ai.service';

describe('AI Integration (e2e)', () => {
  let app: INestApplication;
  let aiService: AiService;

  const mockAiService = {
    analyzeRecipe: jest.fn(),
    generateRecommendations: jest.fn(),
    generateMealPlan: jest.fn(),
    analyzeNutrition: jest.fn(),
    processChat: jest.fn(),
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideGuard(JwtAuthGuard)
      .useValue({ canActivate: () => true })
      .overrideProvider(AiService)
      .useValue(mockAiService)
      .compile();

    app = moduleFixture.createNestApplication();
    aiService = moduleFixture.get<AiService>(AiService);
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('/ai/analyze-recipe (POST)', () => {
    it('should analyze a recipe', () => {
      const recipeData = {
        title: 'Couscous aux légumes',
        ingredients: [
          { name: 'couscous', quantity: '200g' },
          { name: 'carottes', quantity: '2' },
        ],
        steps: [
          { description: 'Préparer les légumes' },
          { description: 'Cuire le couscous' },
        ],
      };

      const expectedResponse = {
        nutritionalValue: {
          calories: 350,
          protein: 10,
          carbs: 70,
          fat: 5,
        },
        cuisineOrigin: 'Afrique du Nord',
        halalCompliance: true,
        difficultyLevel: 'easy',
        preparationTime: 30,
      };

      mockAiService.analyzeRecipe.mockResolvedValue(expectedResponse);

      return request(app.getHttpServer())
        .post('/ai/analyze-recipe')
        .send(recipeData)
        .expect(201)
        .expect(expectedResponse);
    });
  });

  describe('/ai/generate-recommendations (POST)', () => {
    it('should generate recipe recommendations', () => {
      const requestData = {
        userPreferences: {
          dietaryPreferences: ['halal', 'végétarien'],
          excludedIngredients: ['porc', 'alcool'],
        },
        recentRecipes: [
          { title: 'Houmous', id: '1' },
          { title: 'Taboulé', id: '2' },
        ],
      };

      const expectedResponse = [
        {
          title: 'Couscous aux légumes',
          description: 'Un plat traditionnel nord-africain avec des légumes de saison',
          difficultyLevel: 'medium',
          preparationTime: 45,
          calories: 450,
        },
        {
          title: 'Poulet Tikka Masala',
          description: 'Un plat indien épicé avec du poulet mariné',
          difficultyLevel: 'medium',
          preparationTime: 60,
          calories: 520,
        },
      ];

      mockAiService.generateRecommendations.mockResolvedValue(expectedResponse);

      return request(app.getHttpServer())
        .post('/ai/generate-recommendations')
        .send(requestData)
        .expect(201)
        .expect(expectedResponse);
    });
  });

  describe('/ai/generate-meal-plan (POST)', () => {
    it('should generate a meal plan', () => {
      const requestData = {
        userId: 'user-123',
        duration: 3,
        preferences: {
          dietaryPreferences: ['halal'],
          maxCaloriesPerMeal: 600,
        },
      };

      const expectedResponse = {
        userId: 'user-123',
        duration: 3,
        startDate: new Date().toISOString(),
        meals: [
          {
            day: 1,
            breakfast: { title: 'Omelette aux légumes', calories: 350 },
            lunch: { title: 'Salade de quinoa', calories: 420 },
            dinner: { title: 'Saumon grillé', calories: 520 },
          },
          {
            day: 2,
            breakfast: { title: 'Porridge aux fruits', calories: 300 },
            lunch: { title: 'Wrap au poulet', calories: 480 },
            dinner: { title: 'Poulet rôti', calories: 550 },
          },
          {
            day: 3,
            breakfast: { title: 'Omelette aux légumes', calories: 350 },
            lunch: { title: 'Soupe de lentilles', calories: 380 },
            dinner: { title: 'Curry de légumes', calories: 420 },
          },
        ],
      };

      mockAiService.generateMealPlan.mockResolvedValue(expectedResponse);

      return request(app.getHttpServer())
        .post('/ai/generate-meal-plan')
        .send(requestData)
        .expect(201)
        .expect((res) => {
          // Ignorer la date exacte dans la comparaison
          const { startDate, ...rest } = res.body;
          expect(rest).toEqual({
            userId: expectedResponse.userId,
            duration: expectedResponse.duration,
            meals: expectedResponse.meals,
          });
          expect(startDate).toBeDefined();
        });
    });
  });

  describe('/ai/analyze-nutrition (POST)', () => {
    it('should analyze nutritional content', () => {
      const requestData = {
        name: 'Salade de quinoa',
        ingredients: ['quinoa', 'tomates', 'concombres', 'feta', 'huile d\'olive'],
      };

      const expectedResponse = {
        calories: 320,
        macronutrients: {
          protein: 12,
          carbs: 45,
          fat: 15,
          fiber: 8,
        },
        micronutrients: {
          vitamins: ['A', 'C', 'E'],
          minerals: ['Calcium', 'Iron'],
        },
        healthScore: 85,
      };

      mockAiService.analyzeNutrition.mockResolvedValue(expectedResponse);

      return request(app.getHttpServer())
        .post('/ai/analyze-nutrition')
        .send(requestData)
        .expect(201)
        .expect(expectedResponse);
    });
  });

  describe('/ai/chat (POST)', () => {
    it('should process chat messages', () => {
      const requestData = {
        message: 'Je cherche une recette de poulet halal',
        userId: 'user-123',
      };

      const expectedResponse = {
        response: 'Voici quelques idées de recettes halal que vous pourriez apprécier: Couscous aux légumes, Poulet Tikka Masala, ou Kebab d\'agneau. Souhaitez-vous plus de détails sur l\'une de ces recettes?',
        functionCalled: false,
      };

      mockAiService.processChat.mockResolvedValue(expectedResponse);

      return request(app.getHttpServer())
        .post('/ai/chat')
        .send(requestData)
        .expect(201)
        .expect(expectedResponse);
    });
  });
});
