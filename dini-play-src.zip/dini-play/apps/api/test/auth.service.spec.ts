import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from '../src/auth/auth.service';
import { UsersService } from '../src/users/users.service';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../src/prisma/prisma.service';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';

// Mock des services externes
jest.mock('@nestjs/jwt');
jest.mock('bcrypt');
jest.mock('../src/prisma/prisma.service');

describe('AuthService', () => {
  let authService: AuthService;
  let usersService: UsersService;
  let jwtService: JwtService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        UsersService,
        JwtService,
        PrismaService,
        ConfigService,
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
    usersService = module.get<UsersService>(UsersService);
    jwtService = module.get<JwtService>(JwtService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('validateUser', () => {
    it('should return a user object when credentials are valid', async () => {
      // Arrange
      const user = {
        id: '1',
        email: 'test@example.com',
        password: 'hashedPassword',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      };
      
      jest.spyOn(usersService, 'findByEmail').mockResolvedValue(user);
      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      // Act
      const result = await authService.validateUser('test@example.com', 'password');

      // Assert
      expect(result).toEqual({
        id: '1',
        email: 'test@example.com',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      });
      expect(usersService.findByEmail).toHaveBeenCalledWith('test@example.com');
      expect(bcrypt.compare).toHaveBeenCalledWith('password', 'hashedPassword');
    });

    it('should return null when user is not found', async () => {
      // Arrange
      jest.spyOn(usersService, 'findByEmail').mockResolvedValue(null);

      // Act
      const result = await authService.validateUser('nonexistent@example.com', 'password');

      // Assert
      expect(result).toBeNull();
      expect(usersService.findByEmail).toHaveBeenCalledWith('nonexistent@example.com');
    });

    it('should return null when password is invalid', async () => {
      // Arrange
      const user = {
        id: '1',
        email: 'test@example.com',
        password: 'hashedPassword',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      };
      
      jest.spyOn(usersService, 'findByEmail').mockResolvedValue(user);
      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      // Act
      const result = await authService.validateUser('test@example.com', 'wrongPassword');

      // Assert
      expect(result).toBeNull();
      expect(usersService.findByEmail).toHaveBeenCalledWith('test@example.com');
      expect(bcrypt.compare).toHaveBeenCalledWith('wrongPassword', 'hashedPassword');
    });
  });

  describe('login', () => {
    it('should return access token and refresh token when login is successful', async () => {
      // Arrange
      const user = {
        id: '1',
        email: 'test@example.com',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      };
      
      (jwtService.sign as jest.Mock).mockReturnValueOnce('access_token');
      (jwtService.sign as jest.Mock).mockReturnValueOnce('refresh_token');

      // Act
      const result = await authService.login(user);

      // Assert
      expect(result).toEqual({
        access_token: 'access_token',
        refresh_token: 'refresh_token',
        user: {
          id: '1',
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          role: 'USER',
        },
      });
      expect(jwtService.sign).toHaveBeenCalledTimes(2);
    });
  });

  describe('register', () => {
    it('should create a new user and return tokens when registration is successful', async () => {
      // Arrange
      const registerDto = {
        email: 'new@example.com',
        password: 'password',
        firstName: 'New',
        lastName: 'User',
      };
      
      const createdUser = {
        id: '2',
        email: 'new@example.com',
        password: 'hashedPassword',
        firstName: 'New',
        lastName: 'User',
        role: 'USER',
      };
      
      jest.spyOn(usersService, 'findByEmail').mockResolvedValue(null);
      jest.spyOn(usersService, 'create').mockResolvedValue(createdUser);
      (bcrypt.hash as jest.Mock).mockResolvedValue('hashedPassword');
      (jwtService.sign as jest.Mock).mockReturnValueOnce('access_token');
      (jwtService.sign as jest.Mock).mockReturnValueOnce('refresh_token');

      // Act
      const result = await authService.register(registerDto);

      // Assert
      expect(result).toEqual({
        access_token: 'access_token',
        refresh_token: 'refresh_token',
        user: {
          id: '2',
          email: 'new@example.com',
          firstName: 'New',
          lastName: 'User',
          role: 'USER',
        },
      });
      expect(usersService.findByEmail).toHaveBeenCalledWith('new@example.com');
      expect(bcrypt.hash).toHaveBeenCalledWith('password', 10);
      expect(usersService.create).toHaveBeenCalledWith({
        email: 'new@example.com',
        password: 'hashedPassword',
        firstName: 'New',
        lastName: 'User',
      });
    });

    it('should throw an error when user with email already exists', async () => {
      // Arrange
      const registerDto = {
        email: 'existing@example.com',
        password: 'password',
        firstName: 'Existing',
        lastName: 'User',
      };
      
      const existingUser = {
        id: '3',
        email: 'existing@example.com',
        password: 'hashedPassword',
        firstName: 'Existing',
        lastName: 'User',
        role: 'USER',
      };
      
      jest.spyOn(usersService, 'findByEmail').mockResolvedValue(existingUser);

      // Act & Assert
      await expect(authService.register(registerDto)).rejects.toThrow('User with this email already exists');
      expect(usersService.findByEmail).toHaveBeenCalledWith('existing@example.com');
    });
  });

  describe('refreshToken', () => {
    it('should return new access token when refresh token is valid', async () => {
      // Arrange
      const refreshTokenDto = {
        refreshToken: 'valid_refresh_token',
      };
      
      const decodedToken = {
        sub: '1',
        email: 'test@example.com',
      };
      
      const user = {
        id: '1',
        email: 'test@example.com',
        password: 'hashedPassword',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      };
      
      (jwtService.verify as jest.Mock).mockReturnValue(decodedToken);
      jest.spyOn(usersService, 'findOne').mockResolvedValue(user);
      (jwtService.sign as jest.Mock).mockReturnValue('new_access_token');

      // Act
      const result = await authService.refreshToken(refreshTokenDto);

      // Assert
      expect(result).toEqual({
        access_token: 'new_access_token',
      });
      expect(jwtService.verify).toHaveBeenCalledWith('valid_refresh_token', expect.any(Object));
      expect(usersService.findOne).toHaveBeenCalledWith('1');
      expect(jwtService.sign).toHaveBeenCalled();
    });

    it('should throw an error when refresh token is invalid', async () => {
      // Arrange
      const refreshTokenDto = {
        refreshToken: 'invalid_refresh_token',
      };
      
      (jwtService.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });

      // Act & Assert
      await expect(authService.refreshToken(refreshTokenDto)).rejects.toThrow('Invalid refresh token');
      expect(jwtService.verify).toHaveBeenCalledWith('invalid_refresh_token', expect.any(Object));
    });

    it('should throw an error when user not found', async () => {
      // Arrange
      const refreshTokenDto = {
        refreshToken: 'valid_refresh_token',
      };
      
      const decodedToken = {
        sub: '999',
        email: 'nonexistent@example.com',
      };
      
      (jwtService.verify as jest.Mock).mockReturnValue(decodedToken);
      jest.spyOn(usersService, 'findOne').mockResolvedValue(null);

      // Act & Assert
      await expect(authService.refreshToken(refreshTokenDto)).rejects.toThrow('User not found');
      expect(jwtService.verify).toHaveBeenCalledWith('valid_refresh_token', expect.any(Object));
      expect(usersService.findOne).toHaveBeenCalledWith('999');
    });
  });
});
