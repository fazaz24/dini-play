import { Test, TestingModule } from '@nestjs/testing';
import { PlanRepasService } from '../src/plan-repas/plan-repas.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { NotFoundException } from '@nestjs/common';

// Mock du service Prisma
jest.mock('../src/prisma/prisma.service');

describe('PlanRepasService', () => {
  let planRepasService: PlanRepasService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PlanRepasService,
        PrismaService,
      ],
    }).compile();

    planRepasService = module.get<PlanRepasService>(PlanRepasService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('findAll', () => {
    it('should return an array of plan repas', async () => {
      // Arrange
      const planRepas = [
        {
          id: '1',
          name: 'Plan hebdomadaire',
          startDate: new Date('2025-04-20'),
          endDate: new Date('2025-04-26'),
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
          repas: [],
        },
        {
          id: '2',
          name: 'Plan Ramadan',
          startDate: new Date('2025-05-01'),
          endDate: new Date('2025-05-30'),
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
          repas: [],
        },
      ];
      
      prismaService.planRepas.findMany = jest.fn().mockResolvedValue(planRepas);

      // Act
      const result = await planRepasService.findAll();

      // Assert
      expect(result).toEqual(planRepas);
      expect(prismaService.planRepas.findMany).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should return a plan repas when it exists', async () => {
      // Arrange
      const planRepas = {
        id: '1',
        name: 'Plan hebdomadaire',
        startDate: new Date('2025-04-20'),
        endDate: new Date('2025-04-26'),
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
        repas: [
          {
            id: 'repas1',
            date: new Date('2025-04-20'),
            type: 'DEJEUNER',
            planRepasId: '1',
            createdAt: new Date(),
            updatedAt: new Date(),
            recettes: [],
          },
        ],
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(planRepas);

      // Act
      const result = await planRepasService.findOne('1');

      // Assert
      expect(result).toEqual(planRepas);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: '1' },
        include: {
          repas: {
            include: {
              recettes: {
                include: {
                  recette: true,
                },
              },
            },
          },
        },
      });
    });

    it('should throw NotFoundException when plan repas does not exist', async () => {
      // Arrange
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.findOne('999')).rejects.toThrow(NotFoundException);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: '999' },
        include: {
          repas: {
            include: {
              recettes: {
                include: {
                  recette: true,
                },
              },
            },
          },
        },
      });
    });
  });

  describe('create', () => {
    it('should create and return a new plan repas', async () => {
      // Arrange
      const createPlanRepasDto = {
        name: 'Nouveau plan',
        startDate: new Date('2025-05-01'),
        endDate: new Date('2025-05-07'),
        userId: 'user1',
      };
      
      const createdPlanRepas = {
        id: '3',
        ...createPlanRepasDto,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.planRepas.create = jest.fn().mockResolvedValue(createdPlanRepas);

      // Act
      const result = await planRepasService.create(createPlanRepasDto);

      // Assert
      expect(result).toEqual(createdPlanRepas);
      expect(prismaService.planRepas.create).toHaveBeenCalledWith({
        data: createPlanRepasDto,
      });
    });
  });

  describe('update', () => {
    it('should update and return the plan repas', async () => {
      // Arrange
      const id = '1';
      const updatePlanRepasDto = {
        name: 'Plan hebdomadaire modifié',
        endDate: new Date('2025-04-27'),
      };
      
      const existingPlanRepas = {
        id: '1',
        name: 'Plan hebdomadaire',
        startDate: new Date('2025-04-20'),
        endDate: new Date('2025-04-26'),
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const updatedPlanRepas = {
        ...existingPlanRepas,
        name: 'Plan hebdomadaire modifié',
        endDate: new Date('2025-04-27'),
        updatedAt: new Date(),
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(existingPlanRepas);
      prismaService.planRepas.update = jest.fn().mockResolvedValue(updatedPlanRepas);

      // Act
      const result = await planRepasService.update(id, updatePlanRepasDto);

      // Assert
      expect(result).toEqual(updatedPlanRepas);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.planRepas.update).toHaveBeenCalledWith({
        where: { id },
        data: updatePlanRepasDto,
      });
    });

    it('should throw NotFoundException when plan repas does not exist', async () => {
      // Arrange
      const id = '999';
      const updatePlanRepasDto = {
        name: 'Updated Name',
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.update(id, updatePlanRepasDto)).rejects.toThrow(NotFoundException);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });

  describe('remove', () => {
    it('should remove and return the plan repas', async () => {
      // Arrange
      const id = '1';
      const existingPlanRepas = {
        id: '1',
        name: 'Plan hebdomadaire',
        startDate: new Date('2025-04-20'),
        endDate: new Date('2025-04-26'),
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(existingPlanRepas);
      prismaService.planRepas.delete = jest.fn().mockResolvedValue(existingPlanRepas);

      // Act
      const result = await planRepasService.remove(id);

      // Assert
      expect(result).toEqual(existingPlanRepas);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.planRepas.delete).toHaveBeenCalledWith({
        where: { id },
      });
    });

    it('should throw NotFoundException when plan repas does not exist', async () => {
      // Arrange
      const id = '999';
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.remove(id)).rejects.toThrow(NotFoundException);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });

  describe('findByUser', () => {
    it('should return plan repas for a specific user', async () => {
      // Arrange
      const userId = 'user1';
      const userPlanRepas = [
        {
          id: '1',
          name: 'Plan hebdomadaire',
          startDate: new Date('2025-04-20'),
          endDate: new Date('2025-04-26'),
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: '2',
          name: 'Plan Ramadan',
          startDate: new Date('2025-05-01'),
          endDate: new Date('2025-05-30'),
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      
      prismaService.planRepas.findMany = jest.fn().mockResolvedValue(userPlanRepas);

      // Act
      const result = await planRepasService.findByUser(userId);

      // Assert
      expect(result).toEqual(userPlanRepas);
      expect(prismaService.planRepas.findMany).toHaveBeenCalledWith({
        where: { userId },
        include: {
          repas: {
            include: {
              recettes: {
                include: {
                  recette: true,
                },
              },
            },
          },
        },
      });
    });
  });

  describe('addRepas', () => {
    it('should add a repas to a plan repas', async () => {
      // Arrange
      const planRepasId = '1';
      const createRepasDto = {
        date: new Date('2025-04-21'),
        type: 'DINER',
      };
      
      const existingPlanRepas = {
        id: '1',
        name: 'Plan hebdomadaire',
        startDate: new Date('2025-04-20'),
        endDate: new Date('2025-04-26'),
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const createdRepas = {
        id: 'repas2',
        ...createRepasDto,
        planRepasId: '1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(existingPlanRepas);
      prismaService.repas.create = jest.fn().mockResolvedValue(createdRepas);

      // Act
      const result = await planRepasService.addRepas(planRepasId, createRepasDto);

      // Assert
      expect(result).toEqual(createdRepas);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: planRepasId },
      });
      expect(prismaService.repas.create).toHaveBeenCalledWith({
        data: {
          ...createRepasDto,
          planRepas: {
            connect: { id: planRepasId },
          },
        },
      });
    });

    it('should throw NotFoundException when plan repas does not exist', async () => {
      // Arrange
      const planRepasId = '999';
      const createRepasDto = {
        date: new Date('2025-04-21'),
        type: 'DINER',
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.addRepas(planRepasId, createRepasDto)).rejects.toThrow(NotFoundException);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: planRepasId },
      });
    });
  });

  describe('addRecetteToRepas', () => {
    it('should add a recette to a repas', async () => {
      // Arrange
      const repasId = 'repas1';
      const addRecetteDto = {
        recetteId: 'recette1',
        servings: 4,
      };
      
      const existingRepas = {
        id: 'repas1',
        date: new Date('2025-04-20'),
        type: 'DEJEUNER',
        planRepasId: '1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const createdRecetteRepas = {
        id: 'recetteRepas1',
        repasId: 'repas1',
        recetteId: 'recette1',
        servings: 4,
      };
      
      prismaService.repas.findUnique = jest.fn().mockResolvedValue(existingRepas);
      prismaService.recetteRepas.create = jest.fn().mockResolvedValue(createdRecetteRepas);

      // Act
      const result = await planRepasService.addRecetteToRepas(repasId, addRecetteDto);

      // Assert
      expect(result).toEqual(createdRecetteRepas);
      expect(prismaService.repas.findUnique).toHaveBeenCalledWith({
        where: { id: repasId },
      });
      expect(prismaService.recetteRepas.create).toHaveBeenCalledWith({
        data: {
          servings: addRecetteDto.servings,
          repas: {
            connect: { id: repasId },
          },
          recette: {
            connect: { id: addRecetteDto.recetteId },
          },
        },
      });
    });

    it('should throw NotFoundException when repas does not exist', async () => {
      // Arrange
      const repasId = '999';
      const addRecetteDto = {
        recetteId: 'recette1',
        servings: 4,
      };
      
      prismaService.repas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.addRecetteToRepas(repasId, addRecetteDto)).rejects.toThrow(NotFoundException);
      expect(prismaService.repas.findUnique).toHaveBeenCalledWith({
        where: { id: repasId },
      });
    });
  });

  describe('generateShoppingList', () => {
    it('should generate a shopping list from a plan repas', async () => {
      // Arrange
      const planRepasId = '1';
      
      const planRepas = {
        id: '1',
        name: 'Plan hebdomadaire',
        startDate: new Date('2025-04-20'),
        endDate: new Date('2025-04-26'),
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
        repas: [
          {
            id: 'repas1',
            date: new Date('2025-04-20'),
            type: 'DEJEUNER',
            planRepasId: '1',
            recettes: [
              {
                id: 'recetteRepas1',
                repasId: 'repas1',
                recetteId: 'recette1',
                servings: 4,
                recette: {
                  id: 'recette1',
                  title: 'Tajine de poulet',
                  ingredients: ['poulet', 'olives', 'citron confit'],
                  // autres propriétés de la recette
                },
              },
            ],
          },
        ],
      };
      
      const shoppingList = {
        id: 'shoppingList1',
        name: 'Liste pour Plan hebdomadaire',
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
        items: [
          {
            id: 'item1',
            name: 'poulet',
            quantity: 1,
            unit: 'kg',
            category: 'Viandes',
            checked: false,
            shoppingListId: 'shoppingList1',
          },
          {
            id: 'item2',
            name: 'olives',
            quantity: 200,
            unit: 'g',
            category: 'Légumes',
            checked: false,
            shoppingListId: 'shoppingList1',
          },
          {
            id: 'item3',
            name: 'citron confit',
            quantity: 2,
            unit: 'pièce',
            category: 'Épices',
            checked: false,
            shoppingListId: 'shoppingList1',
          },
        ],
      };
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(planRepas);
      prismaService.shoppingList.create = jest.fn().mockResolvedValue(shoppingList);

      // Act
      const result = await planRepasService.generateShoppingList(planRepasId);

      // Assert
      expect(result).toEqual(shoppingList);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: planRepasId },
        include: {
          repas: {
            include: {
              recettes: {
                include: {
                  recette: true,
                },
              },
            },
          },
        },
      });
      expect(prismaService.shoppingList.create).toHaveBeenCalled();
    });

    it('should throw NotFoundException when plan repas does not exist', async () => {
      // Arrange
      const planRepasId = '999';
      
      prismaService.planRepas.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(planRepasService.generateShoppingList(planRepasId)).rejects.toThrow(NotFoundException);
      expect(prismaService.planRepas.findUnique).toHaveBeenCalledWith({
        where: { id: planRepasId },
        include: {
          repas: {
            include: {
              recettes: {
                include: {
                  recette: true,
                },
              },
            },
          },
        },
      });
    });
  });
});
