import { Test, TestingModule } from '@nestjs/testing';
import { UsersService } from '../src/users/users.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { NotFoundException, ConflictException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

// Mock du service Prisma
jest.mock('../src/prisma/prisma.service');
jest.mock('bcrypt');

describe('UsersService', () => {
  let usersService: UsersService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        PrismaService,
      ],
    }).compile();

    usersService = module.get<UsersService>(UsersService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('findAll', () => {
    it('should return an array of users', async () => {
      // Arrange
      const users = [
        {
          id: '1',
          email: 'user1@example.com',
          firstName: 'User',
          lastName: 'One',
          role: 'USER',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: '2',
          email: 'user2@example.com',
          firstName: 'User',
          lastName: 'Two',
          role: 'USER',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      
      prismaService.user.findMany = jest.fn().mockResolvedValue(users);

      // Act
      const result = await usersService.findAll();

      // Assert
      expect(result).toEqual(users);
      expect(prismaService.user.findMany).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should return a user when user exists', async () => {
      // Arrange
      const user = {
        id: '1',
        email: 'user1@example.com',
        firstName: 'User',
        lastName: 'One',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(user);

      // Act
      const result = await usersService.findOne('1');

      // Assert
      expect(result).toEqual(user);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id: '1' },
      });
    });

    it('should throw NotFoundException when user does not exist', async () => {
      // Arrange
      prismaService.user.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(usersService.findOne('999')).rejects.toThrow(NotFoundException);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id: '999' },
      });
    });
  });

  describe('findByEmail', () => {
    it('should return a user when email exists', async () => {
      // Arrange
      const user = {
        id: '1',
        email: 'user1@example.com',
        password: 'hashedPassword',
        firstName: 'User',
        lastName: 'One',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(user);

      // Act
      const result = await usersService.findByEmail('user1@example.com');

      // Assert
      expect(result).toEqual(user);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'user1@example.com' },
      });
    });

    it('should return null when email does not exist', async () => {
      // Arrange
      prismaService.user.findUnique = jest.fn().mockResolvedValue(null);

      // Act
      const result = await usersService.findByEmail('nonexistent@example.com');

      // Assert
      expect(result).toBeNull();
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'nonexistent@example.com' },
      });
    });
  });

  describe('create', () => {
    it('should create and return a new user', async () => {
      // Arrange
      const createUserDto = {
        email: 'new@example.com',
        password: 'hashedPassword',
        firstName: 'New',
        lastName: 'User',
      };
      
      const createdUser = {
        id: '3',
        email: 'new@example.com',
        password: 'hashedPassword',
        firstName: 'New',
        lastName: 'User',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(null);
      prismaService.user.create = jest.fn().mockResolvedValue(createdUser);

      // Act
      const result = await usersService.create(createUserDto);

      // Assert
      expect(result).toEqual(createdUser);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'new@example.com' },
      });
      expect(prismaService.user.create).toHaveBeenCalledWith({
        data: createUserDto,
      });
    });

    it('should throw ConflictException when email already exists', async () => {
      // Arrange
      const createUserDto = {
        email: 'existing@example.com',
        password: 'password',
        firstName: 'Existing',
        lastName: 'User',
      };
      
      const existingUser = {
        id: '4',
        email: 'existing@example.com',
        password: 'hashedPassword',
        firstName: 'Existing',
        lastName: 'User',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(existingUser);

      // Act & Assert
      await expect(usersService.create(createUserDto)).rejects.toThrow(ConflictException);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'existing@example.com' },
      });
    });
  });

  describe('update', () => {
    it('should update and return the user', async () => {
      // Arrange
      const id = '1';
      const updateUserDto = {
        firstName: 'Updated',
        lastName: 'User',
      };
      
      const existingUser = {
        id: '1',
        email: 'user1@example.com',
        password: 'hashedPassword',
        firstName: 'User',
        lastName: 'One',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const updatedUser = {
        ...existingUser,
        firstName: 'Updated',
        lastName: 'User',
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(existingUser);
      prismaService.user.update = jest.fn().mockResolvedValue(updatedUser);

      // Act
      const result = await usersService.update(id, updateUserDto);

      // Assert
      expect(result).toEqual(updatedUser);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.user.update).toHaveBeenCalledWith({
        where: { id },
        data: updateUserDto,
      });
    });

    it('should throw NotFoundException when user does not exist', async () => {
      // Arrange
      const id = '999';
      const updateUserDto = {
        firstName: 'Updated',
        lastName: 'User',
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(usersService.update(id, updateUserDto)).rejects.toThrow(NotFoundException);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });

    it('should hash password when updating password', async () => {
      // Arrange
      const id = '1';
      const updateUserDto = {
        password: 'newPassword',
      };
      
      const existingUser = {
        id: '1',
        email: 'user1@example.com',
        password: 'hashedPassword',
        firstName: 'User',
        lastName: 'One',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const updatedUser = {
        ...existingUser,
        password: 'newHashedPassword',
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(existingUser);
      prismaService.user.update = jest.fn().mockResolvedValue(updatedUser);
      (bcrypt.hash as jest.Mock).mockResolvedValue('newHashedPassword');

      // Act
      const result = await usersService.update(id, updateUserDto);

      // Assert
      expect(result).toEqual(updatedUser);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(bcrypt.hash).toHaveBeenCalledWith('newPassword', 10);
      expect(prismaService.user.update).toHaveBeenCalledWith({
        where: { id },
        data: { password: 'newHashedPassword' },
      });
    });
  });

  describe('remove', () => {
    it('should remove and return the user', async () => {
      // Arrange
      const id = '1';
      const existingUser = {
        id: '1',
        email: 'user1@example.com',
        password: 'hashedPassword',
        firstName: 'User',
        lastName: 'One',
        role: 'USER',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.user.findUnique = jest.fn().mockResolvedValue(existingUser);
      prismaService.user.delete = jest.fn().mockResolvedValue(existingUser);

      // Act
      const result = await usersService.remove(id);

      // Assert
      expect(result).toEqual(existingUser);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.user.delete).toHaveBeenCalledWith({
        where: { id },
      });
    });

    it('should throw NotFoundException when user does not exist', async () => {
      // Arrange
      const id = '999';
      prismaService.user.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(usersService.remove(id)).rejects.toThrow(NotFoundException);
      expect(prismaService.user.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });
});
