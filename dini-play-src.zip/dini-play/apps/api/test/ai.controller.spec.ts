import { Test, TestingModule } from '@nestjs/testing';
import { AiController } from '../src/ai/ai.controller';
import { AiService } from '../src/ai/ai.service';
import { JwtAuthGuard } from '../src/auth/guards/jwt-auth.guard';

describe('AiController', () => {
  let controller: AiController;
  let service: AiService;

  const mockAiService = {
    analyzeRecipe: jest.fn(),
    generateRecommendations: jest.fn(),
    generateMealPlan: jest.fn(),
    analyzeNutrition: jest.fn(),
    processChat: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AiController],
      providers: [
        {
          provide: AiService,
          useValue: mockAiService,
        },
      ],
    })
      .overrideGuard(JwtAuthGuard)
      .useValue({ canActivate: () => true })
      .compile();

    controller = module.get<AiController>(AiController);
    service = module.get<AiService>(AiService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('analyzeRecipe', () => {
    it('should call service.analyzeRecipe with the provided dto', async () => {
      const dto = {
        title: 'Couscous aux légumes',
        ingredients: [{ name: 'couscous', quantity: '200g' }],
        steps: [{ description: 'Préparer les légumes' }],
      };
      
      const expectedResult = {
        nutritionalValue: { calories: 350 },
        halalCompliance: true,
      };
      
      mockAiService.analyzeRecipe.mockResolvedValue(expectedResult);
      
      const result = await controller.analyzeRecipe(dto);
      
      expect(service.analyzeRecipe).toHaveBeenCalledWith(dto);
      expect(result).toEqual(expectedResult);
    });
  });

  describe('generateRecommendations', () => {
    it('should call service.generateRecommendations with the provided parameters', async () => {
      const userPreferences = { dietaryPreferences: ['halal'] };
      const recentRecipes = [{ title: 'Houmous' }];
      
      const expectedResult = [
        { title: 'Couscous aux légumes' },
        { title: 'Poulet Tikka Masala' },
      ];
      
      mockAiService.generateRecommendations.mockResolvedValue(expectedResult);
      
      const result = await controller.generateRecommendations(userPreferences, recentRecipes);
      
      expect(service.generateRecommendations).toHaveBeenCalledWith(userPreferences, recentRecipes);
      expect(result).toEqual(expectedResult);
    });
  });

  describe('generateMealPlan', () => {
    it('should call service.generateMealPlan with the provided dto', async () => {
      const dto = {
        userId: 'user-123',
        duration: 7,
        preferences: { dietaryPreferences: ['halal'] },
      };
      
      const expectedResult = {
        userId: 'user-123',
        duration: 7,
        meals: [],
      };
      
      mockAiService.generateMealPlan.mockResolvedValue(expectedResult);
      
      const result = await controller.generateMealPlan(dto);
      
      expect(service.generateMealPlan).toHaveBeenCalledWith(
        dto.userId,
        dto.duration,
        dto.preferences,
      );
      expect(result).toEqual(expectedResult);
    });
  });

  describe('analyzeNutrition', () => {
    it('should call service.analyzeNutrition with the provided dto', async () => {
      const dto = {
        name: 'Salade de quinoa',
        ingredients: ['quinoa', 'tomates'],
      };
      
      const expectedResult = {
        calories: 300,
        macronutrients: { protein: 10, carbs: 40, fat: 5 },
      };
      
      mockAiService.analyzeNutrition.mockResolvedValue(expectedResult);
      
      const result = await controller.analyzeNutrition(dto);
      
      expect(service.analyzeNutrition).toHaveBeenCalledWith(dto);
      expect(result).toEqual(expectedResult);
    });
  });

  describe('chat', () => {
    it('should call service.processChat with the provided dto', async () => {
      const dto = {
        message: 'Je cherche une recette de poulet halal',
        userId: 'user-123',
      };
      
      const expectedResult = {
        response: 'Voici quelques idées de recettes de poulet halal...',
        functionCalled: false,
      };
      
      mockAiService.processChat.mockResolvedValue(expectedResult);
      
      const result = await controller.chat(dto);
      
      expect(service.processChat).toHaveBeenCalledWith(dto.message, dto.userId);
      expect(result).toEqual(expectedResult);
    });
  });
});
