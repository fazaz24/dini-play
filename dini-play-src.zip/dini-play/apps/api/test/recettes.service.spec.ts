import { Test, TestingModule } from '@nestjs/testing';
import { RecettesService } from '../src/recettes/recettes.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { NotFoundException } from '@nestjs/common';

// Mock du service Prisma
jest.mock('../src/prisma/prisma.service');

describe('RecettesService', () => {
  let recettesService: RecettesService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        RecettesService,
        PrismaService,
      ],
    }).compile();

    recettesService = module.get<RecettesService>(RecettesService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('findAll', () => {
    it('should return an array of recettes', async () => {
      // Arrange
      const recettes = [
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          instructions: 'Instructions pour préparer le tajine...',
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: '2',
          title: 'Couscous aux légumes',
          description: 'Un couscous végétarien savoureux',
          ingredients: ['semoule', 'carottes', 'courgettes', 'pois chiches'],
          instructions: 'Instructions pour préparer le couscous...',
          prepTime: 20,
          cookTime: 45,
          servings: 6,
          calories: 380,
          image: 'couscous.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      
      prismaService.recette.findMany = jest.fn().mockResolvedValue(recettes);

      // Act
      const result = await recettesService.findAll();

      // Assert
      expect(result).toEqual(recettes);
      expect(prismaService.recette.findMany).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should return a recette when recette exists', async () => {
      // Arrange
      const recette = {
        id: '1',
        title: 'Tajine de poulet aux olives',
        description: 'Un plat traditionnel marocain',
        ingredients: ['poulet', 'olives', 'citron confit'],
        instructions: 'Instructions pour préparer le tajine...',
        prepTime: 30,
        cookTime: 60,
        servings: 4,
        calories: 450,
        image: 'tajine.jpg',
        category: 'PLAT_PRINCIPAL',
        cuisine: 'Marocaine',
        isHalal: true,
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(recette);

      // Act
      const result = await recettesService.findOne('1');

      // Assert
      expect(result).toEqual(recette);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id: '1' },
      });
    });

    it('should throw NotFoundException when recette does not exist', async () => {
      // Arrange
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(recettesService.findOne('999')).rejects.toThrow(NotFoundException);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id: '999' },
      });
    });
  });

  describe('create', () => {
    it('should create and return a new recette', async () => {
      // Arrange
      const createRecetteDto = {
        title: 'Houmous',
        description: 'Une purée de pois chiches crémeuse',
        ingredients: ['pois chiches', 'tahini', 'ail', 'citron'],
        instructions: 'Instructions pour préparer le houmous...',
        prepTime: 10,
        cookTime: 0,
        servings: 4,
        calories: 200,
        image: 'houmous.jpg',
        category: 'ENTREE',
        cuisine: 'Libanaise',
        isHalal: true,
        userId: 'user1',
      };
      
      const createdRecette = {
        id: '3',
        ...createRecetteDto,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.recette.create = jest.fn().mockResolvedValue(createdRecette);

      // Act
      const result = await recettesService.create(createRecetteDto);

      // Assert
      expect(result).toEqual(createdRecette);
      expect(prismaService.recette.create).toHaveBeenCalledWith({
        data: createRecetteDto,
      });
    });
  });

  describe('update', () => {
    it('should update and return the recette', async () => {
      // Arrange
      const id = '1';
      const updateRecetteDto = {
        title: 'Tajine de poulet aux olives et citrons confits',
        servings: 6,
      };
      
      const existingRecette = {
        id: '1',
        title: 'Tajine de poulet aux olives',
        description: 'Un plat traditionnel marocain',
        ingredients: ['poulet', 'olives', 'citron confit'],
        instructions: 'Instructions pour préparer le tajine...',
        prepTime: 30,
        cookTime: 60,
        servings: 4,
        calories: 450,
        image: 'tajine.jpg',
        category: 'PLAT_PRINCIPAL',
        cuisine: 'Marocaine',
        isHalal: true,
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const updatedRecette = {
        ...existingRecette,
        title: 'Tajine de poulet aux olives et citrons confits',
        servings: 6,
        updatedAt: new Date(),
      };
      
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(existingRecette);
      prismaService.recette.update = jest.fn().mockResolvedValue(updatedRecette);

      // Act
      const result = await recettesService.update(id, updateRecetteDto);

      // Assert
      expect(result).toEqual(updatedRecette);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.recette.update).toHaveBeenCalledWith({
        where: { id },
        data: updateRecetteDto,
      });
    });

    it('should throw NotFoundException when recette does not exist', async () => {
      // Arrange
      const id = '999';
      const updateRecetteDto = {
        title: 'Updated Title',
      };
      
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(recettesService.update(id, updateRecetteDto)).rejects.toThrow(NotFoundException);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });

  describe('remove', () => {
    it('should remove and return the recette', async () => {
      // Arrange
      const id = '1';
      const existingRecette = {
        id: '1',
        title: 'Tajine de poulet aux olives',
        description: 'Un plat traditionnel marocain',
        ingredients: ['poulet', 'olives', 'citron confit'],
        instructions: 'Instructions pour préparer le tajine...',
        prepTime: 30,
        cookTime: 60,
        servings: 4,
        calories: 450,
        image: 'tajine.jpg',
        category: 'PLAT_PRINCIPAL',
        cuisine: 'Marocaine',
        isHalal: true,
        userId: 'user1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(existingRecette);
      prismaService.recette.delete = jest.fn().mockResolvedValue(existingRecette);

      // Act
      const result = await recettesService.remove(id);

      // Assert
      expect(result).toEqual(existingRecette);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
      expect(prismaService.recette.delete).toHaveBeenCalledWith({
        where: { id },
      });
    });

    it('should throw NotFoundException when recette does not exist', async () => {
      // Arrange
      const id = '999';
      prismaService.recette.findUnique = jest.fn().mockResolvedValue(null);

      // Act & Assert
      await expect(recettesService.remove(id)).rejects.toThrow(NotFoundException);
      expect(prismaService.recette.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });

  describe('findByUser', () => {
    it('should return recettes for a specific user', async () => {
      // Arrange
      const userId = 'user1';
      const userRecettes = [
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          instructions: 'Instructions pour préparer le tajine...',
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: '2',
          title: 'Couscous aux légumes',
          description: 'Un couscous végétarien savoureux',
          ingredients: ['semoule', 'carottes', 'courgettes', 'pois chiches'],
          instructions: 'Instructions pour préparer le couscous...',
          prepTime: 20,
          cookTime: 45,
          servings: 6,
          calories: 380,
          image: 'couscous.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      
      prismaService.recette.findMany = jest.fn().mockResolvedValue(userRecettes);

      // Act
      const result = await recettesService.findByUser(userId);

      // Assert
      expect(result).toEqual(userRecettes);
      expect(prismaService.recette.findMany).toHaveBeenCalledWith({
        where: { userId },
      });
    });
  });

  describe('search', () => {
    it('should return recettes matching search criteria', async () => {
      // Arrange
      const searchParams = {
        query: 'poulet',
        cuisine: 'Marocaine',
        isHalal: true,
      };
      
      const matchingRecettes = [
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          instructions: 'Instructions pour préparer le tajine...',
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
          userId: 'user1',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      
      prismaService.recette.findMany = jest.fn().mockResolvedValue(matchingRecettes);

      // Act
      const result = await recettesService.search(searchParams);

      // Assert
      expect(result).toEqual(matchingRecettes);
      expect(prismaService.recette.findMany).toHaveBeenCalledWith({
        where: {
          AND: [
            {
              OR: [
                { title: { contains: 'poulet', mode: 'insensitive' } },
                { description: { contains: 'poulet', mode: 'insensitive' } },
                { ingredients: { has: 'poulet' } },
              ],
            },
            { cuisine: 'Marocaine' },
            { isHalal: true },
          ],
        },
      });
    });
  });
});
