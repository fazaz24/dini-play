import { Test, TestingModule } from '@nestjs/testing';
import { AiService } from '../src/ai/ai.service';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../src/prisma/prisma.service';

describe('AiService', () => {
  let service: AiService;
  let prismaService: PrismaService;

  const mockConfigService = {
    get: jest.fn((key: string) => {
      if (key === 'GOOGLE_AI_API_KEY') return 'test-api-key';
      if (key === 'GOOGLE_AI_MODEL') return 'gemini-2.0-flash';
      return null;
    }),
  };

  const mockPrismaService = {
    user: {
      findUnique: jest.fn(),
    },
    recette: {
      findMany: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AiService,
        { provide: ConfigService, useValue: mockConfigService },
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<AiService>(AiService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('analyzeRecipe', () => {
    it('should analyze a recipe and return nutritional information', async () => {
      const recipeData = {
        title: 'Couscous aux légumes',
        description: 'Un plat traditionnel nord-africain',
        ingredients: [
          { name: 'couscous', quantity: '200g' },
          { name: 'carottes', quantity: '2' },
          { name: 'courgettes', quantity: '2' },
          { name: 'pois chiches', quantity: '100g' },
        ],
        steps: [
          { description: 'Préparer les légumes' },
          { description: 'Cuire le couscous' },
        ],
      };

      const result = await service.analyzeRecipe(recipeData);
      
      expect(result).toBeDefined();
      expect(result.nutritionalValue).toBeDefined();
      expect(result.halalCompliance).toBeDefined();
      expect(result.difficultyLevel).toBeDefined();
      expect(result.preparationTime).toBeDefined();
    });
  });

  describe('generateRecommendations', () => {
    it('should generate recipe recommendations based on user preferences', async () => {
      const userPreferences = {
        dietaryPreferences: ['halal', 'végétarien'],
        excludedIngredients: ['porc', 'alcool'],
        preferredCuisines: ['Moyen-Orient', 'Asie du Sud'],
      };

      const recentRecipes = [
        { title: 'Houmous', id: '1' },
        { title: 'Taboulé', id: '2' },
      ];

      const result = await service.generateRecommendations(userPreferences, recentRecipes);
      
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
      expect(result[0].title).toBeDefined();
      expect(result[0].description).toBeDefined();
    });
  });

  describe('generateMealPlan', () => {
    it('should generate a meal plan based on user preferences', async () => {
      const userId = 'user-123';
      const duration = 7;
      const preferences = {
        dietaryPreferences: ['halal'],
        maxCaloriesPerMeal: 600,
      };

      const result = await service.generateMealPlan(userId, duration, preferences);
      
      expect(result).toBeDefined();
      expect(result.userId).toBe(userId);
      expect(result.duration).toBe(duration);
      expect(result.meals).toBeDefined();
      expect(Array.isArray(result.meals)).toBe(true);
      expect(result.meals.length).toBe(duration);
    });
  });

  describe('analyzeNutrition', () => {
    it('should analyze nutritional content of food data', async () => {
      const foodData = {
        name: 'Salade de quinoa',
        ingredients: ['quinoa', 'tomates', 'concombres', 'feta', 'huile d\'olive'],
      };

      const result = await service.analyzeNutrition(foodData);
      
      expect(result).toBeDefined();
      expect(result.calories).toBeDefined();
      expect(result.macronutrients).toBeDefined();
      expect(result.macronutrients.protein).toBeDefined();
      expect(result.macronutrients.carbs).toBeDefined();
      expect(result.macronutrients.fat).toBeDefined();
    });
  });

  describe('processChat', () => {
    it('should process user chat message and return appropriate response', async () => {
      const message = 'Je cherche une recette de poulet halal';
      const userId = 'user-123';

      const result = await service.processChat(message, userId);
      
      expect(result).toBeDefined();
      expect(result.response).toBeDefined();
      expect(typeof result.response).toBe('string');
      expect(result.functionCalled).toBeDefined();
    });

    it('should handle nutrition-related queries', async () => {
      const message = 'Combien de calories dans une portion de couscous?';
      const userId = 'user-123';

      const result = await service.processChat(message, userId);
      
      expect(result).toBeDefined();
      expect(result.response).toBeDefined();
      expect(result.response).toContain('nutrition');
    });
  });
});
