import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

describe('AppController (e2e)', () => {
  let app: INestApplication;
  let prismaService: PrismaService;
  let jwtService: JwtService;
  let accessToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    prismaService = moduleFixture.get<PrismaService>(PrismaService);
    jwtService = moduleFixture.get<JwtService>(JwtService);
    
    await app.init();
    
    // Créer un utilisateur de test et générer un token
    const hashedPassword = await bcrypt.hash('password123', 10);
    const testUser = await prismaService.user.create({
      data: {
        email: 'test@example.com',
        password: hashedPassword,
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
      },
    });
    
    accessToken = jwtService.sign({ 
      sub: testUser.id, 
      email: testUser.email,
      role: testUser.role
    });
  });

  afterAll(async () => {
    // Nettoyer la base de données après les tests
    await prismaService.user.deleteMany({
      where: { email: 'test@example.com' },
    });
    await app.close();
  });

  describe('Authentication', () => {
    it('/auth/login (POST) - should login successfully', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'test@example.com', password: 'password123' })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('access_token');
          expect(res.body).toHaveProperty('refresh_token');
          expect(res.body).toHaveProperty('user');
          expect(res.body.user.email).toBe('test@example.com');
        });
    });

    it('/auth/login (POST) - should fail with invalid credentials', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'test@example.com', password: 'wrongpassword' })
        .expect(401);
    });

    it('/auth/register (POST) - should register a new user', () => {
      return request(app.getHttpServer())
        .post('/auth/register')
        .send({
          email: 'newuser@example.com',
          password: 'newpassword123',
          firstName: 'New',
          lastName: 'User',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('access_token');
          expect(res.body).toHaveProperty('refresh_token');
          expect(res.body).toHaveProperty('user');
          expect(res.body.user.email).toBe('newuser@example.com');
        });
    });
  });

  describe('Users', () => {
    it('/users (GET) - should get all users with valid token', () => {
      return request(app.getHttpServer())
        .get('/users')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
          expect(res.body.length).toBeGreaterThan(0);
        });
    });

    it('/users (GET) - should fail without token', () => {
      return request(app.getHttpServer())
        .get('/users')
        .expect(401);
    });

    it('/users/profile (GET) - should get current user profile', () => {
      return request(app.getHttpServer())
        .get('/users/profile')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('email', 'test@example.com');
        });
    });

    it('/users/profile (PATCH) - should update user profile', () => {
      return request(app.getHttpServer())
        .patch('/users/profile')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ firstName: 'Updated' })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('firstName', 'Updated');
        });
    });
  });

  describe('Recettes', () => {
    let recetteId: string;

    it('/recettes (POST) - should create a new recette', () => {
      return request(app.getHttpServer())
        .post('/recettes')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({
          title: 'Test Recette',
          description: 'Une recette de test',
          ingredients: ['ingrédient 1', 'ingrédient 2'],
          instructions: 'Instructions de test',
          prepTime: 15,
          cookTime: 30,
          servings: 4,
          calories: 400,
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Test',
          isHalal: true,
          userId: 'test-user-id',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('title', 'Test Recette');
          recetteId = res.body.id;
        });
    });

    it('/recettes (GET) - should get all recettes', () => {
      return request(app.getHttpServer())
        .get('/recettes')
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
          expect(res.body.length).toBeGreaterThan(0);
        });
    });

    it('/recettes/:id (GET) - should get a specific recette', () => {
      return request(app.getHttpServer())
        .get(`/recettes/${recetteId}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('id', recetteId);
          expect(res.body).toHaveProperty('title', 'Test Recette');
        });
    });

    it('/recettes/search (GET) - should search recettes', () => {
      return request(app.getHttpServer())
        .get('/recettes/search?query=Test')
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
          expect(res.body.length).toBeGreaterThan(0);
          expect(res.body[0]).toHaveProperty('title', 'Test Recette');
        });
    });

    it('/recettes/:id (PATCH) - should update a recette', () => {
      return request(app.getHttpServer())
        .patch(`/recettes/${recetteId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ title: 'Updated Test Recette' })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('id', recetteId);
          expect(res.body).toHaveProperty('title', 'Updated Test Recette');
        });
    });

    it('/recettes/:id (DELETE) - should delete a recette', () => {
      return request(app.getHttpServer())
        .delete(`/recettes/${recetteId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);
    });
  });

  describe('Plan Repas', () => {
    let planRepasId: string;
    let repasId: string;

    it('/plan-repas (POST) - should create a new plan repas', () => {
      return request(app.getHttpServer())
        .post('/plan-repas')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({
          name: 'Test Plan',
          startDate: '2025-05-01',
          endDate: '2025-05-07',
          userId: 'test-user-id',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('name', 'Test Plan');
          planRepasId = res.body.id;
        });
    });

    it('/plan-repas (GET) - should get all plan repas', () => {
      return request(app.getHttpServer())
        .get('/plan-repas')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
          expect(res.body.length).toBeGreaterThan(0);
        });
    });

    it('/plan-repas/:id (GET) - should get a specific plan repas', () => {
      return request(app.getHttpServer())
        .get(`/plan-repas/${planRepasId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('id', planRepasId);
          expect(res.body).toHaveProperty('name', 'Test Plan');
        });
    });

    it('/plan-repas/:id/repas (POST) - should add a repas to plan', () => {
      return request(app.getHttpServer())
        .post(`/plan-repas/${planRepasId}/repas`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({
          date: '2025-05-01',
          type: 'DEJEUNER',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('type', 'DEJEUNER');
          repasId = res.body.id;
        });
    });

    it('/plan-repas/:id/shopping-list (POST) - should generate shopping list', () => {
      return request(app.getHttpServer())
        .post(`/plan-repas/${planRepasId}/shopping-list`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('name');
          expect(res.body).toHaveProperty('items');
        });
    });

    it('/plan-repas/:id (DELETE) - should delete a plan repas', () => {
      return request(app.getHttpServer())
        .delete(`/plan-repas/${planRepasId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);
    });
  });
});
