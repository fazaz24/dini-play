'use client';

import { useState } from 'react';
import Link from 'next/link';

// Composant de navigation latérale (réutilisé du dashboard)
const Sidebar = ({ activeItem }) => {
  const navItems = [
    { name: 'Tableau de bord', href: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Recettes', href: '/dashboard/recettes', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { name: 'Plan de repas', href: '/dashboard/plan-repas', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'Garde-manger', href: '/dashboard/garde-manger', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { name: 'Liste de courses', href: '/dashboard/liste-courses', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { name: 'Profil', href: '/dashboard/profil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  ];

  return (
    <div className="h-screen flex-none w-64 bg-white border-r border-gray-200">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-green-800">
          Dini <span className="text-green-600">Play</span>
        </h1>
      </div>
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`${
                activeItem === item.name
                  ? 'bg-green-50 text-green-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
            >
              <svg
                className={`${
                  activeItem === item.name ? 'text-green-500' : 'text-gray-400 group-hover:text-gray-500'
                } mr-3 flex-shrink-0 h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.name}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

// Composant d'en-tête
const Header = ({ user, title }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {user.role}
              </span>
            </div>
            <div className="ml-3 relative">
              <div className="flex items-center">
                <span className="hidden md:block mr-3 text-sm font-medium text-gray-700">
                  {user.firstName} {user.lastName}
                </span>
                <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                  {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

// Composant de carte de recette
const RecipeCard = ({ recipe }) => {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg transition-all hover:shadow-md">
      <div className="relative pb-2/3">
        <div className="h-48 bg-gray-200 w-full object-cover">
          {recipe.imageUrl && (
            <img 
              src={recipe.imageUrl} 
              alt={recipe.name} 
              className="h-full w-full object-cover"
            />
          )}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">{recipe.name}</h3>
          <div className="flex items-center">
            <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            <span className="ml-1 text-sm text-gray-600">{recipe.rating}</span>
          </div>
        </div>
        <div className="mt-2 flex items-center text-sm text-gray-500">
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
            {recipe.origin}
          </span>
          <span className="mx-2">•</span>
          <svg
            className="flex-shrink-0 mr-1 h-4 w-4 text-gray-400"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
              clipRule="evenodd"
            />
          </svg>
          {recipe.preparationTime + recipe.cookingTime} min
        </div>
        <p className="mt-2 text-sm text-gray-500 line-clamp-2">{recipe.description}</p>
        <div className="mt-3">
          <div className="flex flex-wrap gap-1">
            {recipe.tags.map((tag, index) => (
              <span 
                key={index} 
                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <div className="text-sm text-gray-500">
            <svg className="inline-block h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {recipe.calories} cal
          </div>
          <button
            type="button"
            className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Voir la recette
          </button>
        </div>
      </div>
    </div>
  );
};

// Composant de filtres
const RecipeFilters = ({ filters, setFilters }) => {
  const origins = ['Marocaine', 'Libanaise', 'Turque', 'Indienne', 'Indonésienne', 'Malaisienne'];
  const categories = ['Entrée', 'Plat principal', 'Dessert', 'Boisson', 'Snack'];
  const dietaryRestrictions = ['Végétarien', 'Sans gluten', 'Sans lactose', 'Faible en calories'];

  const handleFilterChange = (type, value) => {
    if (type === 'origin') {
      setFilters(prev => ({
        ...prev,
        origin: prev.origin.includes(value)
          ? prev.origin.filter(item => item !== value)
          : [...prev.origin, value]
      }));
    } else if (type === 'category') {
      setFilters(prev => ({
        ...prev,
        category: prev.category.includes(value)
          ? prev.category.filter(item => item !== value)
          : [...prev.category, value]
      }));
    } else if (type === 'dietary') {
      setFilters(prev => ({
        ...prev,
        dietary: prev.dietary.includes(value)
          ? prev.dietary.filter(item => item !== value)
          : [...prev.dietary, value]
      }));
    } else if (type === 'time') {
      setFilters(prev => ({
        ...prev,
        maxTime: value
      }));
    } else if (type === 'rating') {
      setFilters(prev => ({
        ...prev,
        minRating: value
      }));
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow mb-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Filtres</h3>
      
      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Origine</h4>
        <div className="flex flex-wrap gap-2">
          {origins.map(origin => (
            <button
              key={origin}
              onClick={() => handleFilterChange('origin', origin)}
              className={`px-3 py-1 rounded-full text-xs font-medium ${
                filters.origin.includes(origin)
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {origin}
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Catégorie</h4>
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => handleFilterChange('category', category)}
              className={`px-3 py-1 rounded-full text-xs font-medium ${
                filters.category.includes(category)
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Restrictions alimentaires</h4>
        <div className="flex flex-wrap gap-2">
          {dietaryRestrictions.map(restriction => (
            <button
              key={restriction}
              onClick={() => handleFilterChange('dietary', restriction)}
              className={`px-3 py-1 rounded-full text-xs font-medium ${
                filters.dietary.includes(restriction)
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {restriction}
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Temps de préparation max: {filters.maxTime} min</h4>
        <input
          type="range"
          min="10"
          max="120"
          step="5"
          value={filters.maxTime}
          onChange={(e) => handleFilterChange('time', parseInt(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
      </div>
      
      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Note minimale: {filters.minRating}</h4>
        <input
          type="range"
          min="1"
          max="5"
          step="0.5"
          value={filters.minRating}
          onChange={(e) => handleFilterChange('rating', parseFloat(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
      </div>
      
      <div className="flex justify-end">
        <button
          onClick={() => setFilters({
            origin: [],
            category: [],
            dietary: [],
            maxTime: 60,
            minRating: 3
          })}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
        >
          Réinitialiser
        </button>
      </div>
    </div>
  );
};

export default function Recettes() {
  // Données simulées pour l'utilisateur
  const [user, setUser] = useState({
    firstName: 'Mohammed',
    lastName: 'Ali',
    email: 'mohammed.ali@example.com',
    role: 'Utilisateur',
  });

  // État pour les filtres
  const [filters, setFilters] = useState({
    origin: [],
    category: [],
    dietary: [],
    maxTime: 60,
    minRating: 3
  });

  // État pour la recherche
  const [searchQuery, setSearchQuery] = useState('');

  // Données simulées pour les recettes
  const [recipes, setRecipes] = useState([
    {
      id: 1,
      name: 'Couscous aux légumes',
      description: 'Un délicieux couscous végétarien avec des légumes de saison, parfumé aux épices orientales.',
      preparationTime: 20,
      cookingTime: 40,
      rating: 4.8,
      origin: 'Marocaine',
      category: 'Plat principal',
      tags: ['Végétarien', 'Sain'],
      calories: 450,
      imageUrl: 'https://images.unsplash.com/photo-1585937421612-70a008356c36?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 2,
      name: 'Tajine d\'agneau',
      description: 'Tajine d\'agneau traditionnel avec pruneaux et amandes, mijoté lentement pour un maximum de saveurs.',
      preparationTime: 15,
      cookingTime: 90,
      rating: 4.9,
      origin: 'Marocaine',
      category: 'Plat principal',
      tags: ['Viande', 'Festif'],
      calories: 650,
      imageUrl: 'https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 3,
      name: 'Salade Fattoush',
      description: 'Salade fraîche et croquante avec du pain pita grillé, des légumes frais et une vinaigrette au sumac.',
      preparationTime: 15,
      cookingTime: 0,
      rating: 4.5,
      origin: 'Libanaise',
      category: 'Entrée',
      tags: ['Végétarien', 'Frais', 'Rapide'],
      calories: 280,
      imageUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 4,
      name: 'Poulet Tikka Masala',
      description: 'Poulet mariné dans des épices et du yaourt, grillé puis mijoté dans une sauce tomate crémeuse.',
      preparationTime: 30,
      cookingTime: 25,
      rating: 4.7,
      origin: 'Indienne',
      category: 'Plat principal',
      tags: ['Épicé', 'Viande'],
      calories: 520,
      imageUrl: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 5,
      name: 'Baklava',
      description: 'Pâtisserie feuilletée aux noix et au miel, parfumée à l\'eau de fleur d\'oranger.',
      preparationTime: 45,
      cookingTime: 35,
      rating: 4.6,
      origin: 'Turque',
      category: 'Dessert',
      tags: ['Sucré', 'Noix'],
      calories: 380,
      imageUrl: 'https://images.unsplash.com/photo-1519676867240-f03562e64548?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 6,
      name: 'Nasi Goreng',
      description: 'Riz frit indonésien avec des légumes, des épices et un œuf sur le dessus.',
      preparationTime: 10,
      cookingTime: 15,
      rating: 4.4,
      origin: 'Indonésienne',
      category: 'Plat principal',
      tags: ['Rapide', 'Épicé'],
      calories: 480,
      imageUrl: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 7,
      name: 'Rendang de bœuf',
      description: 'Bœuf mijoté lentement dans du lait de coco et un mélange d\'épices complexe.',
      preparationTime: 20,
      cookingTime: 180,
      rating: 4.9,
      origin: 'Indonésienne',
      category: 'Plat principal',
      tags: ['Viande', 'Épicé', 'Mijoté'],
      calories: 590,
      imageUrl: 'https://images.unsplash.com/photo-1535400875775-0269e7a919af?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 8,
      name: 'Tabbouleh',
      description: 'Salade de persil finement haché avec de la menthe, des tomates, des oignons et du boulgour.',
      preparationTime: 25,
      cookingTime: 0,
      rating: 4.3,
      origin: 'Libanaise',
      category: 'Entrée',
      tags: ['Végétarien', 'Frais', 'Sain'],
      calories: 220,
      imageUrl: 'https://images.unsplash.com/photo-1537729958-6cd7e5283f57?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
  ]);

  // Filtrer les recettes en fonction des filtres et de la recherche
  const filteredRecipes = recipes.filter(recipe => {
    // Filtre par origine
    if (filters.origin.length > 0 && !filters.origin.includes(recipe.origin)) {
      return false;
    }
    
    // Filtre par catégorie
    if (filters.category.length > 0 && !filters.category.includes(recipe.category)) {
      return false;
    }
    
    // Filtre par restrictions alimentaires (tags)
    if (filters.dietary.length > 0 && !filters.dietary.some(diet => recipe.tags.includes(diet))) {
      return false;
    }
    
    // Filtre par temps total
    if (recipe.preparationTime + recipe.cookingTime > filters.maxTime) {
      return false;
    }
    
    // Filtre par note minimale
    if (recipe.rating < filters.minRating) {
      return false;
    }
    
    // Filtre par recherche
    if (searchQuery && !recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !recipe.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !recipe.origin.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !recipe.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))) {
      return false;
    }
    
    return true;
  });

  // Trier les recettes par note (les mieux notées en premier)
  const sortedRecipes = [...filteredRecipes].sort((a, b) => b.rating - a.rating);

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeItem="Recettes" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} title="Recettes du monde" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div className="relative flex-1 max-w-lg mb-4 md:mb-0">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                  </svg>
                </div>
                <input
                  type="text"
                  placeholder="Rechercher des recettes..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center">
                <span className="text-sm text-gray-700">
                  {sortedRecipes.length} recettes trouvées
                </span>
              </div>
            </div>
            
            <div className="flex flex-col lg:flex-row gap-6">
              <div className="lg:w-1/4">
                <RecipeFilters filters={filters} setFilters={setFilters} />
              </div>
              
              <div className="lg:w-3/4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedRecipes.map(recipe => (
                    <RecipeCard key={recipe.id} recipe={recipe} />
                  ))}
                </div>
                
                {sortedRecipes.length === 0 && (
                  <div className="bg-white p-6 rounded-lg shadow text-center">
                    <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Aucune recette trouvée</h3>
                    <p className="mt-1 text-sm text-gray-500">Essayez de modifier vos filtres ou votre recherche.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
