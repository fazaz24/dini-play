'use client';

import { useState } from 'react';
import Link from 'next/link';

// Composant de navigation latérale (réutilisé du dashboard)
const Sidebar = ({ activeItem }) => {
  const navItems = [
    { name: 'Tableau de bord', href: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Recettes', href: '/dashboard/recettes', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { name: 'Plan de repas', href: '/dashboard/plan-repas', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'Garde-manger', href: '/dashboard/garde-manger', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { name: 'Liste de courses', href: '/dashboard/liste-courses', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { name: 'Profil', href: '/dashboard/profil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  ];

  return (
    <div className="h-screen flex-none w-64 bg-white border-r border-gray-200">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-green-800">
          Dini <span className="text-green-600">Play</span>
        </h1>
      </div>
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`${
                activeItem === item.name
                  ? 'bg-green-50 text-green-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
            >
              <svg
                className={`${
                  activeItem === item.name ? 'text-green-500' : 'text-gray-400 group-hover:text-gray-500'
                } mr-3 flex-shrink-0 h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.name}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

// Composant d'en-tête
const Header = ({ user, title }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {user.role}
              </span>
            </div>
            <div className="ml-3 relative">
              <div className="flex items-center">
                <span className="hidden md:block mr-3 text-sm font-medium text-gray-700">
                  {user.firstName} {user.lastName}
                </span>
                <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                  {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

// Composant pour un élément de liste de courses
const ShoppingItem = ({ item, onToggleCheck, onEdit, onDelete, onUpdateQuantity }) => {
  return (
    <div className={`p-3 rounded-lg border ${item.checked ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-200'} mb-2`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 pt-0.5">
            <input
              type="checkbox"
              checked={item.checked}
              onChange={() => onToggleCheck(item.id)}
              className="h-5 w-5 text-green-600 focus:ring-green-500 border-gray-300 rounded"
            />
          </div>
          <div className={`${item.checked ? 'line-through text-gray-500' : 'text-gray-900'}`}>
            <div className="flex items-center">
              <h3 className="text-sm font-medium">{item.name}</h3>
              {item.fromRecipe && (
                <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                  Recette
                </span>
              )}
              {item.urgent && !item.checked && (
                <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
                  Urgent
                </span>
              )}
            </div>
            <div className="mt-1 text-xs text-gray-500">
              {item.category}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center">
            <button 
              onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
              className="text-gray-400 hover:text-gray-500 p-1"
              disabled={item.quantity <= 1}
            >
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
              </svg>
            </button>
            <span className="mx-1 text-sm font-medium text-gray-700">
              {item.quantity} {item.unit}
            </span>
            <button 
              onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
              className="text-gray-400 hover:text-gray-500 p-1"
            >
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
            </button>
          </div>
          <button 
            onClick={() => onEdit(item)}
            className="text-gray-400 hover:text-gray-500 p-1"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
          </button>
          <button 
            onClick={() => onDelete(item.id)}
            className="text-gray-400 hover:text-red-500 p-1"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

// Composant pour le modal d'ajout/édition d'article
const ShoppingItemModal = ({ isOpen, onClose, item, onSave }) => {
  const [formData, setFormData] = useState(
    item ? { ...item } : {
      id: Date.now().toString(),
      name: '',
      category: 'Légumes',
      quantity: 1,
      unit: 'pièce',
      checked: false,
      urgent: false,
      fromRecipe: false,
      note: ''
    }
  );
  
  const categories = [
    'Légumes', 'Fruits', 'Viandes', 'Poissons', 'Produits laitiers', 
    'Céréales', 'Légumineuses', 'Épices', 'Huiles', 'Boissons', 'Autres'
  ];
  
  const units = [
    'pièce', 'g', 'kg', 'ml', 'l', 'cuillère à café', 'cuillère à soupe', 'tasse', 'bouquet', 'boîte'
  ];
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : name === 'quantity' ? parseFloat(value) : value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {item ? 'Modifier l\'article' : 'Ajouter un article'}
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Nom de l'article
              </label>
              <input
                type="text"
                name="name"
                id="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                Catégorie
              </label>
              <select
                name="category"
                id="category"
                required
                value={formData.category}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">
                  Quantité
                </label>
                <input
                  type="number"
                  name="quantity"
                  id="quantity"
                  min="0.1"
                  step="0.1"
                  required
                  value={formData.quantity}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                />
              </div>
              
              <div>
                <label htmlFor="unit" className="block text-sm font-medium text-gray-700">
                  Unité
                </label>
                <select
                  name="unit"
                  id="unit"
                  required
                  value={formData.unit}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                >
                  {units.map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label htmlFor="note" className="block text-sm font-medium text-gray-700">
                Note (optionnel)
              </label>
              <textarea
                name="note"
                id="note"
                rows="2"
                value={formData.note}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Ex: Préférer bio, marque spécifique, etc."
              ></textarea>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                name="urgent"
                id="urgent"
                checked={formData.urgent}
                onChange={handleChange}
                className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
              />
              <label htmlFor="urgent" className="ml-2 block text-sm text-gray-700">
                Marquer comme urgent
              </label>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour les statistiques de la liste de courses
const ShoppingStats = ({ items }) => {
  // Calculer les statistiques
  const totalItems = items.length;
  const checkedItems = items.filter(item => item.checked).length;
  const urgentItems = items.filter(item => item.urgent && !item.checked).length;
  const progress = totalItems > 0 ? Math.round((checkedItems / totalItems) * 100) : 0;
  
  // Calculer les catégories les plus représentées
  const categoryCounts = items.reduce((acc, item) => {
    if (!item.checked) {
      acc[item.category] = (acc[item.category] || 0) + 1;
    }
    return acc;
  }, {});
  
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([category, count]) => ({ category, count }));
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Progression</h3>
      
      <div className="mb-4">
        <div className="flex justify-between text-sm text-gray-700">
          <span>{checkedItems} sur {totalItems} articles</span>
          <span>{progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
          <div 
            className="bg-green-600 h-2.5 rounded-full" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-50 p-3 rounded-md text-center">
          <div className="text-sm text-gray-500">Restants</div>
          <div className="text-2xl font-semibold text-gray-900">{totalItems - checkedItems}</div>
        </div>
        
        <div className="bg-red-50 p-3 rounded-md text-center">
          <div className="text-sm text-red-500">Urgents</div>
          <div className="text-2xl font-semibold text-red-600">{urgentItems}</div>
        </div>
      </div>
      
      {topCategories.length > 0 && (
        <>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Catégories principales</h4>
          
          <div className="space-y-2">
            {topCategories.map(({ category, count }) => (
              <div key={category}>
                <div className="flex justify-between text-sm">
                  <span>{category}</span>
                  <span>{count} articles</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                  <div 
                    className="bg-green-500 h-2 rounded-full" 
                    style={{ width: `${(count / (totalItems - checkedItems)) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

// Composant pour les actions rapides
const QuickActions = ({ onGenerateFromPlan, onShareList, onClearChecked }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Actions rapides</h3>
      
      <div className="space-y-3">
        <button
          onClick={onGenerateFromPlan}
          className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          Générer depuis le plan
        </button>
        
        <button
          onClick={onShareList}
          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
          </svg>
          Partager la liste
        </button>
        
        <button
          onClick={onClearChecked}
          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
          Effacer les articles cochés
        </button>
      </div>
    </div>
  );
};

export default function ListeCourses() {
  // Données simulées pour l'utilisateur
  const [user, setUser] = useState({
    firstName: 'Mohammed',
    lastName: 'Ali',
    email: 'mohammed.ali@example.com',
    role: 'Utilisateur',
  });
  
  // État pour les listes de courses
  const [lists, setLists] = useState([
    { id: '1', name: 'Liste principale', isActive: true },
    { id: '2', name: 'Liste spéciale Ramadan', isActive: false },
  ]);
  
  // État pour les articles de la liste active
  const [items, setItems] = useState([
    {
      id: '1',
      name: 'Tomates',
      category: 'Légumes',
      quantity: 6,
      unit: 'pièce',
      checked: false,
      urgent: false,
      fromRecipe: true,
      note: 'Bien mûres'
    },
    {
      id: '2',
      name: 'Poulet',
      category: 'Viandes',
      quantity: 1,
      unit: 'kg',
      checked: false,
      urgent: true,
      fromRecipe: true,
      note: 'Halal'
    },
    {
      id: '3',
      name: 'Yaourt nature',
      category: 'Produits laitiers',
      quantity: 4,
      unit: 'pièce',
      checked: false,
      urgent: true,
      fromRecipe: true,
      note: ''
    },
    {
      id: '4',
      name: 'Garam masala',
      category: 'Épices',
      quantity: 50,
      unit: 'g',
      checked: false,
      urgent: false,
      fromRecipe: true,
      note: ''
    },
    {
      id: '5',
      name: 'Pain pita',
      category: 'Céréales',
      quantity: 6,
      unit: 'pièce',
      checked: true,
      urgent: false,
      fromRecipe: false,
      note: ''
    },
    {
      id: '6',
      name: 'Lait',
      category: 'Produits laitiers',
      quantity: 2,
      unit: 'l',
      checked: true,
      urgent: false,
      fromRecipe: false,
      note: 'Demi-écrémé'
    },
    {
      id: '7',
      name: 'Oignons',
      category: 'Légumes',
      quantity: 1,
      unit: 'kg',
      checked: false,
      urgent: false,
      fromRecipe: false,
      note: ''
    },
    {
      id: '8',
      name: 'Riz basmati',
      category: 'Céréales',
      quantity: 1,
      unit: 'kg',
      checked: false,
      urgent: false,
      fromRecipe: false,
      note: ''
    }
  ]);
  
  // État pour le modal d'ajout/édition d'article
  const [modalOpen, setModalOpen] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);
  
  // État pour la recherche et le filtrage
  const [searchQuery, setSearchQuery] = useState('');
  const [showChecked, setShowChecked] = useState(true);
  const [activeListId, setActiveListId] = useState('1');
  
  // Filtrer les articles
  const filteredItems = items.filter(item => {
    // Filtre par recherche
    if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filtre pour les articles cochés
    if (!showChecked && item.checked) {
      return false;
    }
    
    return true;
  });
  
  // Trier les articles: d'abord les urgents, puis les non cochés, puis les cochés
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (a.checked && !b.checked) return 1;
    if (!a.checked && b.checked) return -1;
    if (a.urgent && !b.urgent) return -1;
    if (!a.urgent && b.urgent) return 1;
    return a.category.localeCompare(b.category) || a.name.localeCompare(b.name);
  });
  
  // Fonction pour ouvrir le modal d'ajout d'article
  const handleAddItem = () => {
    setCurrentItem(null);
    setModalOpen(true);
  };
  
  // Fonction pour ouvrir le modal d'édition d'article
  const handleEditItem = (item) => {
    setCurrentItem(item);
    setModalOpen(true);
  };
  
  // Fonction pour supprimer un article
  const handleDeleteItem = (itemId) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet article ?')) {
      setItems(items.filter(item => item.id !== itemId));
    }
  };
  
  // Fonction pour mettre à jour la quantité d'un article
  const handleUpdateQuantity = (itemId, newQuantity) => {
    setItems(items.map(item => 
      item.id === itemId ? { ...item, quantity: newQuantity } : item
    ));
  };
  
  // Fonction pour cocher/décocher un article
  const handleToggleCheck = (itemId) => {
    setItems(items.map(item => 
      item.id === itemId ? { ...item, checked: !item.checked } : item
    ));
  };
  
  // Fonction pour sauvegarder un article (ajout ou édition)
  const handleSaveItem = (itemData) => {
    if (currentItem) {
      // Édition d'un article existant
      setItems(items.map(item => item.id === itemData.id ? itemData : item));
    } else {
      // Ajout d'un nouvel article
      setItems([...items, itemData]);
    }
  };
  
  // Fonction pour générer une liste depuis le plan de repas
  const handleGenerateFromPlan = () => {
    alert('Liste générée avec succès à partir du plan de repas !');
  };
  
  // Fonction pour partager la liste
  const handleShareList = () => {
    alert('Fonctionnalité de partage de liste en cours de développement.');
  };
  
  // Fonction pour effacer les articles cochés
  const handleClearChecked = () => {
    if (confirm('Êtes-vous sûr de vouloir supprimer tous les articles cochés ?')) {
      setItems(items.filter(item => !item.checked));
    }
  };
  
  // Fonction pour changer de liste active
  const handleChangeList = (listId) => {
    setActiveListId(listId);
    setLists(lists.map(list => ({
      ...list,
      isActive: list.id === listId
    })));
  };
  
  // Fonction pour créer une nouvelle liste
  const handleCreateList = () => {
    const listName = prompt('Nom de la nouvelle liste :');
    if (listName) {
      const newList = {
        id: Date.now().toString(),
        name: listName,
        isActive: false
      };
      setLists([...lists, newList]);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeItem="Liste de courses" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} title="Liste de courses" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row gap-6">
              <div className="lg:w-3/4">
                <div className="bg-white rounded-lg shadow mb-6">
                  <div className="p-4 border-b border-gray-200">
                    <div className="flex flex-wrap items-center gap-2 mb-4">
                      {lists.map(list => (
                        <button
                          key={list.id}
                          onClick={() => handleChangeList(list.id)}
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            list.isActive
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                          }`}
                        >
                          {list.name}
                        </button>
                      ))}
                      <button
                        onClick={handleCreateList}
                        className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800 hover:bg-gray-200"
                      >
                        <svg className="h-4 w-4 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Nouvelle liste
                      </button>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="relative flex-1">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <svg className="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <input
                          type="text"
                          placeholder="Rechercher des articles..."
                          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                      
                      <button
                        onClick={handleAddItem}
                        className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                      >
                        <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Ajouter un article
                      </button>
                    </div>
                  </div>
                  
                  <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center">
                      <input
                        id="showChecked"
                        type="checkbox"
                        checked={showChecked}
                        onChange={(e) => setShowChecked(e.target.checked)}
                        className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label htmlFor="showChecked" className="ml-2 block text-sm text-gray-700">
                        Afficher les articles cochés
                      </label>
                    </div>
                    
                    <span className="text-sm text-gray-500">
                      {items.filter(item => !item.checked).length} articles restants
                    </span>
                  </div>
                  
                  <div className="p-4">
                    <div className="space-y-2">
                      {sortedItems.length > 0 ? (
                        sortedItems.map(item => (
                          <ShoppingItem
                            key={item.id}
                            item={item}
                            onToggleCheck={handleToggleCheck}
                            onEdit={handleEditItem}
                            onDelete={handleDeleteItem}
                            onUpdateQuantity={handleUpdateQuantity}
                          />
                        ))
                      ) : (
                        <div className="bg-gray-50 p-6 rounded-lg text-center">
                          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          <h3 className="mt-2 text-sm font-medium text-gray-900">Aucun article trouvé</h3>
                          <p className="mt-1 text-sm text-gray-500">Ajoutez des articles à votre liste de courses ou modifiez vos filtres.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="lg:w-1/4 space-y-6">
                <ShoppingStats items={items} />
                <QuickActions
                  onGenerateFromPlan={handleGenerateFromPlan}
                  onShareList={handleShareList}
                  onClearChecked={handleClearChecked}
                />
              </div>
            </div>
          </div>
        </main>
      </div>
      
      {/* Modal pour ajouter/éditer un article */}
      <ShoppingItemModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        item={currentItem}
        onSave={handleSaveItem}
      />
    </div>
  );
}
