'use client';

import { useState } from 'react';
import Link from 'next/link';

// Composant de navigation latérale (réutilisé du dashboard)
const Sidebar = ({ activeItem }) => {
  const navItems = [
    { name: 'Tableau de bord', href: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Recettes', href: '/dashboard/recettes', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { name: 'Plan de repas', href: '/dashboard/plan-repas', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'Garde-manger', href: '/dashboard/garde-manger', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { name: 'Liste de courses', href: '/dashboard/liste-courses', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { name: 'Profil', href: '/dashboard/profil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  ];

  return (
    <div className="h-screen flex-none w-64 bg-white border-r border-gray-200">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-green-800">
          Dini <span className="text-green-600">Play</span>
        </h1>
      </div>
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`${
                activeItem === item.name
                  ? 'bg-green-50 text-green-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
            >
              <svg
                className={`${
                  activeItem === item.name ? 'text-green-500' : 'text-gray-400 group-hover:text-gray-500'
                } mr-3 flex-shrink-0 h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.name}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

// Composant d'en-tête
const Header = ({ user, title }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {user.role}
              </span>
            </div>
            <div className="ml-3 relative">
              <div className="flex items-center">
                <span className="hidden md:block mr-3 text-sm font-medium text-gray-700">
                  {user.firstName} {user.lastName}
                </span>
                <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                  {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

// Composant pour afficher un repas dans le calendrier
const MealItem = ({ meal, onEdit, onDelete }) => {
  return (
    <div className="p-2 bg-white rounded-md shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <h4 className="font-medium text-gray-900">{meal.name}</h4>
        <div className="flex space-x-1">
          <button 
            onClick={() => onEdit(meal)}
            className="text-gray-400 hover:text-gray-500"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
          </button>
          <button 
            onClick={() => onDelete(meal.id)}
            className="text-gray-400 hover:text-red-500"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
      <div className="mt-1 text-sm text-gray-500">
        <div className="flex items-center">
          <svg className="h-4 w-4 mr-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          {meal.time}
        </div>
      </div>
      <div className="mt-2">
        {meal.recipes.map((recipe, index) => (
          <div key={index} className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded mb-1">
            {recipe.name} ({recipe.servings} {recipe.servings > 1 ? 'portions' : 'portion'})
          </div>
        ))}
      </div>
      <div className="mt-2 text-xs text-gray-500">
        {meal.calories} calories
      </div>
    </div>
  );
};

// Composant pour afficher un jour dans le calendrier
const DayColumn = ({ day, meals, onAddMeal, onEditMeal, onDeleteMeal }) => {
  const dayNames = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  const dayName = dayNames[day.getDay()];
  const isToday = new Date().toDateString() === day.toDateString();
  
  // Filtrer les repas pour ce jour
  const dayMeals = meals.filter(meal => {
    const mealDate = new Date(meal.date);
    return mealDate.toDateString() === day.toDateString();
  });
  
  // Trier les repas par heure
  const sortedMeals = [...dayMeals].sort((a, b) => {
    const timeA = a.time.split(':').map(Number);
    const timeB = b.time.split(':').map(Number);
    return (timeA[0] * 60 + timeA[1]) - (timeB[0] * 60 + timeB[1]);
  });

  return (
    <div className="flex flex-col h-full min-w-[200px]">
      <div className={`p-2 text-center font-medium ${isToday ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
        <div>{dayName}</div>
        <div className="text-sm">{day.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</div>
      </div>
      <div className="flex-1 p-2 space-y-2 bg-gray-50 overflow-y-auto">
        {sortedMeals.map(meal => (
          <MealItem 
            key={meal.id} 
            meal={meal} 
            onEdit={onEditMeal} 
            onDelete={onDeleteMeal} 
          />
        ))}
        <button
          onClick={() => onAddMeal(day)}
          className="w-full p-2 border border-dashed border-gray-300 rounded-md text-sm text-gray-500 hover:text-gray-700 hover:border-gray-400 flex items-center justify-center"
        >
          <svg className="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Ajouter un repas
        </button>
      </div>
    </div>
  );
};

// Composant pour le modal d'ajout/édition de repas
const MealModal = ({ isOpen, onClose, meal, date, onSave }) => {
  const [formData, setFormData] = useState(
    meal ? { ...meal } : {
      id: Date.now().toString(),
      name: '',
      date: date ? date.toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      time: '12:00',
      recipes: [],
      calories: 0
    }
  );
  
  const [selectedRecipe, setSelectedRecipe] = useState('');
  const [servings, setServings] = useState(1);
  
  // Données simulées pour les recettes disponibles
  const availableRecipes = [
    { id: '1', name: 'Couscous aux légumes', calories: 450 },
    { id: '2', name: 'Tajine d\'agneau', calories: 650 },
    { id: '3', name: 'Salade Fattoush', calories: 280 },
    { id: '4', name: 'Poulet Tikka Masala', calories: 520 },
    { id: '5', name: 'Baklava', calories: 380 },
    { id: '6', name: 'Nasi Goreng', calories: 480 },
    { id: '7', name: 'Rendang de bœuf', calories: 590 },
    { id: '8', name: 'Tabbouleh', calories: 220 },
  ];
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const addRecipe = () => {
    if (!selectedRecipe) return;
    
    const recipe = availableRecipes.find(r => r.id === selectedRecipe);
    if (!recipe) return;
    
    const newRecipe = {
      id: recipe.id,
      name: recipe.name,
      servings: servings,
      calories: recipe.calories * servings
    };
    
    const updatedRecipes = [...formData.recipes, newRecipe];
    const totalCalories = updatedRecipes.reduce((sum, r) => sum + r.calories, 0);
    
    setFormData(prev => ({
      ...prev,
      recipes: updatedRecipes,
      calories: totalCalories
    }));
    
    setSelectedRecipe('');
    setServings(1);
  };
  
  const removeRecipe = (recipeId) => {
    const updatedRecipes = formData.recipes.filter(r => r.id !== recipeId);
    const totalCalories = updatedRecipes.reduce((sum, r) => sum + r.calories, 0);
    
    setFormData(prev => ({
      ...prev,
      recipes: updatedRecipes,
      calories: totalCalories
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {meal ? 'Modifier le repas' : 'Ajouter un repas'}
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Nom du repas
              </label>
              <input
                type="text"
                name="name"
                id="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                  Date
                </label>
                <input
                  type="date"
                  name="date"
                  id="date"
                  required
                  value={formData.date}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                />
              </div>
              
              <div>
                <label htmlFor="time" className="block text-sm font-medium text-gray-700">
                  Heure
                </label>
                <input
                  type="time"
                  name="time"
                  id="time"
                  required
                  value={formData.time}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Recettes
              </label>
              
              <div className="space-y-2 mb-4">
                {formData.recipes.map((recipe) => (
                  <div key={recipe.id} className="flex justify-between items-center p-2 bg-gray-50 rounded-md">
                    <div>
                      <div className="font-medium text-sm">{recipe.name}</div>
                      <div className="text-xs text-gray-500">
                        {recipe.servings} {recipe.servings > 1 ? 'portions' : 'portion'} • {recipe.calories} calories
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeRecipe(recipe.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
              
              <div className="flex space-x-2">
                <select
                  value={selectedRecipe}
                  onChange={(e) => setSelectedRecipe(e.target.value)}
                  className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                >
                  <option value="">Sélectionner une recette</option>
                  {availableRecipes.map(recipe => (
                    <option key={recipe.id} value={recipe.id}>
                      {recipe.name} ({recipe.calories} cal/portion)
                    </option>
                  ))}
                </select>
                
                <input
                  type="number"
                  min="1"
                  value={servings}
                  onChange={(e) => setServings(parseInt(e.target.value))}
                  className="block w-20 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                  placeholder="Portions"
                />
                
                <button
                  type="button"
                  onClick={addRecipe}
                  disabled={!selectedRecipe}
                  className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                >
                  Ajouter
                </button>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center">
                <label className="block text-sm font-medium text-gray-700">
                  Total calories
                </label>
                <span className="text-lg font-semibold text-gray-900">{formData.calories}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour les statistiques nutritionnelles
const NutritionStats = ({ meals }) => {
  // Calculer les statistiques nutritionnelles pour la semaine
  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0);
  const avgCaloriesPerDay = Math.round(totalCalories / 7);
  
  // Données simulées pour les macronutriments
  const macros = {
    proteins: Math.round(totalCalories * 0.25 / 4), // 25% des calories, 4 cal/g
    carbs: Math.round(totalCalories * 0.5 / 4),     // 50% des calories, 4 cal/g
    fats: Math.round(totalCalories * 0.25 / 9)      // 25% des calories, 9 cal/g
  };
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Statistiques nutritionnelles</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-50 p-3 rounded-md">
          <div className="text-sm text-gray-500">Calories totales</div>
          <div className="text-2xl font-semibold text-gray-900">{totalCalories}</div>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-md">
          <div className="text-sm text-gray-500">Moyenne par jour</div>
          <div className="text-2xl font-semibold text-gray-900">{avgCaloriesPerDay}</div>
        </div>
      </div>
      
      <h4 className="text-sm font-medium text-gray-700 mb-2">Macronutriments (semaine)</h4>
      
      <div className="space-y-2">
        <div>
          <div className="flex justify-between text-sm">
            <span>Protéines</span>
            <span>{macros.proteins}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
            <div className="bg-blue-500 h-2 rounded-full" style={{ width: '25%' }}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm">
            <span>Glucides</span>
            <span>{macros.carbs}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
            <div className="bg-green-500 h-2 rounded-full" style={{ width: '50%' }}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm">
            <span>Lipides</span>
            <span>{macros.fats}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
            <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '25%' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Composant pour les actions rapides
const QuickActions = ({ onGenerateShoppingList, onGenerateMealPlan }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Actions rapides</h3>
      
      <div className="space-y-3">
        <button
          onClick={onGenerateShoppingList}
          className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
          </svg>
          Générer liste de courses
        </button>
        
        <button
          onClick={onGenerateMealPlan}
          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          Générer plan de repas
        </button>
      </div>
    </div>
  );
};

export default function PlanRepas() {
  // Données simulées pour l'utilisateur
  const [user, setUser] = useState({
    firstName: 'Mohammed',
    lastName: 'Ali',
    email: 'mohammed.ali@example.com',
    role: 'Utilisateur',
  });
  
  // État pour les repas
  const [meals, setMeals] = useState([
    {
      id: '1',
      name: 'Petit déjeuner',
      date: '2025-04-26',
      time: '08:00',
      recipes: [
        { id: '8', name: 'Tabbouleh', servings: 1, calories: 220 }
      ],
      calories: 220
    },
    {
      id: '2',
      name: 'Déjeuner',
      date: '2025-04-26',
      time: '12:30',
      recipes: [
        { id: '3', name: 'Salade Fattoush', servings: 1, calories: 280 },
        { id: '5', name: 'Baklava', servings: 1, calories: 380 }
      ],
      calories: 660
    },
    {
      id: '3',
      name: 'Dîner',
      date: '2025-04-26',
      time: '19:00',
      recipes: [
        { id: '4', name: 'Poulet Tikka Masala', servings: 2, calories: 1040 }
      ],
      calories: 1040
    },
    {
      id: '4',
      name: 'Petit déjeuner',
      date: '2025-04-27',
      time: '08:30',
      recipes: [
        { id: '8', name: 'Tabbouleh', servings: 1, calories: 220 }
      ],
      calories: 220
    },
    {
      id: '5',
      name: 'Déjeuner',
      date: '2025-04-27',
      time: '13:00',
      recipes: [
        { id: '1', name: 'Couscous aux légumes', servings: 1, calories: 450 }
      ],
      calories: 450
    },
    {
      id: '6',
      name: 'Dîner',
      date: '2025-04-27',
      time: '20:00',
      recipes: [
        { id: '6', name: 'Nasi Goreng', servings: 1, calories: 480 }
      ],
      calories: 480
    },
    {
      id: '7',
      name: 'Petit déjeuner',
      date: '2025-04-28',
      time: '07:45',
      recipes: [
        { id: '8', name: 'Tabbouleh', servings: 1, calories: 220 }
      ],
      calories: 220
    },
    {
      id: '8',
      name: 'Déjeuner',
      date: '2025-04-28',
      time: '12:00',
      recipes: [
        { id: '2', name: 'Tajine d\'agneau', servings: 1, calories: 650 }
      ],
      calories: 650
    }
  ]);
  
  // État pour le modal d'ajout/édition de repas
  const [modalOpen, setModalOpen] = useState(false);
  const [currentMeal, setCurrentMeal] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  
  // État pour la semaine courante
  const [currentWeek, setCurrentWeek] = useState(getWeekDays(new Date()));
  
  // Fonction pour obtenir les jours de la semaine
  function getWeekDays(date) {
    const day = date.getDay(); // 0 = dimanche, 1 = lundi, etc.
    const diff = date.getDate() - day; // Ajustement pour commencer par dimanche
    
    const weekDays = [];
    for (let i = 0; i < 7; i++) {
      const newDate = new Date(date);
      newDate.setDate(diff + i);
      weekDays.push(newDate);
    }
    
    return weekDays;
  }
  
  // Fonction pour passer à la semaine précédente
  const goToPreviousWeek = () => {
    const firstDayOfCurrentWeek = currentWeek[0];
    const firstDayOfPreviousWeek = new Date(firstDayOfCurrentWeek);
    firstDayOfPreviousWeek.setDate(firstDayOfCurrentWeek.getDate() - 7);
    setCurrentWeek(getWeekDays(firstDayOfPreviousWeek));
  };
  
  // Fonction pour passer à la semaine suivante
  const goToNextWeek = () => {
    const firstDayOfCurrentWeek = currentWeek[0];
    const firstDayOfNextWeek = new Date(firstDayOfCurrentWeek);
    firstDayOfNextWeek.setDate(firstDayOfCurrentWeek.getDate() + 7);
    setCurrentWeek(getWeekDays(firstDayOfNextWeek));
  };
  
  // Fonction pour revenir à la semaine courante
  const goToCurrentWeek = () => {
    setCurrentWeek(getWeekDays(new Date()));
  };
  
  // Fonction pour ouvrir le modal d'ajout de repas
  const handleAddMeal = (date) => {
    setCurrentMeal(null);
    setSelectedDate(date);
    setModalOpen(true);
  };
  
  // Fonction pour ouvrir le modal d'édition de repas
  const handleEditMeal = (meal) => {
    setCurrentMeal(meal);
    setSelectedDate(null);
    setModalOpen(true);
  };
  
  // Fonction pour supprimer un repas
  const handleDeleteMeal = (mealId) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce repas ?')) {
      setMeals(meals.filter(meal => meal.id !== mealId));
    }
  };
  
  // Fonction pour sauvegarder un repas (ajout ou édition)
  const handleSaveMeal = (mealData) => {
    if (currentMeal) {
      // Édition d'un repas existant
      setMeals(meals.map(meal => meal.id === mealData.id ? mealData : meal));
    } else {
      // Ajout d'un nouveau repas
      setMeals([...meals, mealData]);
    }
  };
  
  // Fonction pour générer une liste de courses
  const handleGenerateShoppingList = () => {
    alert('Liste de courses générée avec succès ! Vous pouvez la consulter dans la section "Liste de courses".');
  };
  
  // Fonction pour générer un plan de repas
  const handleGenerateMealPlan = () => {
    alert('Fonctionnalité de génération automatique de plan de repas en cours de développement.');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeItem="Plan de repas" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} title="Planification des repas" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row gap-6">
              <div className="lg:w-3/4">
                <div className="bg-white rounded-lg shadow mb-6">
                  <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={goToPreviousWeek}
                        className="p-1 rounded-full hover:bg-gray-100"
                      >
                        <svg className="h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                        </svg>
                      </button>
                      
                      <span className="text-sm font-medium text-gray-900">
                        {currentWeek[0].toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })} - {currentWeek[6].toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                      
                      <button
                        onClick={goToNextWeek}
                        className="p-1 rounded-full hover:bg-gray-100"
                      >
                        <svg className="h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </button>
                    </div>
                    
                    <button
                      onClick={goToCurrentWeek}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Aujourd'hui
                    </button>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <div className="flex min-w-full p-4 space-x-4">
                      {currentWeek.map((day, index) => (
                        <DayColumn
                          key={index}
                          day={day}
                          meals={meals}
                          onAddMeal={handleAddMeal}
                          onEditMeal={handleEditMeal}
                          onDeleteMeal={handleDeleteMeal}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="lg:w-1/4 space-y-6">
                <NutritionStats meals={meals} />
                <QuickActions
                  onGenerateShoppingList={handleGenerateShoppingList}
                  onGenerateMealPlan={handleGenerateMealPlan}
                />
              </div>
            </div>
          </div>
        </main>
      </div>
      
      {/* Modal pour ajouter/éditer un repas */}
      <MealModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        meal={currentMeal}
        date={selectedDate}
        onSave={handleSaveMeal}
      />
    </div>
  );
}
