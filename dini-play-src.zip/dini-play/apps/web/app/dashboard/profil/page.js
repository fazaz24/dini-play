'use client';

import { useState } from 'react';
import Link from 'next/link';

// Composant de navigation latérale (réutilisé du dashboard)
const Sidebar = ({ activeItem }) => {
  const navItems = [
    { name: 'Tableau de bord', href: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Recettes', href: '/dashboard/recettes', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { name: 'Plan de repas', href: '/dashboard/plan-repas', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'Garde-manger', href: '/dashboard/garde-manger', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { name: 'Liste de courses', href: '/dashboard/liste-courses', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { name: 'Profil', href: '/dashboard/profil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  ];

  return (
    <div className="h-screen flex-none w-64 bg-white border-r border-gray-200">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-green-800">
          Dini <span className="text-green-600">Play</span>
        </h1>
      </div>
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`${
                activeItem === item.name
                  ? 'bg-green-50 text-green-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
            >
              <svg
                className={`${
                  activeItem === item.name ? 'text-green-500' : 'text-gray-400 group-hover:text-gray-500'
                } mr-3 flex-shrink-0 h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.name}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

// Composant d'en-tête
const Header = ({ user, title }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {user.role}
              </span>
            </div>
            <div className="ml-3 relative">
              <div className="flex items-center">
                <span className="hidden md:block mr-3 text-sm font-medium text-gray-700">
                  {user.firstName} {user.lastName}
                </span>
                <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                  {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

// Composant pour la section d'informations personnelles
const PersonalInfoSection = ({ user, onEdit }) => {
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <div>
          <h3 className="text-lg leading-6 font-medium text-gray-900">Informations personnelles</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Détails et préférences du profil</p>
        </div>
        <button
          onClick={onEdit}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
          </svg>
          Modifier
        </button>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Nom complet</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.firstName} {user.lastName}</dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Email</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.email}</dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Téléphone</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.phone || 'Non renseigné'}</dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Rôle</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.role}</dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Date d'inscription</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{new Date(user.createdAt).toLocaleDateString('fr-FR')}</dd>
          </div>
        </dl>
      </div>
    </div>
  );
};

// Composant pour la section des préférences alimentaires
const DietaryPreferencesSection = ({ preferences, onEdit }) => {
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <div>
          <h3 className="text-lg leading-6 font-medium text-gray-900">Préférences alimentaires</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Vos restrictions et préférences pour les recettes</p>
        </div>
        <button
          onClick={onEdit}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
          </svg>
          Modifier
        </button>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Restrictions alimentaires</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {preferences.restrictions.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {preferences.restrictions.map((restriction) => (
                    <span key={restriction} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      {restriction}
                    </span>
                  ))}
                </div>
              ) : (
                'Aucune restriction'
              )}
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Préférences</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {preferences.preferences.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {preferences.preferences.map((preference) => (
                    <span key={preference} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {preference}
                    </span>
                  ))}
                </div>
              ) : (
                'Aucune préférence'
              )}
            </dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Allergènes</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {preferences.allergens.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {preferences.allergens.map((allergen) => (
                    <span key={allergen} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      {allergen}
                    </span>
                  ))}
                </div>
              ) : (
                'Aucun allergène'
              )}
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Cuisines préférées</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {preferences.cuisines.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {preferences.cuisines.map((cuisine) => (
                    <span key={cuisine} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {cuisine}
                    </span>
                  ))}
                </div>
              ) : (
                'Aucune cuisine préférée'
              )}
            </dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Objectifs nutritionnels</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {preferences.nutritionalGoals || 'Aucun objectif spécifique'}
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
};

// Composant pour la section des statistiques
const StatsSection = ({ stats }) => {
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Statistiques</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Votre activité sur Dini Play</p>
      </div>
      <div className="border-t border-gray-200">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">{stats.recipesCreated}</div>
            <div className="text-sm text-gray-500">Recettes créées</div>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">{stats.mealPlans}</div>
            <div className="text-sm text-gray-500">Plans de repas</div>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">{stats.favoriteRecipes}</div>
            <div className="text-sm text-gray-500">Recettes favorites</div>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">{stats.daysActive}</div>
            <div className="text-sm text-gray-500">Jours d'activité</div>
          </div>
        </div>
        
        <div className="px-4 py-5">
          <h4 className="text-md font-medium text-gray-900 mb-4">Activité récente</h4>
          <div className="space-y-4">
            {stats.recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0">
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                    activity.type === 'recipe' ? 'bg-green-100 text-green-600' :
                    activity.type === 'mealPlan' ? 'bg-blue-100 text-blue-600' :
                    activity.type === 'shopping' ? 'bg-purple-100 text-purple-600' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {activity.type === 'recipe' && (
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    )}
                    {activity.type === 'mealPlan' && (
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    )}
                    {activity.type === 'shopping' && (
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    )}
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                  <p className="text-xs text-gray-500">{new Date(activity.date).toLocaleDateString('fr-FR')} à {new Date(activity.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Composant pour la section de sécurité
const SecuritySection = ({ onChangePassword, onManageDevices }) => {
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Sécurité</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Paramètres de sécurité du compte</p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Mot de passe</h4>
            <div className="mt-2 flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Dernière modification il y a 3 mois
              </p>
              <button
                onClick={onChangePassword}
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Changer le mot de passe
              </button>
            </div>
          </div>
          
          <div className="pt-5 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900">Authentification à deux facteurs</h4>
            <div className="mt-2 flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Non activée
              </p>
              <button
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Configurer
              </button>
            </div>
          </div>
          
          <div className="pt-5 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900">Appareils connectés</h4>
            <div className="mt-2 flex items-center justify-between">
              <p className="text-sm text-gray-500">
                2 appareils actifs
              </p>
              <button
                onClick={onManageDevices}
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Gérer les appareils
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Composant pour le modal d'édition des informations personnelles
const EditProfileModal = ({ isOpen, onClose, user, onSave }) => {
  const [formData, setFormData] = useState({ ...user });
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            Modifier les informations personnelles
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                Prénom
              </label>
              <input
                type="text"
                name="firstName"
                id="firstName"
                required
                value={formData.firstName}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                Nom
              </label>
              <input
                type="text"
                name="lastName"
                id="lastName"
                required
                value={formData.lastName}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                type="email"
                name="email"
                id="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Téléphone
              </label>
              <input
                type="tel"
                name="phone"
                id="phone"
                value={formData.phone || ''}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour le modal d'édition des préférences alimentaires
const EditPreferencesModal = ({ isOpen, onClose, preferences, onSave }) => {
  const [formData, setFormData] = useState({ ...preferences });
  
  const allRestrictions = [
    'Halal', 'Végétarien', 'Végétalien', 'Sans gluten', 'Sans lactose', 'Sans fruits de mer'
  ];
  
  const allCuisines = [
    'Marocaine', 'Libanaise', 'Turque', 'Indienne', 'Pakistanaise', 'Indonésienne', 
    'Malaisienne', 'Africaine', 'Méditerranéenne', 'Française', 'Italienne'
  ];
  
  const allAllergens = [
    'Arachides', 'Fruits à coque', 'Lait', 'Œufs', 'Poisson', 'Crustacés', 
    'Mollusques', 'Soja', 'Céleri', 'Moutarde', 'Sésame', 'Lupin', 'Sulfites'
  ];
  
  const handleToggleRestriction = (restriction) => {
    setFormData(prev => {
      const newRestrictions = prev.restrictions.includes(restriction)
        ? prev.restrictions.filter(r => r !== restriction)
        : [...prev.restrictions, restriction];
      return { ...prev, restrictions: newRestrictions };
    });
  };
  
  const handleToggleCuisine = (cuisine) => {
    setFormData(prev => {
      const newCuisines = prev.cuisines.includes(cuisine)
        ? prev.cuisines.filter(c => c !== cuisine)
        : [...prev.cuisines, cuisine];
      return { ...prev, cuisines: newCuisines };
    });
  };
  
  const handleToggleAllergen = (allergen) => {
    setFormData(prev => {
      const newAllergens = prev.allergens.includes(allergen)
        ? prev.allergens.filter(a => a !== allergen)
        : [...prev.allergens, allergen];
      return { ...prev, allergens: newAllergens };
    });
  };
  
  const handleAddPreference = (e) => {
    if (e.key === 'Enter' && e.target.value.trim()) {
      setFormData(prev => ({
        ...prev,
        preferences: [...prev.preferences, e.target.value.trim()]
      }));
      e.target.value = '';
    }
  };
  
  const handleRemovePreference = (preference) => {
    setFormData(prev => ({
      ...prev,
      preferences: prev.preferences.filter(p => p !== preference)
    }));
  };
  
  const handleChangeGoals = (e) => {
    setFormData(prev => ({
      ...prev,
      nutritionalGoals: e.target.value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            Modifier les préférences alimentaires
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Restrictions alimentaires</h4>
              <div className="flex flex-wrap gap-2">
                {allRestrictions.map(restriction => (
                  <button
                    key={restriction}
                    type="button"
                    onClick={() => handleToggleRestriction(restriction)}
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      formData.restrictions.includes(restriction)
                        ? 'bg-red-100 text-red-800 hover:bg-red-200'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    }`}
                  >
                    {restriction}
                    {formData.restrictions.includes(restriction) && (
                      <svg className="ml-1.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Préférences</h4>
              <div className="flex flex-wrap gap-2 mb-2">
                {formData.preferences.map(preference => (
                  <span key={preference} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {preference}
                    <button
                      type="button"
                      onClick={() => handleRemovePreference(preference)}
                      className="ml-1.5 inline-flex flex-shrink-0 h-4 w-4 rounded-full text-green-400 hover:text-green-600"
                    >
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </span>
                ))}
              </div>
              <input
                type="text"
                placeholder="Ajouter une préférence (appuyez sur Entrée)"
                onKeyDown={handleAddPreference}
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
              <p className="mt-1 text-xs text-gray-500">Exemples : Épicé, Sucré, Salé, Acide, Amer, etc.</p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Allergènes</h4>
              <div className="flex flex-wrap gap-2">
                {allAllergens.map(allergen => (
                  <button
                    key={allergen}
                    type="button"
                    onClick={() => handleToggleAllergen(allergen)}
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      formData.allergens.includes(allergen)
                        ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    }`}
                  >
                    {allergen}
                    {formData.allergens.includes(allergen) && (
                      <svg className="ml-1.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Cuisines préférées</h4>
              <div className="flex flex-wrap gap-2">
                {allCuisines.map(cuisine => (
                  <button
                    key={cuisine}
                    type="button"
                    onClick={() => handleToggleCuisine(cuisine)}
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      formData.cuisines.includes(cuisine)
                        ? 'bg-blue-100 text-blue-800 hover:bg-blue-200'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    }`}
                  >
                    {cuisine}
                    {formData.cuisines.includes(cuisine) && (
                      <svg className="ml-1.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Objectifs nutritionnels</h4>
              <textarea
                value={formData.nutritionalGoals || ''}
                onChange={handleChangeGoals}
                rows="3"
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Décrivez vos objectifs nutritionnels (ex: réduire les calories, augmenter les protéines, etc.)"
              ></textarea>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour le modal de changement de mot de passe
const ChangePasswordModal = ({ isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [error, setError] = useState('');
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Réinitialiser l'erreur lorsque l'utilisateur modifie les champs
    setError('');
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Vérifier que les mots de passe correspondent
    if (formData.newPassword !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }
    
    // Vérifier la complexité du mot de passe
    if (formData.newPassword.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }
    
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            Changer le mot de passe
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          {error && (
            <div className="mb-4 p-2 bg-red-100 border border-red-400 text-red-700 rounded">
              {error}
            </div>
          )}
          
          <div className="space-y-4">
            <div>
              <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700">
                Mot de passe actuel
              </label>
              <input
                type="password"
                name="currentPassword"
                id="currentPassword"
                required
                value={formData.currentPassword}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700">
                Nouveau mot de passe
              </label>
              <input
                type="password"
                name="newPassword"
                id="newPassword"
                required
                value={formData.newPassword}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
              <p className="mt-1 text-xs text-gray-500">
                Le mot de passe doit contenir au moins 8 caractères.
              </p>
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                Confirmer le nouveau mot de passe
              </label>
              <input
                type="password"
                name="confirmPassword"
                id="confirmPassword"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Changer le mot de passe
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default function Profil() {
  // Données simulées pour l'utilisateur
  const [user, setUser] = useState({
    firstName: 'Mohammed',
    lastName: 'Ali',
    email: 'mohammed.ali@example.com',
    phone: '+212 6 12 34 56 78',
    role: 'Utilisateur',
    createdAt: '2024-01-15T10:30:00Z'
  });
  
  // Données simulées pour les préférences alimentaires
  const [preferences, setPreferences] = useState({
    restrictions: ['Halal', 'Sans porc'],
    preferences: ['Épicé', 'Sucré-salé'],
    allergens: ['Arachides'],
    cuisines: ['Marocaine', 'Libanaise', 'Indienne'],
    nutritionalGoals: 'Réduire les calories et augmenter l\'apport en protéines.'
  });
  
  // Données simulées pour les statistiques
  const [stats, setStats] = useState({
    recipesCreated: 12,
    mealPlans: 8,
    favoriteRecipes: 24,
    daysActive: 45,
    recentActivity: [
      {
        type: 'recipe',
        description: 'Ajout de la recette "Tajine de poulet aux olives" aux favoris',
        date: '2025-04-25T14:30:00Z'
      },
      {
        type: 'mealPlan',
        description: 'Création d\'un nouveau plan de repas pour la semaine',
        date: '2025-04-24T09:15:00Z'
      },
      {
        type: 'shopping',
        description: 'Génération d\'une liste de courses',
        date: '2025-04-23T18:45:00Z'
      },
      {
        type: 'recipe',
        description: 'Création de la recette "Couscous aux légumes"',
        date: '2025-04-22T11:20:00Z'
      }
    ]
  });
  
  // États pour les modals
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [preferencesModalOpen, setPreferencesModalOpen] = useState(false);
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  
  // Gestionnaires d'événements pour les modals
  const handleEditProfile = () => {
    setProfileModalOpen(true);
  };
  
  const handleEditPreferences = () => {
    setPreferencesModalOpen(true);
  };
  
  const handleChangePassword = () => {
    setPasswordModalOpen(true);
  };
  
  const handleManageDevices = () => {
    alert('Fonctionnalité de gestion des appareils en cours de développement.');
  };
  
  // Gestionnaires pour sauvegarder les modifications
  const handleSaveProfile = (updatedProfile) => {
    setUser(updatedProfile);
    alert('Profil mis à jour avec succès !');
  };
  
  const handleSavePreferences = (updatedPreferences) => {
    setPreferences(updatedPreferences);
    alert('Préférences alimentaires mises à jour avec succès !');
  };
  
  const handleSavePassword = (passwordData) => {
    // Simuler la mise à jour du mot de passe
    alert('Mot de passe changé avec succès !');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeItem="Profil" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} title="Profil" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            <PersonalInfoSection 
              user={user} 
              onEdit={handleEditProfile} 
            />
            
            <DietaryPreferencesSection 
              preferences={preferences} 
              onEdit={handleEditPreferences} 
            />
            
            <StatsSection stats={stats} />
            
            <SecuritySection 
              onChangePassword={handleChangePassword}
              onManageDevices={handleManageDevices}
            />
          </div>
        </main>
      </div>
      
      {/* Modals */}
      <EditProfileModal 
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
        user={user}
        onSave={handleSaveProfile}
      />
      
      <EditPreferencesModal 
        isOpen={preferencesModalOpen}
        onClose={() => setPreferencesModalOpen(false)}
        preferences={preferences}
        onSave={handleSavePreferences}
      />
      
      <ChangePasswordModal 
        isOpen={passwordModalOpen}
        onClose={() => setPasswordModalOpen(false)}
        onSave={handleSavePassword}
      />
    </div>
  );
}
