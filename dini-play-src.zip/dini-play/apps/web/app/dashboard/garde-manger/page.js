'use client';

import { useState } from 'react';
import Link from 'next/link';

// Composant de navigation latérale (réutilisé du dashboard)
const Sidebar = ({ activeItem }) => {
  const navItems = [
    { name: 'Tableau de bord', href: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Recettes', href: '/dashboard/recettes', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { name: 'Plan de repas', href: '/dashboard/plan-repas', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'Garde-manger', href: '/dashboard/garde-manger', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { name: 'Liste de courses', href: '/dashboard/liste-courses', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { name: 'Profil', href: '/dashboard/profil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  ];

  return (
    <div className="h-screen flex-none w-64 bg-white border-r border-gray-200">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-green-800">
          Dini <span className="text-green-600">Play</span>
        </h1>
      </div>
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`${
                activeItem === item.name
                  ? 'bg-green-50 text-green-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
            >
              <svg
                className={`${
                  activeItem === item.name ? 'text-green-500' : 'text-gray-400 group-hover:text-gray-500'
                } mr-3 flex-shrink-0 h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.name}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

// Composant d'en-tête
const Header = ({ user, title }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {user.role}
              </span>
            </div>
            <div className="ml-3 relative">
              <div className="flex items-center">
                <span className="hidden md:block mr-3 text-sm font-medium text-gray-700">
                  {user.firstName} {user.lastName}
                </span>
                <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                  {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

// Composant pour l'élément du garde-manger
const PantryItem = ({ item, onEdit, onDelete, onUpdateQuantity }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-medium text-gray-900">{item.name}</h3>
          <div className="mt-1 text-sm text-gray-500">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 mr-2">
              {item.category}
            </span>
            {item.expiryDate && (
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                new Date(item.expiryDate) < new Date() 
                  ? 'bg-red-100 text-red-800' 
                  : new Date(item.expiryDate) < new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) 
                    ? 'bg-yellow-100 text-yellow-800' 
                    : 'bg-green-100 text-green-800'
              }`}>
                {new Date(item.expiryDate).toLocaleDateString('fr-FR')}
              </span>
            )}
          </div>
        </div>
        <div className="flex space-x-1">
          <button 
            onClick={() => onEdit(item)}
            className="text-gray-400 hover:text-gray-500"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
          </button>
          <button 
            onClick={() => onDelete(item.id)}
            className="text-gray-400 hover:text-red-500"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => onUpdateQuantity(item.id, Math.max(0, item.quantity - 1))}
            className="text-gray-500 hover:text-gray-700 p-1"
            disabled={item.quantity <= 0}
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
            </svg>
          </button>
          <span className="mx-2 text-sm font-medium">
            {item.quantity} {item.unit}
          </span>
          <button 
            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
            className="text-gray-500 hover:text-gray-700 p-1"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </button>
        </div>
        <div className="text-xs text-gray-500">
          {item.calories ? `${item.calories} cal/${item.unit}` : ''}
        </div>
      </div>
    </div>
  );
};

// Composant pour le modal d'ajout/édition d'ingrédient
const PantryItemModal = ({ isOpen, onClose, item, onSave }) => {
  const [formData, setFormData] = useState(
    item ? { ...item } : {
      id: Date.now().toString(),
      name: '',
      category: 'Légumes',
      quantity: 1,
      unit: 'pièce',
      expiryDate: '',
      calories: 0
    }
  );
  
  const categories = [
    'Légumes', 'Fruits', 'Viandes', 'Poissons', 'Produits laitiers', 
    'Céréales', 'Légumineuses', 'Épices', 'Huiles', 'Boissons', 'Autres'
  ];
  
  const units = [
    'pièce', 'g', 'kg', 'ml', 'l', 'cuillère à café', 'cuillère à soupe', 'tasse'
  ];
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'quantity' || name === 'calories' ? parseFloat(value) : value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {item ? 'Modifier l\'ingrédient' : 'Ajouter un ingrédient'}
          </h3>
        </div>
        
        <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Nom de l'ingrédient
              </label>
              <input
                type="text"
                name="name"
                id="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                Catégorie
              </label>
              <select
                name="category"
                id="category"
                required
                value={formData.category}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">
                  Quantité
                </label>
                <input
                  type="number"
                  name="quantity"
                  id="quantity"
                  min="0"
                  step="0.1"
                  required
                  value={formData.quantity}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                />
              </div>
              
              <div>
                <label htmlFor="unit" className="block text-sm font-medium text-gray-700">
                  Unité
                </label>
                <select
                  name="unit"
                  id="unit"
                  required
                  value={formData.unit}
                  onChange={handleChange}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                >
                  {units.map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">
                Date d'expiration
              </label>
              <input
                type="date"
                name="expiryDate"
                id="expiryDate"
                value={formData.expiryDate}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="calories" className="block text-sm font-medium text-gray-700">
                Calories (par unité)
              </label>
              <input
                type="number"
                name="calories"
                id="calories"
                min="0"
                value={formData.calories}
                onChange={handleChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour les statistiques du garde-manger
const PantryStats = ({ items }) => {
  // Calculer les statistiques
  const totalItems = items.length;
  const expiringItems = items.filter(item => {
    if (!item.expiryDate) return false;
    const expiryDate = new Date(item.expiryDate);
    const today = new Date();
    const threeDaysFromNow = new Date(today);
    threeDaysFromNow.setDate(today.getDate() + 3);
    return expiryDate <= threeDaysFromNow && expiryDate >= today;
  }).length;
  const expiredItems = items.filter(item => {
    if (!item.expiryDate) return false;
    return new Date(item.expiryDate) < new Date();
  }).length;
  
  // Calculer les catégories les plus représentées
  const categoryCounts = items.reduce((acc, item) => {
    acc[item.category] = (acc[item.category] || 0) + 1;
    return acc;
  }, {});
  
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([category, count]) => ({ category, count }));
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Statistiques du garde-manger</h3>
      
      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="bg-gray-50 p-3 rounded-md text-center">
          <div className="text-sm text-gray-500">Total</div>
          <div className="text-2xl font-semibold text-gray-900">{totalItems}</div>
        </div>
        
        <div className="bg-yellow-50 p-3 rounded-md text-center">
          <div className="text-sm text-yellow-500">Bientôt périmés</div>
          <div className="text-2xl font-semibold text-yellow-600">{expiringItems}</div>
        </div>
        
        <div className="bg-red-50 p-3 rounded-md text-center">
          <div className="text-sm text-red-500">Périmés</div>
          <div className="text-2xl font-semibold text-red-600">{expiredItems}</div>
        </div>
      </div>
      
      <h4 className="text-sm font-medium text-gray-700 mb-2">Catégories principales</h4>
      
      <div className="space-y-2">
        {topCategories.map(({ category, count }) => (
          <div key={category}>
            <div className="flex justify-between text-sm">
              <span>{category}</span>
              <span>{count} articles</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
              <div 
                className="bg-green-500 h-2 rounded-full" 
                style={{ width: `${(count / totalItems) * 100}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Composant pour les actions rapides
const QuickActions = ({ onScanBarcode, onImportItems, onExportItems }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Actions rapides</h3>
      
      <div className="space-y-3">
        <button
          onClick={onScanBarcode}
          className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
          </svg>
          Scanner un code-barres
        </button>
        
        <button
          onClick={onImportItems}
          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
          </svg>
          Importer des articles
        </button>
        
        <button
          onClick={onExportItems}
          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <svg className="h-5 w-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Exporter le garde-manger
        </button>
      </div>
    </div>
  );
};

export default function GardeManger() {
  // Données simulées pour l'utilisateur
  const [user, setUser] = useState({
    firstName: 'Mohammed',
    lastName: 'Ali',
    email: 'mohammed.ali@example.com',
    role: 'Utilisateur',
  });
  
  // État pour les ingrédients du garde-manger
  const [pantryItems, setPantryItems] = useState([
    {
      id: '1',
      name: 'Tomates',
      category: 'Légumes',
      quantity: 5,
      unit: 'pièce',
      expiryDate: '2025-05-02',
      calories: 22
    },
    {
      id: '2',
      name: 'Poulet',
      category: 'Viandes',
      quantity: 500,
      unit: 'g',
      expiryDate: '2025-04-28',
      calories: 165
    },
    {
      id: '3',
      name: 'Riz basmati',
      category: 'Céréales',
      quantity: 1.5,
      unit: 'kg',
      expiryDate: '2025-12-31',
      calories: 350
    },
    {
      id: '4',
      name: 'Lait',
      category: 'Produits laitiers',
      quantity: 1,
      unit: 'l',
      expiryDate: '2025-04-30',
      calories: 42
    },
    {
      id: '5',
      name: 'Oignons',
      category: 'Légumes',
      quantity: 3,
      unit: 'pièce',
      expiryDate: '2025-05-15',
      calories: 40
    },
    {
      id: '6',
      name: 'Cumin',
      category: 'Épices',
      quantity: 50,
      unit: 'g',
      expiryDate: '',
      calories: 375
    },
    {
      id: '7',
      name: 'Yaourt nature',
      category: 'Produits laitiers',
      quantity: 0,
      unit: 'pièce',
      expiryDate: '2025-04-29',
      calories: 59
    },
    {
      id: '8',
      name: 'Huile d\'olive',
      category: 'Huiles',
      quantity: 0.5,
      unit: 'l',
      expiryDate: '2025-10-15',
      calories: 884
    },
    {
      id: '9',
      name: 'Pois chiches',
      category: 'Légumineuses',
      quantity: 400,
      unit: 'g',
      expiryDate: '2025-08-20',
      calories: 364
    },
    {
      id: '10',
      name: 'Citrons',
      category: 'Fruits',
      quantity: 2,
      unit: 'pièce',
      expiryDate: '2025-05-05',
      calories: 29
    },
    {
      id: '11',
      name: 'Pain pita',
      category: 'Céréales',
      quantity: 6,
      unit: 'pièce',
      expiryDate: '2025-04-27',
      calories: 275
    },
    {
      id: '12',
      name: 'Garam masala',
      category: 'Épices',
      quantity: 0,
      unit: 'g',
      expiryDate: '',
      calories: 323
    }
  ]);
  
  // État pour le modal d'ajout/édition d'ingrédient
  const [modalOpen, setModalOpen] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);
  
  // État pour la recherche et le filtrage
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Tous');
  const [sortBy, setSortBy] = useState('name');
  const [showExpired, setShowExpired] = useState(true);
  const [showEmpty, setShowEmpty] = useState(true);
  
  // Liste des catégories disponibles
  const categories = ['Tous', ...new Set(pantryItems.map(item => item.category))];
  
  // Filtrer et trier les ingrédients
  const filteredItems = pantryItems.filter(item => {
    // Filtre par recherche
    if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filtre par catégorie
    if (categoryFilter !== 'Tous' && item.category !== categoryFilter) {
      return false;
    }
    
    // Filtre pour les articles périmés
    if (!showExpired && item.expiryDate && new Date(item.expiryDate) < new Date()) {
      return false;
    }
    
    // Filtre pour les articles épuisés
    if (!showEmpty && item.quantity <= 0) {
      return false;
    }
    
    return true;
  });
  
  // Trier les ingrédients
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    } else if (sortBy === 'expiryDate') {
      if (!a.expiryDate) return 1;
      if (!b.expiryDate) return -1;
      return new Date(a.expiryDate) - new Date(b.expiryDate);
    } else if (sortBy === 'category') {
      return a.category.localeCompare(b.category);
    } else if (sortBy === 'quantity') {
      return b.quantity - a.quantity;
    }
    return 0;
  });
  
  // Fonction pour ouvrir le modal d'ajout d'ingrédient
  const handleAddItem = () => {
    setCurrentItem(null);
    setModalOpen(true);
  };
  
  // Fonction pour ouvrir le modal d'édition d'ingrédient
  const handleEditItem = (item) => {
    setCurrentItem(item);
    setModalOpen(true);
  };
  
  // Fonction pour supprimer un ingrédient
  const handleDeleteItem = (itemId) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet ingrédient ?')) {
      setPantryItems(pantryItems.filter(item => item.id !== itemId));
    }
  };
  
  // Fonction pour mettre à jour la quantité d'un ingrédient
  const handleUpdateQuantity = (itemId, newQuantity) => {
    setPantryItems(pantryItems.map(item => 
      item.id === itemId ? { ...item, quantity: newQuantity } : item
    ));
  };
  
  // Fonction pour sauvegarder un ingrédient (ajout ou édition)
  const handleSaveItem = (itemData) => {
    if (currentItem) {
      // Édition d'un ingrédient existant
      setPantryItems(pantryItems.map(item => item.id === itemData.id ? itemData : item));
    } else {
      // Ajout d'un nouvel ingrédient
      setPantryItems([...pantryItems, itemData]);
    }
  };
  
  // Fonction pour scanner un code-barres
  const handleScanBarcode = () => {
    alert('Fonctionnalité de scan de code-barres en cours de développement.');
  };
  
  // Fonction pour importer des articles
  const handleImportItems = () => {
    alert('Fonctionnalité d\'import d\'articles en cours de développement.');
  };
  
  // Fonction pour exporter le garde-manger
  const handleExportItems = () => {
    alert('Fonctionnalité d\'export du garde-manger en cours de développement.');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeItem="Garde-manger" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} title="Garde-manger" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row gap-6">
              <div className="lg:w-3/4">
                <div className="bg-white rounded-lg shadow mb-6">
                  <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="relative flex-1">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg className="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <input
                        type="text"
                        placeholder="Rechercher des ingrédients..."
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    
                    <button
                      onClick={handleAddItem}
                      className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    >
                      <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      Ajouter un ingrédient
                    </button>
                  </div>
                  
                  <div className="p-4 border-b border-gray-200 flex flex-wrap gap-4">
                    <div>
                      <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                        Catégorie
                      </label>
                      <select
                        id="category"
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value)}
                        className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                      >
                        {categories.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="sortBy" className="block text-sm font-medium text-gray-700 mb-1">
                        Trier par
                      </label>
                      <select
                        id="sortBy"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                      >
                        <option value="name">Nom</option>
                        <option value="expiryDate">Date d'expiration</option>
                        <option value="category">Catégorie</option>
                        <option value="quantity">Quantité</option>
                      </select>
                    </div>
                    
                    <div className="flex items-end space-x-4">
                      <div className="flex items-center">
                        <input
                          id="showExpired"
                          type="checkbox"
                          checked={showExpired}
                          onChange={(e) => setShowExpired(e.target.checked)}
                          className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                        />
                        <label htmlFor="showExpired" className="ml-2 block text-sm text-gray-700">
                          Afficher les périmés
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          id="showEmpty"
                          type="checkbox"
                          checked={showEmpty}
                          onChange={(e) => setShowEmpty(e.target.checked)}
                          className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                        />
                        <label htmlFor="showEmpty" className="ml-2 block text-sm text-gray-700">
                          Afficher les épuisés
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {sortedItems.map(item => (
                        <PantryItem
                          key={item.id}
                          item={item}
                          onEdit={handleEditItem}
                          onDelete={handleDeleteItem}
                          onUpdateQuantity={handleUpdateQuantity}
                        />
                      ))}
                    </div>
                    
                    {sortedItems.length === 0 && (
                      <div className="bg-gray-50 p-6 rounded-lg text-center">
                        <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h3 className="mt-2 text-sm font-medium text-gray-900">Aucun ingrédient trouvé</h3>
                        <p className="mt-1 text-sm text-gray-500">Ajoutez des ingrédients à votre garde-manger ou modifiez vos filtres.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="lg:w-1/4 space-y-6">
                <PantryStats items={pantryItems} />
                <QuickActions
                  onScanBarcode={handleScanBarcode}
                  onImportItems={handleImportItems}
                  onExportItems={handleExportItems}
                />
              </div>
            </div>
          </div>
        </main>
      </div>
      
      {/* Modal pour ajouter/éditer un ingrédient */}
      <PantryItemModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        item={currentItem}
        onSave={handleSaveItem}
      />
    </div>
  );
}
