import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-12 bg-gradient-to-b from-green-50 to-green-100">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-4 sm:px-20 text-center">
        <h1 className="text-4xl sm:text-6xl font-bold text-green-800 mb-4">
          Dini <span className="text-green-600">Play</span>
        </h1>
        <p className="text-xl sm:text-2xl text-gray-700 mb-8">
          Votre planificateur de repas Halal personnalisé
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 mt-6">
          <Link 
            href="/auth/login" 
            className="px-8 py-3 rounded-md bg-green-600 text-white font-medium hover:bg-green-700 transition-colors"
          >
            Se connecter
          </Link>
          <Link 
            href="/auth/register" 
            className="px-8 py-3 rounded-md bg-white text-green-600 font-medium border border-green-600 hover:bg-green-50 transition-colors"
          >
            S'inscrire
          </Link>
        </div>
        
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-5xl">
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-green-700 mb-3">Recettes Halal</h2>
            <p className="text-gray-600">Découvrez des centaines de recettes halal délicieuses et faciles à préparer.</p>
          </div>
          
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-green-700 mb-3">Planification Simplifiée</h2>
            <p className="text-gray-600">Planifiez vos repas pour la semaine en quelques clics et générez automatiquement votre liste de courses.</p>
          </div>
          
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-green-700 mb-3">Recommandations Personnalisées</h2>
            <p className="text-gray-600">Recevez des suggestions adaptées à vos préférences, allergies et contraintes de temps.</p>
          </div>
        </div>
      </main>
      
      <footer className="w-full py-6 text-center border-t border-gray-200 mt-12">
        <p className="text-gray-600">© 2025 Dini Play - Tous droits réservés</p>
      </footer>
    </div>
  );
}
