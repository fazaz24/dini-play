import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import ListeCourses from '../app/dashboard/liste-courses/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('ListeCourses', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
    
    // Mock de la fonction fetch pour les listes de courses
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          name: 'Liste pour Plan hebdomadaire',
          userId: 'user1',
          createdAt: '2025-04-20T10:00:00Z',
          items: [
            {
              id: 'item1',
              name: 'Poulet',
              quantity: 1,
              unit: 'kg',
              category: 'Viandes',
              checked: false,
              shoppingListId: '1',
            },
            {
              id: 'item2',
              name: 'Olives',
              quantity: 200,
              unit: 'g',
              category: 'Légumes',
              checked: true,
              shoppingListId: '1',
            },
            {
              id: 'item3',
              name: 'Citron confit',
              quantity: 2,
              unit: 'pièce',
              category: 'Épices',
              checked: false,
              shoppingListId: '1',
            },
          ],
        },
        {
          id: '2',
          name: 'Liste pour Ramadan',
          userId: 'user1',
          createdAt: '2025-04-15T14:30:00Z',
          items: [
            {
              id: 'item4',
              name: 'Dattes',
              quantity: 500,
              unit: 'g',
              category: 'Fruits',
              checked: false,
              shoppingListId: '2',
            },
            {
              id: 'item5',
              name: 'Lait',
              quantity: 2,
              unit: 'L',
              category: 'Produits laitiers',
              checked: false,
              shoppingListId: '2',
            },
          ],
        },
      ]),
    });
  });

  it('renders liste courses page correctly', async () => {
    render(<ListeCourses />);
    
    // Vérifier que le titre de la page est présent
    expect(screen.getByText('Mes Listes de Courses')).toBeInTheDocument();
    
    // Vérifier que le bouton pour créer une liste est présent
    expect(screen.getByText('Nouvelle liste')).toBeInTheDocument();
    
    // Vérifier que les listes sont chargées et affichées
    await waitFor(() => {
      expect(screen.getByText('Liste pour Plan hebdomadaire')).toBeInTheDocument();
      expect(screen.getByText('Liste pour Ramadan')).toBeInTheDocument();
    });
  });

  it('displays shopping list items when selecting a list', async () => {
    render(<ListeCourses />);
    
    // Attendre que les listes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Liste pour Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Cliquer sur la première liste
    fireEvent.click(screen.getByText('Liste pour Plan hebdomadaire'));
    
    // Vérifier que les items de la liste sont affichés
    await waitFor(() => {
      expect(screen.getByText('Poulet (1 kg)')).toBeInTheDocument();
      expect(screen.getByText('Olives (200 g)')).toBeInTheDocument();
      expect(screen.getByText('Citron confit (2 pièce)')).toBeInTheDocument();
    });
    
    // Vérifier que les items sont regroupés par catégorie
    expect(screen.getByText('Viandes')).toBeInTheDocument();
    expect(screen.getByText('Légumes')).toBeInTheDocument();
    expect(screen.getByText('Épices')).toBeInTheDocument();
  });

  it('toggles item checked status when clicking on checkbox', async () => {
    render(<ListeCourses />);
    
    // Attendre que les listes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Liste pour Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Cliquer sur la première liste
    fireEvent.click(screen.getByText('Liste pour Plan hebdomadaire'));
    
    // Attendre que les items soient affichés
    await waitFor(() => {
      expect(screen.getByText('Poulet (1 kg)')).toBeInTheDocument();
    });
    
    // Mock de la fonction fetch pour la mise à jour du statut
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'item1',
        name: 'Poulet',
        quantity: 1,
        unit: 'kg',
        category: 'Viandes',
        checked: true,
        shoppingListId: '1',
      }),
    });
    
    // Cliquer sur la case à cocher du poulet
    const checkbox = screen.getAllByRole('checkbox')[0];
    fireEvent.click(checkbox);
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/shopping-list/items/item1'),
        expect.objectContaining({
          method: 'PATCH',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('"checked":true'),
        })
      );
    });
  });

  it('opens create list modal when clicking on new list button', async () => {
    render(<ListeCourses />);
    
    // Cliquer sur le bouton pour créer une nouvelle liste
    fireEvent.click(screen.getByText('Nouvelle liste'));
    
    // Vérifier que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Créer une nouvelle liste de courses')).toBeInTheDocument();
      expect(screen.getByLabelText('Nom de la liste')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Créer' })).toBeInTheDocument();
    });
  });

  it('creates a new list when submitting the form', async () => {
    render(<ListeCourses />);
    
    // Cliquer sur le bouton pour créer une nouvelle liste
    fireEvent.click(screen.getByText('Nouvelle liste'));
    
    // Attendre que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Créer une nouvelle liste de courses')).toBeInTheDocument();
    });
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Nom de la liste'), {
      target: { value: 'Nouvelle liste test' },
    });
    
    // Mock de la fonction fetch pour la création de la liste
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: '3',
        name: 'Nouvelle liste test',
        userId: 'user1',
        createdAt: new Date().toISOString(),
        items: [],
      }),
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Créer' }));
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/shopping-list'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('Nouvelle liste test'),
        })
      );
    });
  });

  it('adds a new item when using the add item form', async () => {
    render(<ListeCourses />);
    
    // Attendre que les listes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Liste pour Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Cliquer sur la première liste
    fireEvent.click(screen.getByText('Liste pour Plan hebdomadaire'));
    
    // Attendre que les items soient affichés
    await waitFor(() => {
      expect(screen.getByText('Poulet (1 kg)')).toBeInTheDocument();
    });
    
    // Cliquer sur le bouton pour ajouter un item
    fireEvent.click(screen.getByText('Ajouter un article'));
    
    // Vérifier que le formulaire s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Ajouter un article à la liste')).toBeInTheDocument();
      expect(screen.getByLabelText('Nom')).toBeInTheDocument();
      expect(screen.getByLabelText('Quantité')).toBeInTheDocument();
      expect(screen.getByLabelText('Unité')).toBeInTheDocument();
      expect(screen.getByLabelText('Catégorie')).toBeInTheDocument();
    });
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Nom'), {
      target: { value: 'Tomates' },
    });
    fireEvent.change(screen.getByLabelText('Quantité'), {
      target: { value: '500' },
    });
    fireEvent.change(screen.getByLabelText('Unité'), {
      target: { value: 'g' },
    });
    fireEvent.change(screen.getByLabelText('Catégorie'), {
      target: { value: 'Légumes' },
    });
    
    // Mock de la fonction fetch pour l'ajout d'item
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'item6',
        name: 'Tomates',
        quantity: 500,
        unit: 'g',
        category: 'Légumes',
        checked: false,
        shoppingListId: '1',
      }),
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Ajouter' }));
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/shopping-list/1/items'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('Tomates'),
        })
      );
    });
  });

  it('displays progress statistics for the shopping list', async () => {
    render(<ListeCourses />);
    
    // Attendre que les listes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Liste pour Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Cliquer sur la première liste
    fireEvent.click(screen.getByText('Liste pour Plan hebdomadaire'));
    
    // Vérifier que les statistiques de progression sont affichées
    await waitFor(() => {
      expect(screen.getByText('Progression: 33%')).toBeInTheDocument();
      expect(screen.getByText('1/3 articles achetés')).toBeInTheDocument();
    });
  });
});
