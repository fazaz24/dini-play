import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import PlanRepasPage from '../app/dashboard/plan-repas/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('PlanRepasPage', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
    
    // Mock de la fonction fetch pour les plans de repas
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          name: 'Plan hebdomadaire',
          startDate: '2025-04-20',
          endDate: '2025-04-26',
          repas: [
            {
              id: 'repas1',
              date: '2025-04-20',
              type: 'DEJEUNER',
              recettes: [
                {
                  id: 'recetteRepas1',
                  servings: 4,
                  recette: {
                    id: 'recette1',
                    title: 'Tajine de poulet',
                    calories: 450,
                  },
                },
              ],
            },
            {
              id: 'repas2',
              date: '2025-04-20',
              type: 'DINER',
              recettes: [
                {
                  id: 'recetteRepas2',
                  servings: 4,
                  recette: {
                    id: 'recette2',
                    title: 'Couscous aux légumes',
                    calories: 380,
                  },
                },
              ],
            },
          ],
        },
      ]),
    });
  });

  it('renders plan repas page correctly', async () => {
    render(<PlanRepasPage />);
    
    // Vérifier que le titre de la page est présent
    expect(screen.getByText('Planification des repas')).toBeInTheDocument();
    
    // Vérifier que le bouton pour créer un nouveau plan est présent
    expect(screen.getByText('Nouveau plan')).toBeInTheDocument();
    
    // Vérifier que le plan de repas est chargé et affiché
    await waitFor(() => {
      expect(screen.getByText('Plan hebdomadaire')).toBeInTheDocument();
      expect(screen.getByText('20 avril - 26 avril 2025')).toBeInTheDocument();
    });
  });

  it('displays calendar view with meals', async () => {
    render(<PlanRepasPage />);
    
    // Attendre que le plan de repas soit chargé
    await waitFor(() => {
      expect(screen.getByText('Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Vérifier que le calendrier est affiché
    expect(screen.getByText('Dimanche')).toBeInTheDocument();
    expect(screen.getByText('Lundi')).toBeInTheDocument();
    expect(screen.getByText('Mardi')).toBeInTheDocument();
    expect(screen.getByText('Mercredi')).toBeInTheDocument();
    expect(screen.getByText('Jeudi')).toBeInTheDocument();
    expect(screen.getByText('Vendredi')).toBeInTheDocument();
    expect(screen.getByText('Samedi')).toBeInTheDocument();
    
    // Vérifier que les repas sont affichés dans le calendrier
    expect(screen.getByText('Déjeuner')).toBeInTheDocument();
    expect(screen.getByText('Dîner')).toBeInTheDocument();
    expect(screen.getByText('Tajine de poulet')).toBeInTheDocument();
    expect(screen.getByText('Couscous aux légumes')).toBeInTheDocument();
  });

  it('opens create plan modal when clicking on new plan button', async () => {
    render(<PlanRepasPage />);
    
    // Cliquer sur le bouton pour créer un nouveau plan
    fireEvent.click(screen.getByText('Nouveau plan'));
    
    // Vérifier que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Créer un nouveau plan de repas')).toBeInTheDocument();
      expect(screen.getByLabelText('Nom du plan')).toBeInTheDocument();
      expect(screen.getByLabelText('Date de début')).toBeInTheDocument();
      expect(screen.getByLabelText('Date de fin')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Créer' })).toBeInTheDocument();
    });
  });

  it('creates a new plan when submitting the form', async () => {
    render(<PlanRepasPage />);
    
    // Cliquer sur le bouton pour créer un nouveau plan
    fireEvent.click(screen.getByText('Nouveau plan'));
    
    // Attendre que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Créer un nouveau plan de repas')).toBeInTheDocument();
    });
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Nom du plan'), {
      target: { value: 'Nouveau plan test' },
    });
    fireEvent.change(screen.getByLabelText('Date de début'), {
      target: { value: '2025-05-01' },
    });
    fireEvent.change(screen.getByLabelText('Date de fin'), {
      target: { value: '2025-05-07' },
    });
    
    // Mock de la fonction fetch pour la création du plan
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: '2',
        name: 'Nouveau plan test',
        startDate: '2025-05-01',
        endDate: '2025-05-07',
        repas: [],
      }),
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Créer' }));
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/plan-repas'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('Nouveau plan test'),
        })
      );
    });
  });

  it('generates shopping list when clicking on generate button', async () => {
    render(<PlanRepasPage />);
    
    // Attendre que le plan de repas soit chargé
    await waitFor(() => {
      expect(screen.getByText('Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Cliquer sur le bouton pour générer la liste de courses
    fireEvent.click(screen.getByText('Générer liste de courses'));
    
    // Mock de la fonction fetch pour la génération de la liste
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'shoppingList1',
        name: 'Liste pour Plan hebdomadaire',
        items: [
          { id: 'item1', name: 'poulet', quantity: 1, unit: 'kg' },
          { id: 'item2', name: 'olives', quantity: 200, unit: 'g' },
          { id: 'item3', name: 'semoule', quantity: 500, unit: 'g' },
        ],
      }),
    });
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/plan-repas/1/shopping-list'),
        expect.objectContaining({
          method: 'POST',
        })
      );
    });
    
    // Vérifier que la redirection vers la page de liste de courses a lieu
    expect(mockPush).toHaveBeenCalledWith('/dashboard/liste-courses');
  });

  it('displays nutritional statistics for the plan', async () => {
    render(<PlanRepasPage />);
    
    // Attendre que le plan de repas soit chargé
    await waitFor(() => {
      expect(screen.getByText('Plan hebdomadaire')).toBeInTheDocument();
    });
    
    // Vérifier que les statistiques nutritionnelles sont affichées
    expect(screen.getByText('Statistiques nutritionnelles')).toBeInTheDocument();
    expect(screen.getByText('Calories totales: 830')).toBeInTheDocument();
    expect(screen.getByText('Calories moyennes par jour: 118.6')).toBeInTheDocument();
  });
});
