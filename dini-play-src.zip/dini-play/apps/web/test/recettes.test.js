import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import RecettesPage from '../app/dashboard/recettes/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('RecettesPage', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
    
    // Mock de la fonction fetch pour les recettes
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
        },
        {
          id: '2',
          title: 'Couscous aux légumes',
          description: 'Un couscous végétarien savoureux',
          ingredients: ['semoule', 'carottes', 'courgettes', 'pois chiches'],
          prepTime: 20,
          cookTime: 45,
          servings: 6,
          calories: 380,
          image: 'couscous.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
        },
      ]),
    });
  });

  it('renders recettes page correctly', async () => {
    render(<RecettesPage />);
    
    // Vérifier que le titre de la page est présent
    expect(screen.getByText('Recettes du monde')).toBeInTheDocument();
    
    // Vérifier que les filtres sont présents
    expect(screen.getByPlaceholderText('Rechercher une recette...')).toBeInTheDocument();
    expect(screen.getByText('Filtrer par')).toBeInTheDocument();
    
    // Vérifier que les recettes sont chargées et affichées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
      expect(screen.getByText('Couscous aux légumes')).toBeInTheDocument();
    });
  });

  it('filters recettes by search query', async () => {
    render(<RecettesPage />);
    
    // Attendre que les recettes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
    });
    
    // Simuler une recherche
    fireEvent.change(screen.getByPlaceholderText('Rechercher une recette...'), {
      target: { value: 'tajine' },
    });
    
    // Mock de la fonction fetch pour les résultats filtrés
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
        },
      ]),
    });
    
    // Soumettre la recherche
    fireEvent.click(screen.getByRole('button', { name: 'Rechercher' }));
    
    // Vérifier que seule la recette correspondante est affichée
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
      expect(screen.queryByText('Couscous aux légumes')).not.toBeInTheDocument();
    });
  });

  it('filters recettes by cuisine', async () => {
    render(<RecettesPage />);
    
    // Attendre que les recettes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
    });
    
    // Sélectionner une cuisine
    fireEvent.change(screen.getByLabelText('Cuisine'), {
      target: { value: 'Marocaine' },
    });
    
    // Mock de la fonction fetch pour les résultats filtrés
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          title: 'Tajine de poulet aux olives',
          description: 'Un plat traditionnel marocain',
          ingredients: ['poulet', 'olives', 'citron confit'],
          prepTime: 30,
          cookTime: 60,
          servings: 4,
          calories: 450,
          image: 'tajine.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
        },
        {
          id: '2',
          title: 'Couscous aux légumes',
          description: 'Un couscous végétarien savoureux',
          ingredients: ['semoule', 'carottes', 'courgettes', 'pois chiches'],
          prepTime: 20,
          cookTime: 45,
          servings: 6,
          calories: 380,
          image: 'couscous.jpg',
          category: 'PLAT_PRINCIPAL',
          cuisine: 'Marocaine',
          isHalal: true,
        },
      ]),
    });
    
    // Appliquer le filtre
    fireEvent.click(screen.getByRole('button', { name: 'Appliquer les filtres' }));
    
    // Vérifier que les recettes correspondantes sont affichées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
      expect(screen.getByText('Couscous aux légumes')).toBeInTheDocument();
    });
  });

  it('navigates to recette details when clicking on a recette', async () => {
    render(<RecettesPage />);
    
    // Attendre que les recettes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
    });
    
    // Cliquer sur une recette
    fireEvent.click(screen.getByText('Tajine de poulet aux olives'));
    
    // Vérifier que la redirection a lieu
    expect(mockPush).toHaveBeenCalledWith('/dashboard/recettes/1');
  });

  it('displays nutritional information for each recette', async () => {
    render(<RecettesPage />);
    
    // Attendre que les recettes soient chargées
    await waitFor(() => {
      expect(screen.getByText('Tajine de poulet aux olives')).toBeInTheDocument();
    });
    
    // Vérifier que les informations nutritionnelles sont affichées
    expect(screen.getByText('450 calories')).toBeInTheDocument();
    expect(screen.getByText('380 calories')).toBeInTheDocument();
  });
});
