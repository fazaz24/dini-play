import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import ProfilPage from '../app/dashboard/profil/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('ProfilPage', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
    
    // Mock de la fonction fetch pour les données utilisateur
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'user1',
        email: 'user@example.com',
        firstName: 'Mohamed',
        lastName: 'Dupont',
        role: 'USER',
        preferences: {
          dietaryRestrictions: ['HALAL', 'NO_PORK'],
          allergies: ['NUTS'],
          favoriteCuisines: ['Marocaine', 'Libanaise'],
          calorieGoal: 2000
        },
        createdAt: '2025-01-15T10:00:00Z',
      }),
    });
  });

  it('renders profil page correctly', async () => {
    render(<ProfilPage />);
    
    // Vérifier que le titre de la page est présent
    expect(screen.getByText('Mon Profil')).toBeInTheDocument();
    
    // Vérifier que les sections du profil sont présentes
    expect(screen.getByText('Informations personnelles')).toBeInTheDocument();
    expect(screen.getByText('Préférences alimentaires')).toBeInTheDocument();
    expect(screen.getByText('Sécurité')).toBeInTheDocument();
    
    // Vérifier que les données utilisateur sont chargées et affichées
    await waitFor(() => {
      expect(screen.getByDisplayValue('Mohamed')).toBeInTheDocument();
      expect(screen.getByDisplayValue('Dupont')).toBeInTheDocument();
      expect(screen.getByDisplayValue('user@example.com')).toBeInTheDocument();
    });
  });

  it('updates personal information when submitting the form', async () => {
    render(<ProfilPage />);
    
    // Attendre que les données utilisateur soient chargées
    await waitFor(() => {
      expect(screen.getByDisplayValue('Mohamed')).toBeInTheDocument();
    });
    
    // Modifier les champs du formulaire
    fireEvent.change(screen.getByDisplayValue('Mohamed'), {
      target: { value: 'Ahmed' },
    });
    fireEvent.change(screen.getByDisplayValue('Dupont'), {
      target: { value: 'Martin' },
    });
    
    // Mock de la fonction fetch pour la mise à jour
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'user1',
        email: 'user@example.com',
        firstName: 'Ahmed',
        lastName: 'Martin',
        role: 'USER',
      }),
    });
    
    // Soumettre le formulaire
    const saveButton = screen.getByRole('button', { name: 'Enregistrer les modifications' });
    fireEvent.click(saveButton);
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/users/profile'),
        expect.objectContaining({
          method: 'PATCH',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('Ahmed'),
        })
      );
    });
    
    // Vérifier que le message de succès s'affiche
    expect(screen.getByText('Profil mis à jour avec succès')).toBeInTheDocument();
  });

  it('updates dietary preferences when submitting the form', async () => {
    render(<ProfilPage />);
    
    // Attendre que les données utilisateur soient chargées
    await waitFor(() => {
      expect(screen.getByText('Préférences alimentaires')).toBeInTheDocument();
    });
    
    // Cliquer sur l'onglet des préférences alimentaires
    fireEvent.click(screen.getByText('Préférences alimentaires'));
    
    // Vérifier que les préférences sont affichées
    await waitFor(() => {
      expect(screen.getByLabelText('Halal')).toBeInTheDocument();
      expect(screen.getByLabelText('Objectif calorique quotidien')).toBeInTheDocument();
    });
    
    // Modifier les préférences
    fireEvent.change(screen.getByLabelText('Objectif calorique quotidien'), {
      target: { value: '1800' },
    });
    
    // Ajouter une cuisine favorite
    fireEvent.change(screen.getByLabelText('Cuisines favorites'), {
      target: { value: 'Turque' },
    });
    fireEvent.click(screen.getByText('Ajouter'));
    
    // Mock de la fonction fetch pour la mise à jour
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: 'user1',
        preferences: {
          dietaryRestrictions: ['HALAL', 'NO_PORK'],
          allergies: ['NUTS'],
          favoriteCuisines: ['Marocaine', 'Libanaise', 'Turque'],
          calorieGoal: 1800
        },
      }),
    });
    
    // Soumettre le formulaire
    const saveButton = screen.getByRole('button', { name: 'Enregistrer les préférences' });
    fireEvent.click(saveButton);
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/users/preferences'),
        expect.objectContaining({
          method: 'PATCH',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('1800'),
        })
      );
    });
    
    // Vérifier que le message de succès s'affiche
    expect(screen.getByText('Préférences mises à jour avec succès')).toBeInTheDocument();
  });

  it('changes password when submitting the security form', async () => {
    render(<ProfilPage />);
    
    // Attendre que les données utilisateur soient chargées
    await waitFor(() => {
      expect(screen.getByText('Sécurité')).toBeInTheDocument();
    });
    
    // Cliquer sur l'onglet de sécurité
    fireEvent.click(screen.getByText('Sécurité'));
    
    // Vérifier que le formulaire de changement de mot de passe est affiché
    await waitFor(() => {
      expect(screen.getByLabelText('Mot de passe actuel')).toBeInTheDocument();
      expect(screen.getByLabelText('Nouveau mot de passe')).toBeInTheDocument();
      expect(screen.getByLabelText('Confirmer le nouveau mot de passe')).toBeInTheDocument();
    });
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Mot de passe actuel'), {
      target: { value: 'currentPassword123' },
    });
    fireEvent.change(screen.getByLabelText('Nouveau mot de passe'), {
      target: { value: 'newPassword123' },
    });
    fireEvent.change(screen.getByLabelText('Confirmer le nouveau mot de passe'), {
      target: { value: 'newPassword123' },
    });
    
    // Mock de la fonction fetch pour le changement de mot de passe
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        message: 'Mot de passe mis à jour avec succès',
      }),
    });
    
    // Soumettre le formulaire
    const changeButton = screen.getByRole('button', { name: 'Changer le mot de passe' });
    fireEvent.click(changeButton);
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/auth/change-password'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('newPassword123'),
        })
      );
    });
    
    // Vérifier que le message de succès s'affiche
    expect(screen.getByText('Mot de passe mis à jour avec succès')).toBeInTheDocument();
  });

  it('displays user statistics in the profile', async () => {
    // Mock supplémentaire pour les statistiques
    global.fetch = jest.fn()
      .mockImplementationOnce(() => Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
          id: 'user1',
          email: 'user@example.com',
          firstName: 'Mohamed',
          lastName: 'Dupont',
          role: 'USER',
          preferences: {
            dietaryRestrictions: ['HALAL', 'NO_PORK'],
            allergies: ['NUTS'],
            favoriteCuisines: ['Marocaine', 'Libanaise'],
            calorieGoal: 2000
          },
          createdAt: '2025-01-15T10:00:00Z',
        }),
      }))
      .mockImplementationOnce(() => Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
          recetteCount: 15,
          planRepasCount: 8,
          averageCalories: 1850,
          favoriteCategory: 'PLAT_PRINCIPAL',
          favoriteCuisine: 'Marocaine',
        }),
      }));
    
    render(<ProfilPage />);
    
    // Attendre que les données utilisateur soient chargées
    await waitFor(() => {
      expect(screen.getByText('Statistiques')).toBeInTheDocument();
    });
    
    // Cliquer sur l'onglet des statistiques
    fireEvent.click(screen.getByText('Statistiques'));
    
    // Vérifier que les statistiques sont affichées
    await waitFor(() => {
      expect(screen.getByText('15 recettes sauvegardées')).toBeInTheDocument();
      expect(screen.getByText('8 plans de repas créés')).toBeInTheDocument();
      expect(screen.getByText('1850 calories en moyenne par jour')).toBeInTheDocument();
      expect(screen.getByText('Catégorie préférée: Plat principal')).toBeInTheDocument();
      expect(screen.getByText('Cuisine préférée: Marocaine')).toBeInTheDocument();
    });
  });
});
