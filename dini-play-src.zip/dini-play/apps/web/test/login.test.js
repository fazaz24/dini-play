import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import LoginPage from '../app/auth/login/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('LoginPage', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
  });

  it('renders login form correctly', () => {
    render(<LoginPage />);
    
    // Vérifier que les éléments du formulaire sont présents
    expect(screen.getByText('Connexion')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Mot de passe')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Se connecter' })).toBeInTheDocument();
    expect(screen.getByText('Pas encore de compte?')).toBeInTheDocument();
    expect(screen.getByText('Créer un compte')).toBeInTheDocument();
  });

  it('validates form inputs', async () => {
    render(<LoginPage />);
    
    // Soumettre le formulaire sans remplir les champs
    fireEvent.click(screen.getByRole('button', { name: 'Se connecter' }));
    
    // Vérifier que les messages d'erreur s'affichent
    await waitFor(() => {
      expect(screen.getByText('L\'email est requis')).toBeInTheDocument();
      expect(screen.getByText('Le mot de passe est requis')).toBeInTheDocument();
    });
    
    // Remplir l'email avec un format invalide
    fireEvent.change(screen.getByLabelText('Email'), {
      target: { value: 'invalid-email' },
    });
    
    // Vérifier que le message d'erreur pour l'email s'affiche
    await waitFor(() => {
      expect(screen.getByText('Format d\'email invalide')).toBeInTheDocument();
    });
  });

  it('submits form with valid data', async () => {
    // Mock de la fonction fetch
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        access_token: 'test-token',
        user: { id: '1', email: 'test@example.com' }
      }),
    });
    
    render(<LoginPage />);
    
    // Remplir le formulaire avec des données valides
    fireEvent.change(screen.getByLabelText('Email'), {
      target: { value: 'test@example.com' },
    });
    fireEvent.change(screen.getByLabelText('Mot de passe'), {
      target: { value: 'password123' },
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Se connecter' }));
    
    // Vérifier que la redirection a lieu après la connexion réussie
    await waitFor(() => {
      expect(mockPush).toHaveBeenCalledWith('/dashboard');
    });
  });

  it('handles login error', async () => {
    // Mock de la fonction fetch pour simuler une erreur
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: jest.fn().mockResolvedValue({
        message: 'Email ou mot de passe incorrect',
      }),
    });
    
    render(<LoginPage />);
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Email'), {
      target: { value: 'test@example.com' },
    });
    fireEvent.change(screen.getByLabelText('Mot de passe'), {
      target: { value: 'wrongpassword' },
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Se connecter' }));
    
    // Vérifier que le message d'erreur s'affiche
    await waitFor(() => {
      expect(screen.getByText('Email ou mot de passe incorrect')).toBeInTheDocument();
    });
  });

  it('navigates to register page when clicking on create account link', () => {
    render(<LoginPage />);
    
    // Cliquer sur le lien pour créer un compte
    fireEvent.click(screen.getByText('Créer un compte'));
    
    // Vérifier que la redirection a lieu
    expect(mockPush).toHaveBeenCalledWith('/auth/register');
  });
});
