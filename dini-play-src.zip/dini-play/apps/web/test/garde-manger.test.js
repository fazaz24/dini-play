import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import GardeManger from '../app/dashboard/garde-manger/page';
import { useRouter } from 'next/navigation';

// Mock des dépendances
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

describe('GardeManger', () => {
  const mockPush = jest.fn();
  
  beforeEach(() => {
    useRouter.mockReturnValue({
      push: mockPush,
    });
    
    // Mock de la fonction fetch pour les ingrédients du garde-manger
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue([
        {
          id: '1',
          name: 'Poulet',
          quantity: 1,
          unit: 'kg',
          category: 'Viandes',
          expirationDate: '2025-05-15',
          userId: 'user1',
        },
        {
          id: '2',
          name: 'Riz',
          quantity: 2,
          unit: 'kg',
          category: 'Céréales',
          expirationDate: '2026-04-20',
          userId: 'user1',
        },
        {
          id: '3',
          name: 'Lait',
          quantity: 1,
          unit: 'L',
          category: 'Produits laitiers',
          expirationDate: '2025-05-01',
          userId: 'user1',
        },
      ]),
    });
  });

  it('renders garde-manger page correctly', async () => {
    render(<GardeManger />);
    
    // Vérifier que le titre de la page est présent
    expect(screen.getByText('Mon Garde-Manger')).toBeInTheDocument();
    
    // Vérifier que le bouton pour ajouter un ingrédient est présent
    expect(screen.getByText('Ajouter un ingrédient')).toBeInTheDocument();
    
    // Vérifier que les ingrédients sont chargés et affichés
    await waitFor(() => {
      expect(screen.getByText('Poulet')).toBeInTheDocument();
      expect(screen.getByText('Riz')).toBeInTheDocument();
      expect(screen.getByText('Lait')).toBeInTheDocument();
    });
  });

  it('displays ingredients grouped by category', async () => {
    render(<GardeManger />);
    
    // Attendre que les ingrédients soient chargés
    await waitFor(() => {
      expect(screen.getByText('Poulet')).toBeInTheDocument();
    });
    
    // Vérifier que les catégories sont affichées
    expect(screen.getByText('Viandes')).toBeInTheDocument();
    expect(screen.getByText('Céréales')).toBeInTheDocument();
    expect(screen.getByText('Produits laitiers')).toBeInTheDocument();
    
    // Vérifier que les ingrédients sont regroupés par catégorie
    const viandesSection = screen.getByText('Viandes').closest('section');
    const cerealesSection = screen.getByText('Céréales').closest('section');
    const laitiersSection = screen.getByText('Produits laitiers').closest('section');
    
    expect(viandesSection).toContainElement(screen.getByText('Poulet'));
    expect(cerealesSection).toContainElement(screen.getByText('Riz'));
    expect(laitiersSection).toContainElement(screen.getByText('Lait'));
  });

  it('opens add ingredient modal when clicking on add button', async () => {
    render(<GardeManger />);
    
    // Cliquer sur le bouton pour ajouter un ingrédient
    fireEvent.click(screen.getByText('Ajouter un ingrédient'));
    
    // Vérifier que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Ajouter un nouvel ingrédient')).toBeInTheDocument();
      expect(screen.getByLabelText('Nom')).toBeInTheDocument();
      expect(screen.getByLabelText('Quantité')).toBeInTheDocument();
      expect(screen.getByLabelText('Unité')).toBeInTheDocument();
      expect(screen.getByLabelText('Catégorie')).toBeInTheDocument();
      expect(screen.getByLabelText('Date d\'expiration')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Ajouter' })).toBeInTheDocument();
    });
  });

  it('adds a new ingredient when submitting the form', async () => {
    render(<GardeManger />);
    
    // Cliquer sur le bouton pour ajouter un ingrédient
    fireEvent.click(screen.getByText('Ajouter un ingrédient'));
    
    // Attendre que le modal s'ouvre
    await waitFor(() => {
      expect(screen.getByText('Ajouter un nouvel ingrédient')).toBeInTheDocument();
    });
    
    // Remplir le formulaire
    fireEvent.change(screen.getByLabelText('Nom'), {
      target: { value: 'Tomates' },
    });
    fireEvent.change(screen.getByLabelText('Quantité'), {
      target: { value: '500' },
    });
    fireEvent.change(screen.getByLabelText('Unité'), {
      target: { value: 'g' },
    });
    fireEvent.change(screen.getByLabelText('Catégorie'), {
      target: { value: 'Légumes' },
    });
    fireEvent.change(screen.getByLabelText('Date d\'expiration'), {
      target: { value: '2025-05-10' },
    });
    
    // Mock de la fonction fetch pour l'ajout d'ingrédient
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        id: '4',
        name: 'Tomates',
        quantity: 500,
        unit: 'g',
        category: 'Légumes',
        expirationDate: '2025-05-10',
        userId: 'user1',
      }),
    });
    
    // Soumettre le formulaire
    fireEvent.click(screen.getByRole('button', { name: 'Ajouter' }));
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/pantry'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
          body: expect.stringContaining('Tomates'),
        })
      );
    });
  });

  it('displays expiration warnings for ingredients', async () => {
    render(<GardeManger />);
    
    // Attendre que les ingrédients soient chargés
    await waitFor(() => {
      expect(screen.getByText('Poulet')).toBeInTheDocument();
    });
    
    // Vérifier que les avertissements d'expiration sont affichés
    expect(screen.getByText('Expire bientôt')).toBeInTheDocument();
    
    // Le lait expire le plus tôt, il devrait avoir un avertissement
    const laitItem = screen.getByText('Lait').closest('div');
    expect(laitItem).toHaveClass('expiration-warning');
  });

  it('deletes an ingredient when clicking on delete button', async () => {
    render(<GardeManger />);
    
    // Attendre que les ingrédients soient chargés
    await waitFor(() => {
      expect(screen.getByText('Poulet')).toBeInTheDocument();
    });
    
    // Mock de la fonction fetch pour la suppression
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
    });
    
    // Cliquer sur le bouton de suppression pour le poulet
    const deleteButton = screen.getAllByRole('button', { name: 'Supprimer' })[0];
    fireEvent.click(deleteButton);
    
    // Vérifier que la confirmation de suppression apparaît
    expect(screen.getByText('Êtes-vous sûr de vouloir supprimer cet ingrédient ?')).toBeInTheDocument();
    
    // Confirmer la suppression
    fireEvent.click(screen.getByRole('button', { name: 'Confirmer' }));
    
    // Vérifier que la requête fetch a été appelée avec les bons paramètres
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/pantry/1'),
        expect.objectContaining({
          method: 'DELETE',
        })
      );
    });
  });
});
