# Dini Play - Guide de déploiement et d'utilisation

Ce document fournit les instructions pour déployer et utiliser l'application Dini Play, un planificateur de repas Halal.

## Structure du projet

Dini Play est une application full-stack avec une architecture monorepo utilisant Turborepo :

- **Backend** : NestJS + Prisma + PostgreSQL
- **Frontend** : Next.js + Tailwind CSS

## Déploiement sur Vercel

Tous les fichiers de configuration nécessaires pour le déploiement sur Vercel ont été préparés :

- `vercel.json` et `vercel.yaml` : Configuration du déploiement
- `.env.production` : Variables d'environnement pour la production
- `scripts/prepare-vercel.js` : Script de préparation pour le déploiement

Pour déployer l'application, suivez les instructions détaillées dans le fichier `DEPLOYMENT.md`.

## Connexion à un dépôt Git

Pour faciliter le déploiement continu, nous recommandons de connecter ce projet à un dépôt Git :

```bash
# Initialiser un dépôt Git
git init

# Ajouter tous les fichiers
git add .

# Créer un commit initial
git commit -m "Initial commit"

# Connecter à votre dépôt distant
git remote add origin <URL_DE_VOTRE_DEPOT>

# Pousser les modifications
git push -u origin main
```

## Configuration de la base de données

Pour le déploiement en production, vous devrez configurer une base de données PostgreSQL et mettre à jour la variable d'environnement `DATABASE_URL` dans les fichiers de configuration.

## Fonctionnalités principales

L'application Dini Play offre les fonctionnalités suivantes :

1. **Authentification** : Inscription, connexion et gestion de profil
2. **Recettes** : Recherche, filtrage et gestion de recettes Halal
3. **Planification de repas** : Création de plans de repas hebdomadaires
4. **Garde-manger** : Suivi des ingrédients disponibles
5. **Liste de courses** : Génération automatique basée sur les plans de repas
6. **Recommandations** : Suggestions de recettes personnalisées

## Maintenance et mises à jour

Pour mettre à jour l'application déployée, il suffit de pousser les modifications sur votre dépôt Git. Vercel détectera automatiquement les changements et redéploiera l'application.

## Support

En cas de problème avec le déploiement ou l'utilisation de l'application, consultez la documentation Vercel ou contactez votre équipe de développement.
