# Déploiement de Dini Play sur Vercel

Ce document explique comment déployer l'application Dini Play sur Vercel.

## Prérequis

1. Un compte Vercel
2. Git installé sur votre machine
3. Le CLI Vercel installé (optionnel)

## Étapes de déploiement

### 1. Préparation du projet

Avant de déployer, exécutez le script de préparation pour Vercel :

```bash
npm run prepare-vercel
```

Ce script va créer les fichiers de configuration nécessaires pour le déploiement sur Vercel.

### 2. Configuration de la base de données

Pour le déploiement en production, vous devrez configurer une base de données PostgreSQL. Vous pouvez utiliser :

- Vercel Postgres
- Supabase
- Railway
- Neon
- Tout autre fournisseur PostgreSQL

Une fois votre base de données configurée, mettez à jour la variable d'environnement `DATABASE_URL` dans le fichier `vercel.json` et dans `.env.production`.

### 3. Déploiement via l'interface Vercel

1. Connectez-vous à votre compte Vercel
2. Importez votre projet Git
3. Configurez les variables d'environnement suivantes :
   - `DATABASE_URL` : URL de connexion à votre base de données PostgreSQL
   - `JWT_SECRET` : Clé secrète pour la génération des tokens JWT (utilisez une valeur sécurisée)
   - `FRONTEND_URL` : URL de votre frontend déployé

4. Cliquez sur "Deploy"

### 4. Déploiement via CLI Vercel

Si vous préférez utiliser le CLI Vercel :

```bash
# Installation du CLI Vercel (si pas déjà installé)
npm install -g vercel

# Connexion à votre compte Vercel
vercel login

# Déploiement
vercel
```

Suivez les instructions à l'écran pour configurer votre projet.

### 5. Configuration des domaines personnalisés

Une fois le déploiement réussi, vous pouvez configurer un domaine personnalisé dans les paramètres du projet sur Vercel.

## Vérification du déploiement

Après le déploiement, vérifiez que :

1. Le frontend est accessible à l'URL de déploiement
2. L'API backend répond correctement aux requêtes
3. La connexion à la base de données fonctionne
4. Les fonctionnalités d'authentification fonctionnent

## Mise à jour de l'application

Pour mettre à jour l'application déployée, il suffit de pousser les modifications sur votre dépôt Git. Vercel détectera automatiquement les changements et redéploiera l'application.

## Surveillance et maintenance

Utilisez le tableau de bord Vercel pour :
- Surveiller les performances de l'application
- Consulter les logs
- Configurer des alertes
- Gérer les environnements (production, preview, development)
