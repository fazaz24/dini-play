# Dini Play - Composants UI partagés

Ce package contient les composants UI partagés pour l'application Dini Play, utilisables à la fois dans le frontend principal et d'autres applications potentielles.

## Composants

Les composants sont basés sur Tailwind CSS et Shadcn UI pour assurer une expérience utilisateur cohérente et accessible.

## Installation

```bash
npm install
```

## Utilisation

Importez les composants depuis ce package dans vos applications :

```tsx
import { Button } from "@dini-play/ui";
```
