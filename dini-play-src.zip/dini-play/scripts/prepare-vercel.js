// scripts/prepare-vercel.js
const fs = require('fs');
const path = require('path');

// Créer le dossier scripts s'il n'existe pas
if (!fs.existsSync(path.join(process.cwd(), 'scripts'))) {
  fs.mkdirSync(path.join(process.cwd(), 'scripts'));
}

// Fonction pour copier les fichiers de configuration nécessaires
function copyConfigFiles() {
  console.log('Préparation des fichiers pour le déploiement Vercel...');
  
  // Vérifier si le fichier vercel.json existe déjà à la racine
  if (!fs.existsSync(path.join(process.cwd(), 'vercel.json'))) {
    console.log('Création du fichier vercel.json...');
    
    const vercelConfig = {
      "version": 2,
      "builds": [
        { "src": "apps/web/package.json", "use": "@vercel/next" },
        { "src": "apps/api/src/main.ts", "use": "@vercel/node" }
      ],
      "routes": [
        { "src": "/api/(.*)", "dest": "apps/api/src/main.ts" },
        { "src": "/(.*)", "dest": "apps/web/$1" }
      ],
      "env": {
        "DATABASE_URL": "postgresql://postgres:postgres@localhost:5432/dini_play?schema=public",
        "JWT_SECRET": "dini-play-secret-key-for-production"
      }
    };
    
    fs.writeFileSync(
      path.join(process.cwd(), 'vercel.json'),
      JSON.stringify(vercelConfig, null, 2)
    );
  }
  
  // Créer un fichier .env.production pour le frontend
  console.log('Création du fichier .env.production pour le frontend...');
  const frontendEnv = 
`NEXT_PUBLIC_API_URL=https://dini-play.vercel.app/api
NEXT_PUBLIC_APP_URL=https://dini-play.vercel.app`;
  
  fs.writeFileSync(
    path.join(process.cwd(), 'apps/web/.env.production'),
    frontendEnv
  );
  
  // Créer un fichier .env.production pour le backend
  console.log('Création du fichier .env.production pour le backend...');
  const backendEnv = 
`DATABASE_URL=postgresql://postgres:postgres@localhost:5432/dini_play?schema=public
JWT_SECRET=dini-play-secret-key-for-production
FRONTEND_URL=https://dini-play.vercel.app`;
  
  fs.writeFileSync(
    path.join(process.cwd(), 'apps/api/.env.production'),
    backendEnv
  );
  
  console.log('Préparation terminée avec succès!');
}

// Exécuter la fonction
copyConfigFiles();
