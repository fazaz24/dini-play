# Configuration de déploiement pour l'intégration de Google AI Studio

Ce document décrit les modifications nécessaires à la configuration de déploiement de l'application Dini Play pour prendre en compte l'intégration de Google AI Studio.

## Variables d'environnement

### Fichier .env.production

Ajoutez les variables d'environnement suivantes au fichier `/home/ubuntu/dini-play/apps/api/.env.production` :

```
# Google AI Studio API
GOOGLE_AI_API_KEY=votre_clé_api_ici
GOOGLE_AI_MODEL=gemini-2.0-flash
```

## Configuration Vercel

### Fichier vercel.json

Mettez à jour le fichier `vercel.json` pour inclure les variables d'environnement nécessaires à l'API Google AI Studio :

```json
{
  "buildCommand": "cd ../.. && npm run build",
  "outputDirectory": "../../dist/apps/api",
  "devCommand": "cd ../.. && npm run start:dev",
  "installCommand": "cd ../.. && npm install",
  "env": {
    "GOOGLE_AI_API_KEY": "@google_ai_api_key",
    "GOOGLE_AI_MODEL": "gemini-2.0-flash"
  }
}
```

### Secrets Vercel

Vous devrez ajouter la clé API Google AI Studio comme secret dans votre projet Vercel :

1. Accédez au tableau de bord Vercel
2. Sélectionnez votre projet Dini Play
3. Allez dans "Settings" > "Environment Variables"
4. Ajoutez une nouvelle variable d'environnement :
   - Nom : `GOOGLE_AI_API_KEY`
   - Valeur : Votre clé API Google AI Studio
   - Environnements : Production, Preview, Development

## Optimisation des performances

### Mise en cache

Pour optimiser les performances et réduire le nombre d'appels à l'API Google AI Studio, ajoutez la configuration de mise en cache suivante au fichier `apps/api/src/ai/ai.module.ts` :

```typescript
import { Module, CacheModule } from '@nestjs/common';
import { ThrottlerModule } from '@nestjs/throttler';
import * as redisStore from 'cache-manager-redis-store';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AiService } from './ai.service';
import { AiController } from './ai.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    ThrottlerModule.forRoot({
      ttl: 60,
      limit: 10, // Limite à 10 requêtes par minute
    }),
    CacheModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        store: redisStore,
        host: configService.get('REDIS_HOST', 'localhost'),
        port: configService.get('REDIS_PORT', 6379),
        ttl: 3600, // Mise en cache pendant 1 heure
      }),
    }),
  ],
  controllers: [AiController],
  providers: [AiService],
  exports: [AiService],
})
export class AiModule {}
```

### Gestion des quotas

Pour éviter de dépasser les quotas de l'API Google AI Studio, ajoutez la dépendance Redis et configurez les variables d'environnement suivantes :

```
# Redis pour la mise en cache
REDIS_HOST=votre_hôte_redis
REDIS_PORT=6379
```

## Surveillance et journalisation

### Configuration de la journalisation

Ajoutez la configuration suivante au fichier `apps/api/src/main.ts` pour améliorer la journalisation des appels à l'API Google AI Studio :

```typescript
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'debug', 'verbose'], // Activer tous les niveaux de journalisation
  });
  
  // Configuration existante...
  
  // Configuration de Swagger
  const config = new DocumentBuilder()
    .setTitle('Dini Play API')
    .setDescription('API pour l\'application de planification de repas Halal Dini Play')
    .setVersion('1.0')
    .addTag('auth')
    .addTag('users')
    .addTag('recettes')
    .addTag('plan-repas')
    .addTag('pantry')
    .addTag('shopping-list')
    .addTag('recommendations')
    .addTag('admin')
    .addTag('ai') // Ajout du tag pour le module IA
    .addBearerAuth()
    .build();
  
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);
  
  // Validation
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    transform: true,
    forbidNonWhitelisted: true,
  }));
  
  // CORS
  app.enableCors();
  
  await app.listen(process.env.PORT || 3000);
  Logger.log(`Application is running on: ${await app.getUrl()}`);
}

bootstrap();
```

## Déploiement continu

### Mise à jour du script de préparation Vercel

Mettez à jour le fichier `scripts/prepare-vercel.js` pour inclure les dépendances nécessaires à l'intégration de Google AI Studio :

```javascript
const fs = require('fs');
const path = require('path');

// Chemin vers le package.json de l'API
const apiPackageJsonPath = path.join(__dirname, '../apps/api/package.json');

// Lire le fichier package.json
const packageJson = JSON.parse(fs.readFileSync(apiPackageJsonPath, 'utf8'));

// Ajouter les dépendances nécessaires pour Google AI Studio
if (!packageJson.dependencies['@google/generative-ai']) {
  packageJson.dependencies['@google/generative-ai'] = '^0.2.1';
}

if (!packageJson.dependencies['cache-manager-redis-store']) {
  packageJson.dependencies['cache-manager-redis-store'] = '^2.0.0';
}

if (!packageJson.dependencies['@nestjs/throttler']) {
  packageJson.dependencies['@nestjs/throttler'] = '^5.1.1';
}

// Écrire les modifications dans le fichier package.json
fs.writeFileSync(apiPackageJsonPath, JSON.stringify(packageJson, null, 2));

console.log('Le fichier package.json a été mis à jour avec les dépendances pour Google AI Studio');
```

## Résumé des modifications

1. Ajout des variables d'environnement pour l'API Google AI Studio
2. Mise à jour de la configuration Vercel
3. Configuration de la mise en cache avec Redis
4. Amélioration de la journalisation
5. Mise à jour du script de préparation pour le déploiement continu

Ces modifications permettront de déployer efficacement l'application Dini Play avec l'intégration de Google AI Studio, tout en optimisant les performances et en respectant les quotas de l'API.
