```mermaid
sequenceDiagram
    participant U as Utilisateur
    participant F as Frontend Next.js
    participant B as Backend NestJS
    participant AI as Module IA
    participant G as Google AI Studio API
    
    U->>F: Demande d'analyse de recette
    F->>B: POST /ai/analyze-recipe
    B->>AI: analyzeRecipe()
    AI->>G: Appel API Gemini avec Function Calling
    G-->>AI: Résultat d'analyse
    AI-->>B: Données structurées
    B-->>F: Réponse JSON
    F-->>U: Affichage des résultats
    
    U->>F: Demande de recommandations
    F->>B: POST /ai/generate-recommendations
    B->>AI: generateRecommendations()
    AI->>G: Appel API Gemini
    G-->>AI: Suggestions de recettes
    AI-->>B: Liste de recommandations
    B-->>F: Réponse JSON
    F-->>U: Affichage des recommandations
    
    U->>F: Demande de plan de repas
    F->>B: POST /ai/generate-meal-plan
    B->>AI: generateMealPlan()
    AI->>G: Appel API Gemini avec Function Calling
    G-->>AI: Plan de repas généré
    AI-->>B: Données structurées
    B-->>F: Réponse JSON
    F-->>U: Affichage du plan de repas
    
    U->>F: Question à l'assistant
    F->>B: POST /ai/chat
    B->>AI: processChat()
    AI->>G: Appel API Gemini
    G-->>AI: Réponse générée
    AI-->>B: Réponse formatée
    B-->>F: Réponse JSON
    F-->>U: Affichage de la réponse
```
