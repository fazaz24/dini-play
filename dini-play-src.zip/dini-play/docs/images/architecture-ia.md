```mermaid
graph TD
    A[Application Dini Play] --> B[Backend NestJS]
    A --> C[Frontend Next.js]
    
    B --> D[Module IA]
    B --> E[Module Recettes]
    B --> F[Module Plan Repas]
    B --> G[Module Utilisateurs]
    B --> H[Module Authentification]
    
    D --> I[Google AI Studio API]
    
    D --> J[Service IA]
    J --> K[Analyse de Recettes]
    J --> L[Recommandations]
    J --> M[Plan de Repas IA]
    J --> N[Analyse Nutritionnelle]
    J --> O[Assistant Conversationnel]
    
    I --> P[Modèle Gemini]
    P --> Q[Function Calling]
    P --> R[Génération de Texte]
    P --> S[Compréhension d'Images]
    
    E <--> D
    F <--> D
    G <--> D
```
