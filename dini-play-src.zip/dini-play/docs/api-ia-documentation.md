# Documentation de l'API IA pour Dini Play

## Introduction

Cette documentation décrit l'intégration de Google AI Studio (API Gemini) dans l'application Dini Play. Le module IA enrichit l'application avec des fonctionnalités d'intelligence artificielle avancées pour améliorer l'expérience utilisateur dans la planification de repas Halal.

## Configuration

### Prérequis

Pour utiliser le module IA, vous devez disposer d'une clé API Google AI Studio. Cette clé doit être configurée dans le fichier `.env` :

```
# Google AI Studio API
GOOGLE_AI_API_KEY=votre_clé_api_ici
GOOGLE_AI_MODEL=gemini-2.0-flash
```

### Installation des dépendances

Le module IA nécessite l'installation de la bibliothèque Google Generative AI :

```bash
npm install @google/generative-ai
```

## Architecture du module IA

Le module IA est structuré comme suit :

```
/apps/api/src/ai/
├── ai.module.ts          # Module NestJS pour l'IA
├── ai.service.ts         # Service contenant la logique d'IA
├── ai.controller.ts      # Contrôleur exposant les endpoints API
├── dto/                  # Objets de transfert de données
├── interfaces/           # Interfaces TypeScript
└── functions/            # Définitions des fonctions pour Function Calling
```

## Endpoints API

### Analyse de recettes

Analyse une recette pour déterminer ses caractéristiques nutritionnelles et culturelles.

**Endpoint:** `POST /ai/analyze-recipe`

**Corps de la requête:**
```json
{
  "title": "Couscous aux légumes",
  "description": "Un plat traditionnel nord-africain",
  "ingredients": [
    { "name": "couscous", "quantity": "200g" },
    { "name": "carottes", "quantity": "2" }
  ],
  "steps": [
    { "description": "Préparer les légumes" },
    { "description": "Cuire le couscous" }
  ]
}
```

**Réponse:**
```json
{
  "nutritionalValue": {
    "calories": 350,
    "protein": 10,
    "carbs": 70,
    "fat": 5
  },
  "cuisineOrigin": "Afrique du Nord",
  "halalCompliance": true,
  "difficultyLevel": "easy",
  "preparationTime": 30
}
```

### Recommandations personnalisées

Génère des recommandations de recettes personnalisées basées sur les préférences de l'utilisateur.

**Endpoint:** `POST /ai/generate-recommendations`

**Corps de la requête:**
```json
{
  "userPreferences": {
    "dietaryPreferences": ["halal", "végétarien"],
    "excludedIngredients": ["porc", "alcool"],
    "preferredCuisines": ["Moyen-Orient", "Asie du Sud"]
  },
  "recentRecipes": [
    { "title": "Houmous", "id": "1" },
    { "title": "Taboulé", "id": "2" }
  ]
}
```

**Réponse:**
```json
[
  {
    "title": "Couscous aux légumes",
    "description": "Un plat traditionnel nord-africain avec des légumes de saison",
    "difficultyLevel": "medium",
    "preparationTime": 45,
    "calories": 450
  },
  {
    "title": "Poulet Tikka Masala",
    "description": "Un plat indien épicé avec du poulet mariné",
    "difficultyLevel": "medium",
    "preparationTime": 60,
    "calories": 520
  }
]
```

### Génération de plan de repas

Génère un plan de repas personnalisé en fonction des préférences de l'utilisateur.

**Endpoint:** `POST /ai/generate-meal-plan`

**Corps de la requête:**
```json
{
  "userId": "user-123",
  "duration": 3,
  "preferences": {
    "dietaryPreferences": ["halal"],
    "maxCaloriesPerMeal": 600,
    "excludedIngredients": ["fruits de mer"]
  }
}
```

**Réponse:**
```json
{
  "userId": "user-123",
  "duration": 3,
  "startDate": "2025-04-26T14:00:00.000Z",
  "meals": [
    {
      "day": 1,
      "breakfast": { "title": "Omelette aux légumes", "calories": 350 },
      "lunch": { "title": "Salade de quinoa", "calories": 420 },
      "dinner": { "title": "Saumon grillé", "calories": 520 }
    },
    {
      "day": 2,
      "breakfast": { "title": "Porridge aux fruits", "calories": 300 },
      "lunch": { "title": "Wrap au poulet", "calories": 480 },
      "dinner": { "title": "Poulet rôti", "calories": 550 }
    },
    {
      "day": 3,
      "breakfast": { "title": "Omelette aux légumes", "calories": 350 },
      "lunch": { "title": "Soupe de lentilles", "calories": 380 },
      "dinner": { "title": "Curry de légumes", "calories": 420 }
    }
  ]
}
```

### Analyse nutritionnelle

Analyse la valeur nutritionnelle d'un aliment ou d'une recette.

**Endpoint:** `POST /ai/analyze-nutrition`

**Corps de la requête:**
```json
{
  "name": "Salade de quinoa",
  "ingredients": ["quinoa", "tomates", "concombres", "feta", "huile d'olive"]
}
```

**Réponse:**
```json
{
  "calories": 320,
  "macronutrients": {
    "protein": 12,
    "carbs": 45,
    "fat": 15,
    "fiber": 8
  },
  "micronutrients": {
    "vitamins": ["A", "C", "E"],
    "minerals": ["Calcium", "Iron"]
  },
  "healthScore": 85
}
```

### Assistant conversationnel

Permet d'interagir avec l'assistant IA pour obtenir des recommandations, des informations nutritionnelles ou de l'aide pour la planification de repas.

**Endpoint:** `POST /ai/chat`

**Corps de la requête:**
```json
{
  "message": "Je cherche une recette de poulet halal",
  "userId": "user-123"
}
```

**Réponse:**
```json
{
  "response": "Voici quelques idées de recettes halal que vous pourriez apprécier: Couscous aux légumes, Poulet Tikka Masala, ou Kebab d'agneau. Souhaitez-vous plus de détails sur l'une de ces recettes?",
  "functionCalled": false
}
```

## Fonctionnalités IA spécifiques

### Function Calling avec Google AI Studio

Le module IA utilise la fonctionnalité Function Calling de l'API Gemini pour permettre au modèle d'IA d'appeler des fonctions spécifiques en fonction des besoins de l'utilisateur. Les fonctions suivantes sont définies :

#### 1. Analyse de recettes (recipe-analysis.function.ts)

Permet d'analyser une recette pour déterminer ses caractéristiques nutritionnelles, son origine culturelle, sa conformité halal, son niveau de difficulté et son temps de préparation.

#### 2. Génération de plan de repas (meal-plan-generation.function.ts)

Génère un plan de repas personnalisé sur une période définie, en tenant compte des préférences alimentaires, des restrictions et des objectifs caloriques de l'utilisateur.

#### 3. Analyse nutritionnelle (nutrition-analysis.function.ts)

Analyse la valeur nutritionnelle d'un aliment ou d'une recette, fournissant des informations sur les calories, les macronutriments, les micronutriments et un score de santé global.

#### 4. Substitution d'ingrédients (ingredient-substitution.function.ts)

Propose des substituts halal pour des ingrédients spécifiques, avec des informations sur les ratios de substitution, l'impact nutritionnel et l'impact sur le goût.

## Intégration avec les autres modules

Le module IA est intégré avec les autres modules de l'application Dini Play :

### Module de recommandations

Le service IA améliore les recommandations de recettes en utilisant l'apprentissage automatique pour suggérer des recettes personnalisées en fonction des préférences de l'utilisateur, de son historique et des tendances actuelles.

### Module de plan de repas

Le service IA aide à générer des plans de repas équilibrés et personnalisés, en tenant compte des préférences alimentaires, des restrictions et des objectifs nutritionnels de l'utilisateur.

### Module de recettes

Le service IA enrichit les recettes avec des analyses nutritionnelles détaillées et des suggestions de substitution d'ingrédients.

## Gestion des quotas et limites

Le module IA implémente un système de limitation de requêtes pour respecter les quotas de l'API Google AI Studio :

```typescript
// ai.module.ts
import { Module } from '@nestjs/common';
import { ThrottlerModule } from '@nestjs/throttler';

@Module({
  imports: [
    ThrottlerModule.forRoot({
      ttl: 60,
      limit: 10, // Limite à 10 requêtes par minute
    }),
  ],
  // ...
})
export class AiModule {}
```

## Tests

Le module IA est accompagné de tests unitaires et d'intégration pour garantir son bon fonctionnement :

- `ai.service.spec.ts` : Tests unitaires pour le service IA
- `ai.controller.spec.ts` : Tests unitaires pour le contrôleur IA
- `ai.integration.spec.ts` : Tests d'intégration end-to-end

Pour exécuter les tests :

```bash
cd apps/api
npm run test
```

## Dépannage

### Problèmes d'authentification

Si vous rencontrez des problèmes d'authentification avec l'API Google AI Studio, vérifiez que :

1. La clé API est correctement configurée dans le fichier `.env`
2. La clé API est valide et active dans la console Google AI Studio
3. Vous n'avez pas dépassé les quotas de l'API

### Erreurs de Function Calling

Si les fonctions ne sont pas correctement appelées par le modèle IA :

1. Vérifiez que les schémas de fonction sont correctement définis
2. Assurez-vous que le modèle Gemini utilisé prend en charge Function Calling
3. Vérifiez les logs pour identifier les erreurs spécifiques

## Ressources supplémentaires

- [Documentation officielle de l'API Gemini](https://ai.google.dev/gemini-api/docs)
- [Guide de Function Calling avec Gemini](https://ai.google.dev/gemini-api/docs/function-calling)
- [Console Google AI Studio](https://aistudio.google.com/)
